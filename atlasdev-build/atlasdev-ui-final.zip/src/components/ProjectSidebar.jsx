import React, { useState } from 'react';
import { NavLink, useParams, useNavigate } from 'react-router-dom';
import { 
  ChevronLeft, ChevronDown, ChevronRight, Building2,
  FileText, Users, CheckSquare, Search, Calculator,
  TrendingUp, Hammer, FileCheck, Calendar, DollarSign,
  Receipt, ClipboardList, Home, Megaphone, Shield,
  PieChart, BarChart3, Wallet, FolderOpen, Mail, MessageSquare
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';

// Define project modules and their subsections
const projectModules = [
  {
    id: 'overview',
    label: 'OVERVIEW',
    sections: [
      { id: 'basic-info', label: 'Basic Info', icon: FileText },
      { id: 'property-profile', label: 'Property Profile', icon: Building2 },
      { id: 'seller-info', label: 'Seller Info', icon: Users },
      { id: 'tasks', label: 'Tasks', icon: CheckSquare },
    ],
  },
  {
    id: 'pipeline',
    label: 'PIPELINE ANALYSIS',
    sections: [
      { id: 'deal-analysis', label: 'Deal Analysis', icon: Calculator },
      { id: 'pipeline-tracker', label: 'Pipeline Tracker', icon: TrendingUp },
    ],
  },
  {
    id: 'acquisition',
    label: 'ACQUISITION',
    sections: [
      { id: 'due-diligence', label: 'Due Diligence', icon: Search },
      { id: 'legal', label: 'Legal', icon: FileCheck },
      { id: 'loans', label: 'Loans', icon: DollarSign },
    ],
  },
  {
    id: 'construction',
    label: 'CONSTRUCTION',
    sections: [
      { id: 'plans-permits', label: 'Plans & Permits', icon: ClipboardList },
      { id: 'schedule', label: 'Schedule', icon: Calendar },
      { id: 'budget', label: 'Budget', icon: DollarSign },
      { id: 'draws', label: 'Draws', icon: Receipt },
      { id: 'contracts', label: 'Contracts', icon: FileText },
      { id: 'inspections', label: 'Inspections', icon: CheckSquare },
    ],
  },
  {
    id: 'disposition',
    label: 'DISPOSITION',
    sections: [
      { id: 'marketing', label: 'Marketing', icon: Megaphone },
      { id: 'sales', label: 'Sales', icon: Home },
      { id: 'warranty', label: 'Warranty', icon: Shield },
    ],
  },
  {
    id: 'finance',
    label: 'FINANCE',
    sections: [
      { id: 'proforma', label: 'Proforma', icon: PieChart },
      { id: 'actuals', label: 'Actuals', icon: BarChart3 },
      { id: 'expenses', label: 'Expenses', icon: Receipt },
      { id: 'revenue', label: 'Revenue', icon: Wallet },
    ],
  },
  {
    id: 'investors',
    label: 'INVESTORS',
    sections: [
      { id: 'investors-list', label: 'Investors', icon: Users },
      { id: 'investments', label: 'Investments', icon: DollarSign },
      { id: 'distributions', label: 'Distributions', icon: Wallet },
    ],
  },
  {
    id: 'documents',
    label: 'DOCUMENTS',
    sections: [
      { id: 'all-documents', label: 'Documents', icon: FolderOpen },
      { id: 'communications', label: 'Communications', icon: MessageSquare },
      { id: 'email', label: 'Email', icon: Mail },
    ],
  },
];

// Mock project data
const mockProjectData = {
  1: { name: 'Watson House', code: 'PRJ-001', status: 'construction' },
  2: { name: 'Oslo Townhomes', code: 'PRJ-002', status: 'pre_development' },
  3: { name: 'Cedar Mill Apartments', code: 'PRJ-003', status: 'acquisition' },
  4: { name: 'Pine Valley Lots', code: 'PRJ-004', status: 'construction' },
};

const statusColors = {
  acquisition: 'bg-blue-500',
  pre_development: 'bg-purple-500',
  construction: 'bg-yellow-500',
  stabilized: 'bg-green-500',
};

const ProjectSidebar = ({ currentSection, currentSubsection }) => {
  const { projectId } = useParams();
  const navigate = useNavigate();
  const [expandedModules, setExpandedModules] = useState(['overview', 'pipeline']);
  
  const project = mockProjectData[projectId] || mockProjectData[1];

  const toggleModule = (moduleId) => {
    setExpandedModules(prev => 
      prev.includes(moduleId) 
        ? prev.filter(id => id !== moduleId)
        : [...prev, moduleId]
    );
  };

  return (
    <div className="w-64 bg-[#1a202c] text-white flex flex-col h-full">
      {/* Back Link */}
      <div className="px-4 py-3 border-b border-gray-700">
        <button 
          onClick={() => navigate('/projects')}
          className="flex items-center gap-2 text-sm text-gray-400 hover:text-white transition-colors"
        >
          <ChevronLeft className="w-4 h-4" />
          BACK TO PROJECTS
        </button>
      </div>

      {/* Project Header */}
      <div className="px-4 py-4 border-b border-gray-700">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-emerald-600 rounded-lg flex items-center justify-center">
            <Building2 className="w-5 h-5 text-white" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs text-gray-400 uppercase">PROJECT</p>
            <p className="font-semibold truncate">{project.name}</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-2">
        {projectModules.map((module) => {
          const isExpanded = expandedModules.includes(module.id);
          
          return (
            <div key={module.id} className="mb-1">
              {/* Module Header */}
              <button
                onClick={() => toggleModule(module.id)}
                className="w-full px-4 py-2 flex items-center justify-between text-xs font-semibold text-gray-400 hover:text-gray-200 transition-colors"
              >
                <span>{module.label}</span>
                {isExpanded ? (
                  <ChevronDown className="w-4 h-4" />
                ) : (
                  <ChevronRight className="w-4 h-4" />
                )}
              </button>

              {/* Module Sections */}
              {isExpanded && (
                <div className="space-y-0.5">
                  {module.sections.map((section) => {
                    const Icon = section.icon;
                    const isActive = currentSection === module.id && currentSubsection === section.id;
                    
                    return (
                      <NavLink
                        key={section.id}
                        to={`/project/${projectId}/${module.id}/${section.id}`}
                        className={cn(
                          "flex items-center gap-3 px-6 py-2 text-sm transition-colors",
                          isActive 
                            ? "bg-gray-700 text-white border-l-2 border-emerald-500" 
                            : "text-gray-400 hover:bg-gray-800 hover:text-white"
                        )}
                      >
                        <Icon className="w-4 h-4" />
                        <span>{section.label}</span>
                      </NavLink>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="px-4 py-3 border-t border-gray-700">
        <p className="text-xs text-gray-500">AtlasDev v1.0</p>
      </div>
    </div>
  );
};

export default ProjectSidebar;
