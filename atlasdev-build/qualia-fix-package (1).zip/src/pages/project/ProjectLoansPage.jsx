import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { Search, Plus } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { cn } from '@/lib/utils';

const ProjectLoansPage = () => {
  const { projectId } = useParams();
  
  const [formData, setFormData] = useState({
    loanAmount: '',
    fundingType: 'net',
    lender: '',
    loanType: '',
    termYears: '',
    termMonths: '',
    firstPaymentDate: '',
    lastPaymentDate: '',
    commitmentDate: '',
    maturityDate: '',
    originationFeePercent: '',
    originationFeeAmount: '',
    originationPoints: '',
    isHELOC: false,
    isConstructionLoan: false,
    isMERS: false,
    mersMinNumber: '',
    generatingMortgageDocs: false,
    loanIdNumber: '',
    mortgageInsCaseNumber: '',
    gracePeriodDays: '',
    latePenaltyAmount: '',
    latePenaltyType: 'percent',
    interestOnly: false,
    interestRate: '',
    interestType: 'Fixed',
    loanOfficer: '',
    loanProcessor: '',
  });

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const loanTypes = [
    'Construction',
    'Permanent',
    'Bridge',
    'Mezzanine',
    'Acquisition',
    'Refinance',
    'Hard Money',
    'SBA',
    'Conventional',
    'FHA',
    'VA',
    'USDA',
  ];

  return (
    <div className="p-6 bg-gray-50 min-h-full overflow-auto">
      <div className="max-w-4xl space-y-4">
        
        {/* Loan Amount & Type */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <h3 className="text-xs font-semibold text-gray-700 uppercase mb-4">Loan Details</h3>
          <div className="grid grid-cols-4 gap-4">
            <div>
              <label className="block text-[11px] text-gray-500 uppercase mb-1">Loan Amount</label>
              <Input
                value={formData.loanAmount}
                onChange={(e) => handleChange('loanAmount', e.target.value)}
                placeholder="$0.00"
                className="h-9 text-sm"
              />
            </div>
            <div>
              <label className="block text-[11px] text-gray-500 uppercase mb-1">Funding Type</label>
              <div className="flex border border-gray-200 rounded overflow-hidden h-9">
                <button
                  onClick={() => handleChange('fundingType', 'net')}
                  className={cn(
                    "flex-1 text-xs font-medium transition-colors",
                    formData.fundingType === 'net'
                      ? "bg-gray-800 text-white"
                      : "bg-white text-gray-600 hover:bg-gray-50"
                  )}
                >
                  Net
                </button>
                <button
                  onClick={() => handleChange('fundingType', 'gross')}
                  className={cn(
                    "flex-1 text-xs font-medium transition-colors",
                    formData.fundingType === 'gross'
                      ? "bg-gray-800 text-white"
                      : "bg-white text-gray-600 hover:bg-gray-50"
                  )}
                >
                  Gross
                </button>
              </div>
            </div>
            <div>
              <label className="block text-[11px] text-gray-500 uppercase mb-1">Lender</label>
              <div className="relative">
                <Input
                  value={formData.lender}
                  onChange={(e) => handleChange('lender', e.target.value)}
                  placeholder="Search lenders..."
                  className="h-9 text-sm pr-8"
                />
                <Search className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              </div>
            </div>
            <div>
              <label className="block text-[11px] text-gray-500 uppercase mb-1">Loan Type</label>
              <select
                value={formData.loanType}
                onChange={(e) => handleChange('loanType', e.target.value)}
                className="w-full h-9 text-sm border border-gray-200 rounded px-2"
              >
                <option value="">Select type...</option>
                {loanTypes.map(type => (
                  <option key={type} value={type}>{type}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Term */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <h3 className="text-xs font-semibold text-gray-700 uppercase mb-4">Term</h3>
          <div className="grid grid-cols-6 gap-4">
            <div>
              <label className="block text-[11px] text-gray-500 uppercase mb-1">Years</label>
              <Input
                type="number"
                value={formData.termYears}
                onChange={(e) => handleChange('termYears', e.target.value)}
                className="h-9 text-sm"
              />
            </div>
            <div>
              <label className="block text-[11px] text-gray-500 uppercase mb-1">Months</label>
              <Input
                type="number"
                value={formData.termMonths}
                onChange={(e) => handleChange('termMonths', e.target.value)}
                className="h-9 text-sm"
              />
            </div>
            <div>
              <label className="block text-[11px] text-gray-500 uppercase mb-1">First Payment</label>
              <Input
                type="date"
                value={formData.firstPaymentDate}
                onChange={(e) => handleChange('firstPaymentDate', e.target.value)}
                className="h-9 text-sm"
              />
            </div>
            <div>
              <label className="block text-[11px] text-gray-500 uppercase mb-1">Last Payment</label>
              <Input
                type="date"
                value={formData.lastPaymentDate}
                onChange={(e) => handleChange('lastPaymentDate', e.target.value)}
                className="h-9 text-sm"
              />
            </div>
            <div>
              <label className="block text-[11px] text-gray-500 uppercase mb-1">Commitment</label>
              <Input
                type="date"
                value={formData.commitmentDate}
                onChange={(e) => handleChange('commitmentDate', e.target.value)}
                className="h-9 text-sm"
              />
            </div>
            <div>
              <label className="block text-[11px] text-gray-500 uppercase mb-1">Maturity</label>
              <Input
                type="date"
                value={formData.maturityDate}
                onChange={(e) => handleChange('maturityDate', e.target.value)}
                className="h-9 text-sm"
              />
            </div>
          </div>
        </div>

        {/* Origination */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <h3 className="text-xs font-semibold text-gray-700 uppercase mb-4">Origination</h3>
          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-[11px] text-gray-500 uppercase mb-1">Fee %</label>
              <Input
                value={formData.originationFeePercent}
                onChange={(e) => handleChange('originationFeePercent', e.target.value)}
                placeholder="0.00%"
                className="h-9 text-sm"
              />
            </div>
            <div>
              <label className="block text-[11px] text-gray-500 uppercase mb-1">Fee Amount</label>
              <Input
                value={formData.originationFeeAmount}
                onChange={(e) => handleChange('originationFeeAmount', e.target.value)}
                placeholder="$0.00"
                className="h-9 text-sm"
              />
            </div>
            <div>
              <label className="block text-[11px] text-gray-500 uppercase mb-1">Points</label>
              <Input
                value={formData.originationPoints}
                onChange={(e) => handleChange('originationPoints', e.target.value)}
                placeholder="0"
                className="h-9 text-sm"
              />
            </div>
          </div>
        </div>

        {/* Options */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <h3 className="text-xs font-semibold text-gray-700 uppercase mb-4">Options</h3>
          <div className="space-y-3">
            <div className="flex items-center gap-8">
              <label className="flex items-center gap-2 text-xs text-gray-600">
                <Switch
                  checked={formData.isHELOC}
                  onCheckedChange={(v) => handleChange('isHELOC', v)}
                />
                HELOC
              </label>
              <label className="flex items-center gap-2 text-xs text-gray-600">
                <Switch
                  checked={formData.isConstructionLoan}
                  onCheckedChange={(v) => handleChange('isConstructionLoan', v)}
                />
                Construction Loan
              </label>
              <label className="flex items-center gap-2 text-xs text-gray-600">
                <Switch
                  checked={formData.generatingMortgageDocs}
                  onCheckedChange={(v) => handleChange('generatingMortgageDocs', v)}
                />
                Generating Mortgage Docs
              </label>
            </div>
            <div className="flex items-center gap-4">
              <label className="flex items-center gap-2 text-xs text-gray-600">
                <Switch
                  checked={formData.isMERS}
                  onCheckedChange={(v) => handleChange('isMERS', v)}
                />
                MERS
              </label>
              {formData.isMERS && (
                <div className="flex-1 max-w-xs">
                  <label className="block text-[11px] text-gray-500 uppercase mb-1">MIN #</label>
                  <Input
                    value={formData.mersMinNumber}
                    onChange={(e) => handleChange('mersMinNumber', e.target.value)}
                    className="h-8 text-sm"
                  />
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Disclosures */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <h3 className="text-xs font-semibold text-gray-700 uppercase mb-4">Disclosures</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-[11px] text-gray-500 uppercase mb-1">Loan ID #</label>
              <Input
                value={formData.loanIdNumber}
                onChange={(e) => handleChange('loanIdNumber', e.target.value)}
                className="h-9 text-sm"
              />
            </div>
            <div>
              <label className="block text-[11px] text-gray-500 uppercase mb-1">Mortgage Ins. Case #</label>
              <Input
                value={formData.mortgageInsCaseNumber}
                onChange={(e) => handleChange('mortgageInsCaseNumber', e.target.value)}
                className="h-9 text-sm"
              />
            </div>
          </div>
        </div>

        {/* Late Penalty */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <h3 className="text-xs font-semibold text-gray-700 uppercase mb-4">Late Penalty</h3>
          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-[11px] text-gray-500 uppercase mb-1">Grace Period (Days)</label>
              <Input
                type="number"
                value={formData.gracePeriodDays}
                onChange={(e) => handleChange('gracePeriodDays', e.target.value)}
                className="h-9 text-sm"
              />
            </div>
            <div>
              <label className="block text-[11px] text-gray-500 uppercase mb-1">Amount</label>
              <Input
                value={formData.latePenaltyAmount}
                onChange={(e) => handleChange('latePenaltyAmount', e.target.value)}
                placeholder="0.00"
                className="h-9 text-sm"
              />
            </div>
            <div>
              <label className="block text-[11px] text-gray-500 uppercase mb-1">Type</label>
              <div className="flex border border-gray-200 rounded overflow-hidden h-9">
                <button
                  onClick={() => handleChange('latePenaltyType', 'percent')}
                  className={cn(
                    "flex-1 text-xs font-medium transition-colors",
                    formData.latePenaltyType === 'percent'
                      ? "bg-gray-800 text-white"
                      : "bg-white text-gray-600 hover:bg-gray-50"
                  )}
                >
                  %
                </button>
                <button
                  onClick={() => handleChange('latePenaltyType', 'dollar')}
                  className={cn(
                    "flex-1 text-xs font-medium transition-colors",
                    formData.latePenaltyType === 'dollar'
                      ? "bg-gray-800 text-white"
                      : "bg-white text-gray-600 hover:bg-gray-50"
                  )}
                >
                  $
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Interest */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <h3 className="text-xs font-semibold text-gray-700 uppercase mb-4">Interest</h3>
          <div className="grid grid-cols-3 gap-4 items-end">
            <div>
              <label className="flex items-center gap-2 text-xs text-gray-600 mb-2">
                <Switch
                  checked={formData.interestOnly}
                  onCheckedChange={(v) => handleChange('interestOnly', v)}
                />
                Interest Only
              </label>
            </div>
            <div>
              <label className="block text-[11px] text-gray-500 uppercase mb-1">Rate %</label>
              <Input
                value={formData.interestRate}
                onChange={(e) => handleChange('interestRate', e.target.value)}
                placeholder="0.00%"
                className="h-9 text-sm"
              />
            </div>
            <div>
              <label className="block text-[11px] text-gray-500 uppercase mb-1">Type</label>
              <select
                value={formData.interestType}
                onChange={(e) => handleChange('interestType', e.target.value)}
                className="w-full h-9 text-sm border border-gray-200 rounded px-2"
              >
                <option>Fixed</option>
                <option>Variable</option>
                <option>ARM</option>
              </select>
            </div>
          </div>
        </div>

        {/* Lender Contacts */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <h3 className="text-xs font-semibold text-gray-700 uppercase mb-4">Lender Contacts</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-[11px] text-gray-500 uppercase mb-1">Loan Officer</label>
              <div className="relative">
                <Input
                  value={formData.loanOfficer}
                  onChange={(e) => handleChange('loanOfficer', e.target.value)}
                  placeholder="Search..."
                  className="h-9 text-sm pr-8"
                />
                <Search className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              </div>
            </div>
            <div>
              <label className="block text-[11px] text-gray-500 uppercase mb-1">Processor</label>
              <div className="relative">
                <Input
                  value={formData.loanProcessor}
                  onChange={(e) => handleChange('loanProcessor', e.target.value)}
                  placeholder="Search..."
                  className="h-9 text-sm pr-8"
                />
                <Search className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};

export default ProjectLoansPage;
