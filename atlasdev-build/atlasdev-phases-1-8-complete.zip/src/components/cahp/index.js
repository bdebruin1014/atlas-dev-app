// src/components/cahp/index.js
// Export all CAHP components

export { default as AddTenantModal } from './AddTenantModal';
export { default as RecertifyTenantModal } from './RecertifyTenantModal';
