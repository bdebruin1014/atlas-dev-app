#!/bin/bash
# AtlasDev Pages Installation Script
# Run this in your Codespace terminal from your project root

echo "=== AtlasDev Pages Installation ==="
echo ""

# Check if we're in the right directory
if [ ! -d "src" ]; then
    echo "ERROR: 'src' folder not found. Please run this from your project root."
    exit 1
fi

# Create directories if they don't exist
echo "Creating directories..."
mkdir -p src/pages/accounting
mkdir -p src/pages/projects
mkdir -p src/pages/eos
mkdir -p src/pages/eos/components

# Copy accounting pages
echo "Installing accounting pages (10 files)..."
cp src-new/pages/accounting/*.jsx src/pages/accounting/

# Copy project pages
echo "Installing project pages (43 files)..."
cp src-new/pages/projects/*.jsx src/pages/projects/

# Copy EOS module
echo "Installing EOS module (17 files)..."
cp src-new/pages/eos/*.jsx src/pages/eos/
cp src-new/pages/eos/components/*.jsx src/pages/eos/components/
cp src-new/pages/eos/components/*.js src/pages/eos/components/

echo ""
echo "=== Installation Complete ==="
echo ""
echo "Files installed:"
echo "  - Accounting: $(ls src/pages/accounting/*.jsx 2>/dev/null | wc -l) pages"
echo "  - Projects:   $(ls src/pages/projects/*.jsx 2>/dev/null | wc -l) pages"
echo "  - EOS:        $(find src/pages/eos -name '*.jsx' -o -name '*.js' 2>/dev/null | wc -l) files"
echo ""
echo "NEXT STEPS:"
echo "1. Update your router (see ROUTES.jsx for examples)"
echo "2. Add EOS to your header navigation"
echo "3. Run: npm run dev"
echo ""
