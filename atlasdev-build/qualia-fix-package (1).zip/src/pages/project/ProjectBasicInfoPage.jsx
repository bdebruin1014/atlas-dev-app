import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { Calendar, Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';

const ProjectBasicInfoPage = () => {
  const { projectId } = useParams();
  
  const [formData, setFormData] = useState({
    acceptanceDate: '',
    daysToClose: '30',
    estimatedClosing: '',
    contractDate: '',
    fundingDate: '',
    disbursementDate: '',
    buyersClosing: '',
    sellersClosing: '',
    purchasePrice: '',
    loanAmount: '',
    cashOnly: false,
    heloc: false,
    constructionLoan: false,
    transactionType: 'Purchase',
    representing: 'Buyer',
    accountingMode: 'Accrual',
    projectType: 'Single Family',
    projectTemplate: '',
    clientEntity: '',
    sourceOfBusiness: '',
    statusSummary: '',
    eligible1099: false,
    fincenReportable: false,
    agency: '',
    responsibleAttorney: '',
    paralegal: '',
    orderOpener: '',
    assistant: '',
    marketer: '',
    closingAddress: '',
    closingApt: '',
    closingCity: '',
    closingCounty: '',
  });

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const SearchableSelect = ({ label, value, onChange, placeholder, greenLabel = false }) => (
    <div>
      <label className={`block text-[11px] uppercase mb-1 ${greenLabel ? 'text-[#047857] font-medium' : 'text-gray-500'}`}>
        {label}
      </label>
      <div className="relative">
        <Input 
          value={value} 
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          className="h-9 text-sm pr-8"
        />
        <Search className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
      </div>
    </div>
  );

  const DateInput = ({ label, value, onChange, greenLabel = false }) => (
    <div>
      <label className={`block text-[11px] uppercase mb-1 ${greenLabel ? 'text-[#047857] font-medium' : 'text-gray-500'}`}>
        {label}
      </label>
      <div className="relative">
        <Input 
          type="date"
          value={value} 
          onChange={(e) => onChange(e.target.value)}
          className="h-9 text-sm"
        />
      </div>
    </div>
  );

  return (
    <div className="p-6 bg-gray-50 min-h-full overflow-auto">
      <div className="max-w-5xl space-y-6">
        
        {/* Dates Section */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <h3 className="text-xs font-semibold text-gray-700 uppercase mb-4">Dates</h3>
          <div className="grid grid-cols-6 gap-4">
            <DateInput 
              label="Acceptance" 
              value={formData.acceptanceDate} 
              onChange={(v) => handleChange('acceptanceDate', v)} 
            />
            <div>
              <label className="block text-[11px] text-gray-500 uppercase mb-1">Days to Close</label>
              <Input 
                type="number"
                value={formData.daysToClose} 
                onChange={(e) => handleChange('daysToClose', e.target.value)}
                className="h-9 text-sm"
              />
            </div>
            <DateInput 
              label="Estimated Closing" 
              value={formData.estimatedClosing} 
              onChange={(v) => handleChange('estimatedClosing', v)}
              greenLabel 
            />
            <DateInput 
              label="Contract" 
              value={formData.contractDate} 
              onChange={(v) => handleChange('contractDate', v)} 
            />
            <DateInput 
              label="Funding" 
              value={formData.fundingDate} 
              onChange={(v) => handleChange('fundingDate', v)}
              greenLabel 
            />
            <DateInput 
              label="Disbursement" 
              value={formData.disbursementDate} 
              onChange={(v) => handleChange('disbursementDate', v)}
              greenLabel 
            />
          </div>
        </div>

        {/* Closings Section */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xs font-semibold text-gray-700 uppercase">Closings</h3>
            <Button variant="outline" size="sm" className="text-xs h-7">
              Schedule Closing
            </Button>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <DateInput 
              label="Buyer's Closing" 
              value={formData.buyersClosing} 
              onChange={(v) => handleChange('buyersClosing', v)} 
            />
            <DateInput 
              label="Seller's Closing" 
              value={formData.sellersClosing} 
              onChange={(v) => handleChange('sellersClosing', v)} 
            />
          </div>
        </div>

        {/* Amounts Section */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <h3 className="text-xs font-semibold text-gray-700 uppercase mb-4">Amounts</h3>
          <div className="grid grid-cols-4 gap-4 items-end">
            <div>
              <label className="block text-[11px] text-gray-500 uppercase mb-1">Purchase Price</label>
              <Input 
                type="text"
                value={formData.purchasePrice} 
                onChange={(e) => handleChange('purchasePrice', e.target.value)}
                placeholder="$0.00"
                className="h-9 text-sm"
              />
            </div>
            <div>
              <label className="block text-[11px] text-gray-500 uppercase mb-1">Loan Amount</label>
              <Input 
                type="text"
                value={formData.loanAmount} 
                onChange={(e) => handleChange('loanAmount', e.target.value)}
                placeholder="$0.00"
                className="h-9 text-sm"
              />
            </div>
            <div className="col-span-2 flex items-center gap-6">
              <label className="flex items-center gap-2 text-xs text-gray-600">
                <Switch checked={formData.cashOnly} onCheckedChange={(v) => handleChange('cashOnly', v)} />
                Cash Only
              </label>
              <label className="flex items-center gap-2 text-xs text-gray-600">
                <Switch checked={formData.heloc} onCheckedChange={(v) => handleChange('heloc', v)} />
                HELOC
              </label>
              <label className="flex items-center gap-2 text-xs text-gray-600">
                <Switch checked={formData.constructionLoan} onCheckedChange={(v) => handleChange('constructionLoan', v)} />
                Construction Loan
              </label>
            </div>
          </div>
        </div>

        {/* Type Section */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <h3 className="text-xs font-semibold text-gray-700 uppercase mb-4">Type</h3>
          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-[11px] text-gray-500 uppercase mb-1">Transaction Type</label>
              <select 
                value={formData.transactionType}
                onChange={(e) => handleChange('transactionType', e.target.value)}
                className="w-full h-9 text-sm border border-gray-200 rounded px-2"
              >
                <option>Purchase</option>
                <option>Sale</option>
                <option>Refinance</option>
                <option>Construction</option>
                <option>Development</option>
              </select>
            </div>
            <div>
              <label className="block text-[11px] text-gray-500 uppercase mb-1">Representing</label>
              <select 
                value={formData.representing}
                onChange={(e) => handleChange('representing', e.target.value)}
                className="w-full h-9 text-sm border border-gray-200 rounded px-2"
              >
                <option>Buyer</option>
                <option>Seller</option>
                <option>Both</option>
              </select>
            </div>
            <div>
              <label className="block text-[11px] text-gray-500 uppercase mb-1">Accounting Mode</label>
              <select 
                value={formData.accountingMode}
                onChange={(e) => handleChange('accountingMode', e.target.value)}
                className="w-full h-9 text-sm border border-gray-200 rounded px-2"
              >
                <option>Accrual</option>
                <option>Cash</option>
              </select>
            </div>
            <div>
              <label className="block text-[11px] text-gray-500 uppercase mb-1">Project Type</label>
              <select 
                value={formData.projectType}
                onChange={(e) => handleChange('projectType', e.target.value)}
                className="w-full h-9 text-sm border border-gray-200 rounded px-2"
              >
                <option>Single Family</option>
                <option>Multifamily</option>
                <option>Commercial</option>
                <option>Land Development</option>
                <option>Fix & Flip</option>
                <option>Build to Rent</option>
              </select>
            </div>
            <SearchableSelect 
              label="Project Template" 
              value={formData.projectTemplate}
              onChange={(v) => handleChange('projectTemplate', v)}
              placeholder="Select template..."
            />
            <SearchableSelect 
              label="Client Entity" 
              value={formData.clientEntity}
              onChange={(v) => handleChange('clientEntity', v)}
              placeholder="Link to Accounting..."
            />
          </div>
        </div>

        {/* Reporting Section */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <h3 className="text-xs font-semibold text-gray-700 uppercase mb-4">Reporting</h3>
          <div className="grid grid-cols-2 gap-4">
            <SearchableSelect 
              label="Source of Business" 
              value={formData.sourceOfBusiness}
              onChange={(v) => handleChange('sourceOfBusiness', v)}
              placeholder="Select source..."
            />
            <div>
              <label className="block text-[11px] text-gray-500 uppercase mb-1">Status Summary</label>
              <textarea 
                value={formData.statusSummary}
                onChange={(e) => handleChange('statusSummary', e.target.value)}
                className="w-full h-20 text-sm border border-gray-200 rounded px-2 py-1 resize-none"
                placeholder="Enter status notes..."
              />
            </div>
          </div>
        </div>

        {/* Taxes Section */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <h3 className="text-xs font-semibold text-gray-700 uppercase mb-4">Taxes</h3>
          <div className="flex items-center gap-8">
            <label className="flex items-center gap-2 text-xs text-gray-600">
              <Switch checked={formData.eligible1099} onCheckedChange={(v) => handleChange('eligible1099', v)} />
              1099 Eligible
            </label>
            <label className="flex items-center gap-2 text-xs text-gray-600">
              <Switch checked={formData.fincenReportable} onCheckedChange={(v) => handleChange('fincenReportable', v)} />
              FinCEN Reportable
            </label>
          </div>
        </div>

        {/* Settlement Team Section */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <h3 className="text-xs font-semibold text-gray-700 uppercase mb-4">Settlement Team</h3>
          <div className="grid grid-cols-3 gap-4">
            <SearchableSelect 
              label="Agency" 
              value={formData.agency}
              onChange={(v) => handleChange('agency', v)}
              placeholder="Select agency..."
            />
            <SearchableSelect 
              label="Responsible Attorney" 
              value={formData.responsibleAttorney}
              onChange={(v) => handleChange('responsibleAttorney', v)}
              placeholder="Select attorney..."
            />
            <SearchableSelect 
              label="Paralegal" 
              value={formData.paralegal}
              onChange={(v) => handleChange('paralegal', v)}
              placeholder="Select paralegal..."
            />
            <SearchableSelect 
              label="Order Opener" 
              value={formData.orderOpener}
              onChange={(v) => handleChange('orderOpener', v)}
              placeholder="Select opener..."
            />
            <SearchableSelect 
              label="Assistant" 
              value={formData.assistant}
              onChange={(v) => handleChange('assistant', v)}
              placeholder="Select assistant..."
            />
            <SearchableSelect 
              label="Marketer" 
              value={formData.marketer}
              onChange={(v) => handleChange('marketer', v)}
              placeholder="Select marketer..."
            />
          </div>
        </div>

        {/* Place of Closing Section */}
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <h3 className="text-xs font-semibold text-gray-700 uppercase mb-4">Place of Closing</h3>
          <div className="grid grid-cols-4 gap-4">
            <div className="col-span-2">
              <label className="block text-[11px] text-gray-500 uppercase mb-1">Address</label>
              <Input 
                value={formData.closingAddress}
                onChange={(e) => handleChange('closingAddress', e.target.value)}
                placeholder="Street address"
                className="h-9 text-sm"
              />
            </div>
            <div>
              <label className="block text-[11px] text-gray-500 uppercase mb-1">Apt/Suite</label>
              <Input 
                value={formData.closingApt}
                onChange={(e) => handleChange('closingApt', e.target.value)}
                className="h-9 text-sm"
              />
            </div>
            <div>
              <label className="block text-[11px] text-gray-500 uppercase mb-1">City</label>
              <Input 
                value={formData.closingCity}
                onChange={(e) => handleChange('closingCity', e.target.value)}
                className="h-9 text-sm"
              />
            </div>
            <div>
              <label className="block text-[11px] text-gray-500 uppercase mb-1">County</label>
              <Input 
                value={formData.closingCounty}
                onChange={(e) => handleChange('closingCounty', e.target.value)}
                className="h-9 text-sm"
              />
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};

export default ProjectBasicInfoPage;
