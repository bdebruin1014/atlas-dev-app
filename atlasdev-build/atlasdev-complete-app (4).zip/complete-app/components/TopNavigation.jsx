import React from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { 
  Building2, ChevronDown, Search, Bell, User, Settings, LogOut,
  Target, FolderKanban, Calendar, CheckSquare, Users, 
  Calculator, BarChart3, ListChecks, Milestone, Package, 
  TrendingUp, Briefcase, UserCircle, Shield, Mail
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { cn } from '@/lib/utils';

const TopNavigation = () => {
  const navigate = useNavigate();
  const location = useLocation();
  
  const isActive = (path) => location.pathname.startsWith(path);

  return (
    <header className="h-12 bg-[#1a202c] border-b border-gray-700 flex items-center justify-between px-3 flex-shrink-0">
      <div className="flex items-center gap-4">
        <Link to="/" className="flex items-center gap-2 hover:opacity-80 transition-opacity">
          <div className="w-7 h-7 bg-emerald-600 rounded-md flex items-center justify-center">
            <Building2 className="w-4 h-4 text-white" />
          </div>
          <span className="text-white font-bold text-sm">AtlasDev</span>
        </Link>

        <nav className="flex items-center">
          <Link to="/pipeline">
            <Button 
              variant="ghost" 
              size="sm"
              className={cn(
                "text-gray-300 hover:text-white hover:bg-gray-700 text-xs h-8 px-2.5",
                isActive('/pipeline') && "bg-gray-700 text-white"
              )}
            >
              <Target className="w-3.5 h-3.5 mr-1.5" />
              Opportunities
            </Button>
          </Link>

          <Link to="/projects">
            <Button 
              variant="ghost" 
              size="sm"
              className={cn(
                "text-gray-300 hover:text-white hover:bg-gray-700 text-xs h-8 px-2.5",
                (isActive('/project') || location.pathname === '/projects') && "bg-gray-700 text-white"
              )}
            >
              <FolderKanban className="w-3.5 h-3.5 mr-1.5" />
              Projects
            </Button>
          </Link>

          <Link to="/calendar">
            <Button 
              variant="ghost" 
              size="sm"
              className={cn(
                "text-gray-300 hover:text-white hover:bg-gray-700 text-xs h-8 px-2.5",
                isActive('/calendar') && "bg-gray-700 text-white"
              )}
            >
              <Calendar className="w-3.5 h-3.5 mr-1.5" />
              Calendar
            </Button>
          </Link>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                variant="ghost" 
                size="sm"
                className={cn(
                  "text-gray-300 hover:text-white hover:bg-gray-700 text-xs h-8 px-2.5",
                  isActive('/operations') && "bg-gray-700 text-white"
                )}
              >
                <CheckSquare className="w-3.5 h-3.5 mr-1.5" />
                Operations
                <ChevronDown className="w-3 h-3 ml-1" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-44">
              <DropdownMenuItem onClick={() => navigate('/operations/tasks')} className="text-xs">
                <CheckSquare className="w-3.5 h-3.5 mr-2" />Tasks
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate('/operations/task-templates')} className="text-xs">
                <ListChecks className="w-3.5 h-3.5 mr-2" />Task Templates
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate('/operations/milestone-templates')} className="text-xs">
                <Milestone className="w-3.5 h-3.5 mr-2" />Milestone Templates
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => navigate('/operations/reports')} className="text-xs">
                <BarChart3 className="w-3.5 h-3.5 mr-2" />Reports
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate('/operations/product-library')} className="text-xs">
                <Package className="w-3.5 h-3.5 mr-2" />Product Library
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                variant="ghost" 
                size="sm"
                className={cn(
                  "text-gray-300 hover:text-white hover:bg-gray-700 text-xs h-8 px-2.5",
                  isActive('/investors') && "bg-gray-700 text-white"
                )}
              >
                <Users className="w-3.5 h-3.5 mr-1.5" />
                Investors
                <ChevronDown className="w-3 h-3 ml-1" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-44">
              <DropdownMenuItem onClick={() => navigate('/investors/contacts')} className="text-xs">
                <UserCircle className="w-3.5 h-3.5 mr-2" />Investor Contacts
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate('/investors/investments')} className="text-xs">
                <Briefcase className="w-3.5 h-3.5 mr-2" />Investments
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate('/investors/capital-raising')} className="text-xs">
                <TrendingUp className="w-3.5 h-3.5 mr-2" />Capital Raising
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <Link to="/accounting/entities">
            <Button 
              variant="ghost" 
              size="sm"
              className={cn(
                "text-gray-300 hover:text-white hover:bg-gray-700 text-xs h-8 px-2.5",
                isActive('/accounting') && "bg-gray-700 text-white"
              )}
            >
              <Calculator className="w-3.5 h-3.5 mr-1.5" />
              Accounting
            </Button>
          </Link>

          <Link to="/admin">
            <Button 
              variant="ghost" 
              size="sm"
              className={cn(
                "text-gray-300 hover:text-white hover:bg-gray-700 text-xs h-8 px-2.5",
                isActive('/admin') && "bg-gray-700 text-white"
              )}
            >
              <Settings className="w-3.5 h-3.5 mr-1.5" />
              Admin
            </Button>
          </Link>
        </nav>
      </div>

      <div className="flex items-center gap-3">
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400" />
          <Input 
            placeholder="Search..." 
            className="pl-8 w-52 h-8 text-xs bg-gray-700 border-gray-600 text-white placeholder:text-gray-400 focus:ring-emerald-500"
          />
        </div>

        <Button variant="ghost" size="icon" className="text-gray-300 hover:text-white hover:bg-gray-700 relative h-8 w-8">
          <Bell className="w-4 h-4" />
          <span className="absolute top-1 right-1 w-1.5 h-1.5 bg-red-500 rounded-full"></span>
        </Button>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="text-gray-300 hover:text-white hover:bg-gray-700 relative h-8 w-8">
              <div className="w-7 h-7 bg-gray-600 rounded-full flex items-center justify-center border border-gray-500 overflow-hidden">
                <User className="w-4 h-4 text-gray-300 mt-0.5" />
              </div>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-52">
            <DropdownMenuLabel>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-emerald-600 rounded-full flex items-center justify-center">
                  <User className="w-4 h-4 text-white" />
                </div>
                <div>
                  <p className="font-medium text-sm">Bryan V.</p>
                  <p className="text-xs text-gray-500">bryan@vanrock.com</p>
                </div>
              </div>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => navigate('/settings/profile')} className="text-xs">
              <User className="w-3.5 h-3.5 mr-2" />Your Profile
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => navigate('/settings/email')} className="text-xs">
              <Mail className="w-3.5 h-3.5 mr-2" />Email Settings
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => navigate('/settings/notifications')} className="text-xs">
              <Bell className="w-3.5 h-3.5 mr-2" />Notifications
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => navigate('/settings/security')} className="text-xs">
              <Shield className="w-3.5 h-3.5 mr-2" />Security
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => navigate('/settings/preferences/calendar')} className="text-xs">
              <Settings className="w-3.5 h-3.5 mr-2" />All Settings
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem className="text-red-600 text-xs">
              <LogOut className="w-3.5 h-3.5 mr-2" />Log out
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
};

export default TopNavigation;
