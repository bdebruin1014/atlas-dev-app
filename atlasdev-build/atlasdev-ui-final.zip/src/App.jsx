import React, { Suspense, lazy } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from '@/components/ui/toaster';
import { AuthProvider, useAuth } from '@/contexts/AuthContext';
import TopNavigation from '@/components/TopNavigation';
import LoadingState from '@/components/LoadingState';

// Create a client for React Query
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000, // 5 minutes
      retry: 1,
    },
  },
});

// Lazy load pages for better performance
// Auth pages
const LoginPage = lazy(() => import('@/pages/LoginPage'));
const SignUpPage = lazy(() => import('@/pages/SignUpPage'));
const ForgotPasswordPage = lazy(() => import('@/pages/ForgotPasswordPage'));

// Main pages
const HomePage = lazy(() => import('@/pages/HomePage'));
const ProjectsPage = lazy(() => import('@/pages/ProjectsPage'));
const ProjectsListPage = lazy(() => import('@/pages/ProjectsListPage'));
const ProjectDetailPage = lazy(() => import('@/pages/ProjectDetailPage'));
const EntitiesPage = lazy(() => import('@/pages/EntitiesPage'));
const OpportunitiesPage = lazy(() => import('@/pages/OpportunitiesPage'));
const ContactsPage = lazy(() => import('@/pages/ContactsPage'));
const CalendarPage = lazy(() => import('@/pages/CalendarPage'));
const SettingsPage = lazy(() => import('@/pages/SettingsPage'));

// Pipeline pages
const PipelineListPage = lazy(() => import('@/pages/PipelineListPage'));
const OpportunityDetailPage = lazy(() => import('@/pages/OpportunityDetailPage'));

// Layouts
const ProjectLayout = lazy(() => import('@/components/layouts/ProjectLayout'));
const OpportunityLayout = lazy(() => import('@/components/layouts/OpportunityLayout'));

// Accounting pages
const AccountingPage = lazy(() => import('@/pages/AccountingPage'));
const EntityAccountingDashboard = lazy(() => import('@/pages/EntityAccountingDashboard'));
const BankAccountsPage = lazy(() => import('@/pages/BankAccountsPage'));
const AccountingChartOfAccountsPage = lazy(() => import('@/pages/AccountingChartOfAccountsPage'));
const AccountingVendorsPage = lazy(() => import('@/pages/AccountingVendorsPage'));
const AccountingBillsPage = lazy(() => import('@/pages/AccountingBillsPage'));
const PaymentsPage = lazy(() => import('@/pages/PaymentsPage'));
const JournalEntriesPage = lazy(() => import('@/pages/JournalEntriesPage'));
const InvoicesPage = lazy(() => import('@/pages/InvoicesPage'));
const ReconciliationPage = lazy(() => import('@/pages/ReconciliationPage'));
const EntityCapitalPage = lazy(() => import('@/pages/EntityCapitalPage'));
const ReportsPage = lazy(() => import('@/pages/ReportsPage'));
const TrialBalanceReport = lazy(() => import('@/pages/TrialBalanceReport'));
const ProfitLossReport = lazy(() => import('@/pages/ProfitLossReport'));
const BalanceSheetReport = lazy(() => import('@/pages/BalanceSheetReport'));
const GeneralLedgerReport = lazy(() => import('@/pages/GeneralLedgerReport'));

// Investor pages
const InvestorsPage = lazy(() => import('@/pages/InvestorsPage'));
const InvestorDashboardPage = lazy(() => import('@/pages/InvestorDashboardPage'));
const InvestorDistributionsOverview = lazy(() => import('@/pages/InvestorDistributionsOverview'));
const CapitalCallsPage = lazy(() => import('@/pages/CapitalCallsPage'));

// Operations pages
const OperationsDashboard = lazy(() => import('@/pages/OperationsDashboard'));
const GlobalTasksPage = lazy(() => import('@/pages/GlobalTasksPage'));

// Protected Route Component
const ProtectedRoute = ({ children }) => {
  const { user, loading } = useAuth();
  
  if (loading) {
    return <LoadingState />;
  }
  
  if (!user) {
    return <Navigate to="/login" replace />;
  }
  
  return children;
};

// Main Layout with Top Navigation - for pages WITHOUT left sidebar
const MainLayout = ({ children }) => {
  return (
    <div className="h-full flex flex-col">
      <TopNavigation />
      <main className="flex-1 flex flex-col overflow-hidden">
        <Suspense fallback={<LoadingState />}>
          {children}
        </Suspense>
      </main>
    </div>
  );
};

// Layout with Top Navigation + Project Sidebar
const ProjectPageLayout = () => {
  return (
    <div className="h-full flex flex-col">
      <TopNavigation />
      <main className="flex-1 flex overflow-hidden">
        <Suspense fallback={<LoadingState />}>
          <ProjectLayout />
        </Suspense>
      </main>
    </div>
  );
};

// Layout with Top Navigation + Opportunity Sidebar
const OpportunityPageLayout = () => {
  return (
    <div className="h-full flex flex-col">
      <TopNavigation />
      <main className="flex-1 flex overflow-hidden">
        <Suspense fallback={<LoadingState />}>
          <OpportunityLayout />
        </Suspense>
      </main>
    </div>
  );
};

// Main App Content
const AppContent = () => {
  return (
    <Routes>
      {/* Public Routes */}
      <Route path="/login" element={
        <Suspense fallback={<LoadingState />}><LoginPage /></Suspense>
      } />
      <Route path="/signup" element={
        <Suspense fallback={<LoadingState />}><SignUpPage /></Suspense>
      } />
      <Route path="/forgot-password" element={
        <Suspense fallback={<LoadingState />}><ForgotPasswordPage /></Suspense>
      } />

      {/* Protected Routes */}
      <Route path="/" element={
        <ProtectedRoute>
          <MainLayout><HomePage /></MainLayout>
        </ProtectedRoute>
      } />
      
      {/* Projects - List View */}
      <Route path="/projects" element={
        <ProtectedRoute>
          <MainLayout><ProjectsListPage /></MainLayout>
        </ProtectedRoute>
      } />
      
      {/* Project Detail - With Left Sidebar */}
      <Route path="/project/:projectId" element={
        <ProtectedRoute>
          <ProjectPageLayout />
        </ProtectedRoute>
      }>
        <Route index element={<Navigate to="overview/basic-info" replace />} />
        <Route path=":section/:subsection" element={<ProjectDetailPage />} />
      </Route>
      
      {/* Pipeline - List View */}
      <Route path="/pipeline" element={
        <ProtectedRoute>
          <MainLayout><PipelineListPage /></MainLayout>
        </ProtectedRoute>
      } />
      
      {/* Opportunity Detail - With Left Sidebar */}
      <Route path="/pipeline/opportunity/:opportunityId" element={
        <ProtectedRoute>
          <OpportunityPageLayout />
        </ProtectedRoute>
      }>
        <Route index element={<Navigate to="overview/basic-info" replace />} />
        <Route path=":section/:subsection" element={<OpportunityDetailPage />} />
      </Route>
      
      {/* Legacy opportunities route - redirect to pipeline */}
      <Route path="/opportunities" element={<Navigate to="/pipeline" replace />} />
      
      <Route path="/entities" element={
        <ProtectedRoute>
          <MainLayout><EntitiesPage /></MainLayout>
        </ProtectedRoute>
      } />
      
      <Route path="/contacts" element={
        <ProtectedRoute>
          <MainLayout><ContactsPage /></MainLayout>
        </ProtectedRoute>
      } />
      
      <Route path="/calendar" element={
        <ProtectedRoute>
          <MainLayout><CalendarPage /></MainLayout>
        </ProtectedRoute>
      } />
      
      <Route path="/settings/*" element={
        <ProtectedRoute>
          <MainLayout><SettingsPage /></MainLayout>
        </ProtectedRoute>
      } />

      {/* Accounting Routes */}
      <Route path="/accounting" element={
        <ProtectedRoute>
          <MainLayout><AccountingPage /></MainLayout>
        </ProtectedRoute>
      } />
      
      <Route path="/accounting/entity/:entityId" element={
        <ProtectedRoute>
          <MainLayout><EntityAccountingDashboard /></MainLayout>
        </ProtectedRoute>
      } />
      
      <Route path="/accounting/entity/:entityId/dashboard" element={
        <ProtectedRoute>
          <MainLayout><EntityAccountingDashboard /></MainLayout>
        </ProtectedRoute>
      } />
      
      <Route path="/accounting/entity/:entityId/banking" element={
        <ProtectedRoute>
          <MainLayout><BankAccountsPage /></MainLayout>
        </ProtectedRoute>
      } />
      
      <Route path="/accounting/entity/:entityId/chart-of-accounts" element={
        <ProtectedRoute>
          <MainLayout><AccountingChartOfAccountsPage /></MainLayout>
        </ProtectedRoute>
      } />
      
      <Route path="/accounting/entity/:entityId/vendors" element={
        <ProtectedRoute>
          <MainLayout><AccountingVendorsPage /></MainLayout>
        </ProtectedRoute>
      } />
      
      <Route path="/accounting/entity/:entityId/bills" element={
        <ProtectedRoute>
          <MainLayout><AccountingBillsPage /></MainLayout>
        </ProtectedRoute>
      } />
      
      <Route path="/accounting/entity/:entityId/payments" element={
        <ProtectedRoute>
          <MainLayout><PaymentsPage /></MainLayout>
        </ProtectedRoute>
      } />
      
      <Route path="/accounting/entity/:entityId/journal-entries" element={
        <ProtectedRoute>
          <MainLayout><JournalEntriesPage /></MainLayout>
        </ProtectedRoute>
      } />
      
      <Route path="/accounting/entity/:entityId/invoices" element={
        <ProtectedRoute>
          <MainLayout><InvoicesPage /></MainLayout>
        </ProtectedRoute>
      } />
      
      <Route path="/accounting/entity/:entityId/reconciliation" element={
        <ProtectedRoute>
          <MainLayout><ReconciliationPage /></MainLayout>
        </ProtectedRoute>
      } />
      
      <Route path="/accounting/entity/:entityId/capital/*" element={
        <ProtectedRoute>
          <MainLayout><EntityCapitalPage /></MainLayout>
        </ProtectedRoute>
      } />
      
      <Route path="/accounting/entity/:entityId/reports" element={
        <ProtectedRoute>
          <MainLayout><ReportsPage /></MainLayout>
        </ProtectedRoute>
      } />
      
      <Route path="/accounting/entity/:entityId/reports/trial-balance" element={
        <ProtectedRoute>
          <MainLayout><TrialBalanceReport /></MainLayout>
        </ProtectedRoute>
      } />
      
      <Route path="/accounting/entity/:entityId/reports/profit-loss" element={
        <ProtectedRoute>
          <MainLayout><ProfitLossReport /></MainLayout>
        </ProtectedRoute>
      } />
      
      <Route path="/accounting/entity/:entityId/reports/balance-sheet" element={
        <ProtectedRoute>
          <MainLayout><BalanceSheetReport /></MainLayout>
        </ProtectedRoute>
      } />
      
      <Route path="/accounting/entity/:entityId/reports/general-ledger" element={
        <ProtectedRoute>
          <MainLayout><GeneralLedgerReport /></MainLayout>
        </ProtectedRoute>
      } />

      {/* Finance Routes (redirect to accounting equivalents) */}
      <Route path="/finance/entities/:entityId/bills" element={
        <ProtectedRoute>
          <MainLayout><AccountingBillsPage /></MainLayout>
        </ProtectedRoute>
      } />
      
      <Route path="/finance/entities/:entityId/invoices" element={
        <ProtectedRoute>
          <MainLayout><InvoicesPage /></MainLayout>
        </ProtectedRoute>
      } />
      
      <Route path="/finance/entities/:entityId/journal-entries" element={
        <ProtectedRoute>
          <MainLayout><JournalEntriesPage /></MainLayout>
        </ProtectedRoute>
      } />
      
      <Route path="/finance/entities/:entityId/vendors" element={
        <ProtectedRoute>
          <MainLayout><AccountingVendorsPage /></MainLayout>
        </ProtectedRoute>
      } />
      
      <Route path="/finance/entities/:entityId/chart-of-accounts" element={
        <ProtectedRoute>
          <MainLayout><AccountingChartOfAccountsPage /></MainLayout>
        </ProtectedRoute>
      } />

      {/* Investor Routes */}
      <Route path="/investors" element={
        <ProtectedRoute>
          <MainLayout><InvestorDashboardPage /></MainLayout>
        </ProtectedRoute>
      } />
      
      <Route path="/investors/directory" element={
        <ProtectedRoute>
          <MainLayout><InvestorsPage /></MainLayout>
        </ProtectedRoute>
      } />
      
      <Route path="/investors/distributions" element={
        <ProtectedRoute>
          <MainLayout><InvestorDistributionsOverview /></MainLayout>
        </ProtectedRoute>
      } />
      
      <Route path="/investors/capital-calls" element={
        <ProtectedRoute>
          <MainLayout><CapitalCallsPage /></MainLayout>
        </ProtectedRoute>
      } />

      {/* Operations Routes */}
      <Route path="/operations" element={
        <ProtectedRoute>
          <MainLayout><OperationsDashboard /></MainLayout>
        </ProtectedRoute>
      } />
      
      <Route path="/operations/tasks" element={
        <ProtectedRoute>
          <MainLayout><GlobalTasksPage /></MainLayout>
        </ProtectedRoute>
      } />

      {/* Catch all - redirect to home */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
};

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router>
        <Helmet>
          <title>AtlasDev | Real Estate Development Platform</title>
        </Helmet>
        <AuthProvider>
          <AppContent />
          <Toaster />
        </AuthProvider>
      </Router>
    </QueryClientProvider>
  );
}

export default App;
