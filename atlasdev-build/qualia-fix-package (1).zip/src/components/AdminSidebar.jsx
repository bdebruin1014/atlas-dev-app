import React, { useState } from 'react';
import { NavLink, useNavigate, useLocation } from 'react-router-dom';
import { 
  ChevronDown, ChevronLeft, Home, Users, Shield, Settings, 
  Building2, FileText, Workflow, BarChart3
} from 'lucide-react';
import { cn } from '@/lib/utils';

const AdminSidebar = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [expandedSections, setExpandedSections] = useState(['organization', 'security']);

  const toggleSection = (sectionId) => {
    setExpandedSections(prev => 
      prev.includes(sectionId) 
        ? prev.filter(id => id !== sectionId)
        : [...prev, sectionId]
    );
  };

  const sections = [
    {
      id: 'overview',
      label: 'Overview',
      icon: Home,
      path: '/admin',
      isLink: true,
    },
    {
      id: 'organization',
      label: 'Organization',
      icon: Users,
      items: [
        { id: 'users', label: 'Users', path: '/admin/organization/users' },
        { id: 'permissions', label: 'Permission Groups', path: '/admin/organization/permissions' },
        { id: 'roles', label: 'Roles & Structure', path: '/admin/organization/roles' },
      ]
    },
    {
      id: 'security',
      label: 'Security',
      icon: Shield,
      items: [
        { id: 'account', label: 'Account Security', path: '/admin/security/account' },
        { id: 'access', label: 'Access Control', path: '/admin/security/access' },
        { id: 'sso', label: 'SSO Configuration', path: '/admin/security/sso' },
        { id: 'activity', label: 'Activity Log', path: '/admin/security/activity' },
      ]
    },
    {
      id: 'preferences',
      label: 'Preferences',
      icon: Settings,
      items: [
        { id: 'basic', label: 'Basic Preferences', path: '/admin/preferences/basic' },
        { id: 'contacts', label: 'Contacts', path: '/admin/preferences/contacts' },
        { id: 'accounting', label: 'Accounting', path: '/admin/preferences/accounting' },
        { id: 'partners', label: 'Partners', path: '/admin/preferences/partners' },
        { id: 'integrations', label: 'Integrations', path: '/admin/preferences/integrations' },
      ]
    },
    {
      id: 'project-defaults',
      label: 'Project Defaults',
      icon: Building2,
      items: [
        { id: 'general', label: 'General', path: '/admin/project-defaults/general' },
        { id: 'charges', label: 'Charges', path: '/admin/project-defaults/charges' },
        { id: 'documents', label: 'Documents', path: '/admin/project-defaults/documents' },
      ]
    },
    {
      id: 'fee-schedule',
      label: 'Fee Schedule',
      icon: Building2,
      items: [
        { id: 'default', label: 'Default Schedule', path: '/admin/fee-schedule/default' },
        { id: 'by-type', label: 'By Project Type', path: '/admin/fee-schedule/by-type' },
      ]
    },
    {
      id: 'workflows',
      label: 'Workflows',
      icon: Workflow,
      items: [
        { id: 'types', label: 'Workflow Types', path: '/admin/workflows/types' },
        { id: 'core', label: 'Core Workflows', path: '/admin/workflows/core' },
        { id: 'smart-actions', label: 'Smart Actions', path: '/admin/workflows/smart-actions' },
        { id: 'assignments', label: 'Assignment Groups', path: '/admin/workflows/assignments' },
        { id: 'templates', label: 'Project Templates', path: '/admin/workflows/templates' },
      ]
    },
    {
      id: 'documents',
      label: 'Documents',
      icon: FileText,
      items: [
        { id: 'custom', label: 'Custom Documents', path: '/admin/documents/custom' },
        { id: 'packages', label: 'Document Packages', path: '/admin/documents/packages' },
        { id: 'qr', label: 'QR Packages', path: '/admin/documents/qr' },
        { id: 'stamps', label: 'Document Stamps', path: '/admin/documents/stamps' },
        { id: 'instructions', label: 'Standard Instructions', path: '/admin/documents/instructions' },
      ]
    },
    {
      id: 'reports',
      label: 'Reports',
      icon: BarChart3,
      items: [
        { id: 'packages', label: 'Report Packages', path: '/admin/reports/packages' },
        { id: 'k1', label: 'K-1 Reporting', path: '/admin/reports/k1' },
      ]
    },
  ];

  const isItemActive = (path) => location.pathname === path;
  const isSectionActive = (section) => {
    if (section.path) return location.pathname === section.path;
    return section.items?.some(item => location.pathname === item.path);
  };

  return (
    <div className="w-48 bg-[#1e2a3a] flex flex-col h-full flex-shrink-0">
      {/* Header */}
      <div className="p-3 border-b border-gray-700">
        <button 
          onClick={() => navigate('/')}
          className="flex items-center gap-1 text-xs text-gray-400 hover:text-white mb-2"
        >
          <ChevronLeft className="w-3 h-3" />
          Back to Dashboard
        </button>
        <h2 className="text-white font-semibold text-sm">Admin Settings</h2>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-2">
        {sections.map((section) => {
          if (section.isLink) {
            return (
              <NavLink
                key={section.id}
                to={section.path}
                end
                className={({ isActive }) => cn(
                  "flex items-center gap-2 px-3 py-2 text-xs transition-colors",
                  isActive
                    ? "text-white bg-white/10"
                    : "text-gray-400 hover:text-white hover:bg-white/5"
                )}
              >
                <section.icon className="w-3.5 h-3.5" />
                {section.label}
              </NavLink>
            );
          }

          const isExpanded = expandedSections.includes(section.id);
          const sectionActive = isSectionActive(section);

          return (
            <div key={section.id}>
              <button
                onClick={() => toggleSection(section.id)}
                className={cn(
                  "w-full flex items-center justify-between px-3 py-2 text-xs transition-colors",
                  sectionActive ? "text-white" : "text-gray-400 hover:text-white hover:bg-white/5"
                )}
              >
                <div className="flex items-center gap-2">
                  <section.icon className="w-3.5 h-3.5" />
                  <span>{section.label}</span>
                </div>
                <ChevronDown className={cn(
                  "w-3 h-3 transition-transform",
                  isExpanded ? "" : "-rotate-90"
                )} />
              </button>
              
              {isExpanded && section.items && (
                <div className="bg-black/20">
                  {section.items.map((item) => (
                    <NavLink
                      key={item.id}
                      to={item.path}
                      className={({ isActive }) => cn(
                        "block px-4 py-1.5 text-xs transition-colors pl-9",
                        isActive
                          ? "text-white bg-white/10"
                          : "text-gray-400 hover:text-white hover:bg-white/5"
                      )}
                    >
                      {item.label}
                    </NavLink>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </nav>
    </div>
  );
};

export default AdminSidebar;
