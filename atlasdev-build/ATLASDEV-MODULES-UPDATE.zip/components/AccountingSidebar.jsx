import React from 'react';
import { NavLink, useParams, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, ListChecks, Receipt, FileText, CreditCard, Landmark,
  CheckSquare, Building2, Layers, TrendingUp, Settings, PieChart,
  DollarSign, ArrowLeftRight, Clock, BarChart3
} from 'lucide-react';
import { cn } from '@/lib/utils';

const AccountingSidebar = ({ entity }) => {
  const { entityId } = useParams();
  const location = useLocation();

  const menuSections = [
    {
      title: 'Overview',
      items: [
        { label: 'Dashboard', path: `/accounting/${entityId}`, icon: LayoutDashboard, exact: true },
        { label: 'Entity Details', path: `/accounting/${entityId}/details`, icon: Building2 },
      ]
    },
    {
      title: 'Accounts',
      items: [
        { label: 'Chart of Accounts', path: `/accounting/${entityId}/chart-of-accounts`, icon: ListChecks },
        { label: 'Bank Accounts', path: `/accounting/${entityId}/banking`, icon: Landmark },
        { label: 'Credit Cards', path: `/accounting/${entityId}/credit-cards`, icon: CreditCard },
      ]
    },
    {
      title: 'Transactions',
      items: [
        { label: 'All Transactions', path: `/accounting/${entityId}/transactions`, icon: Receipt },
        { label: 'Journal Entries', path: `/accounting/${entityId}/journal-entries`, icon: FileText },
        { label: 'Reconciliation', path: `/accounting/${entityId}/reconciliation`, icon: CheckSquare },
      ]
    },
    {
      title: 'Payables & Receivables',
      items: [
        { label: 'Invoices', path: `/accounting/${entityId}/invoices`, icon: FileText },
        { label: 'Bills', path: `/accounting/${entityId}/bills`, icon: CreditCard },
        { label: 'Payments', path: `/accounting/${entityId}/payments`, icon: DollarSign },
      ]
    },
    {
      title: 'Intercompany',
      items: [
        { label: 'Intercompany Transactions', path: `/accounting/${entityId}/intercompany`, icon: ArrowLeftRight },
        { label: 'Due To/From', path: `/accounting/${entityId}/due-to-from`, icon: Layers },
      ]
    },
    {
      title: 'Reports',
      items: [
        { label: 'Financial Statements', path: `/accounting/${entityId}/reports`, icon: BarChart3 },
        { label: 'Trial Balance', path: `/accounting/${entityId}/trial-balance`, icon: PieChart },
        { label: 'Cash Flow', path: `/accounting/${entityId}/cash-flow`, icon: TrendingUp },
      ]
    },
    {
      title: 'Settings',
      items: [
        { label: 'Entity Settings', path: `/accounting/${entityId}/settings`, icon: Settings },
        { label: 'Fiscal Year', path: `/accounting/${entityId}/fiscal-year`, icon: Clock },
      ]
    },
  ];

  const getTypeConfig = (type) => ({
    holding: { bg: 'bg-purple-500', label: 'Holding' },
    project: { bg: 'bg-blue-500', label: 'Project SPV' },
    operating: { bg: 'bg-green-500', label: 'Operating' },
  }[type] || { bg: 'bg-gray-500', label: 'Entity' });

  const typeConfig = entity ? getTypeConfig(entity.type) : { bg: 'bg-gray-500', label: 'Loading...' };

  const formatCurrency = (val) => {
    if (!val) return '$0';
    if (val >= 1000000) return `$${(val / 1000000).toFixed(1)}M`;
    if (val >= 1000) return `$${(val / 1000).toFixed(0)}K`;
    return `$${val.toLocaleString()}`;
  };

  return (
    <aside className="w-56 bg-[#1a1a1a] border-r border-gray-800 flex flex-col flex-shrink-0 h-full">
      {/* Entity Header */}
      <div className="p-4 border-b border-gray-800">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 bg-[#047857] rounded-lg flex items-center justify-center">
            <Building2 className="w-5 h-5 text-white" />
          </div>
          <div className="flex-1 min-w-0">
            <h2 className="font-semibold text-white text-sm truncate">{entity?.name || 'Loading...'}</h2>
            <div className="flex items-center gap-2 mt-1">
              <span className={cn("w-2 h-2 rounded-full", typeConfig.bg)} />
              <span className="text-xs text-gray-400">{typeConfig.label}</span>
            </div>
          </div>
        </div>
        {entity && (
          <div className="grid grid-cols-2 gap-2 mt-3">
            <div className="bg-gray-800 rounded p-2">
              <p className="text-xs text-gray-400">Cash</p>
              <p className="text-sm font-semibold text-white">{formatCurrency(entity.cashBalance)}</p>
            </div>
            <div className="bg-gray-800 rounded p-2">
              <p className="text-xs text-gray-400">YTD P&L</p>
              <p className={cn("text-sm font-semibold", 
                (entity.ytdRevenue - entity.ytdExpenses) >= 0 ? 'text-green-400' : 'text-red-400'
              )}>
                {formatCurrency(entity.ytdRevenue - entity.ytdExpenses)}
              </p>
            </div>
          </div>
        )}
      </div>
      
      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto p-2">
        {menuSections.map((section) => (
          <div key={section.title} className="mb-4">
            <p className="px-3 py-1 text-[10px] font-semibold text-gray-500 uppercase tracking-wider">
              {section.title}
            </p>
            {section.items.map((item) => {
              const IconComponent = item.icon;
              const isActive = item.exact 
                ? location.pathname === item.path
                : location.pathname === item.path || location.pathname.startsWith(item.path + '/');
              
              return (
                <NavLink
                  key={item.path}
                  to={item.path}
                  className={cn(
                    "flex items-center gap-2 px-3 py-2 text-sm rounded-md transition-colors",
                    isActive 
                      ? "bg-[#047857] text-white" 
                      : "text-gray-400 hover:bg-gray-800 hover:text-white"
                  )}
                >
                  <IconComponent className="w-4 h-4" />
                  {item.label}
                </NavLink>
              );
            })}
          </div>
        ))}
      </nav>
    </aside>
  );
};

export default AccountingSidebar;
