import React, { useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { 
  ChevronDown, ChevronRight, User, Mail, Bell, Key, Shield, 
  Sliders, GraduationCap, BarChart3, MessageSquare, Search,
  UserCircle, Signature, Calendar, Palette
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';

const sidebarItems = [
  { id: 'profile', label: 'Your Profile', icon: UserCircle, path: '/settings/profile' },
  { id: 'email', label: 'Email', icon: Mail, path: '/settings/email' },
  { id: 'notifications', label: 'Notifications', icon: Bell, path: '/settings/notifications' },
  { id: 'credentials', label: 'Credentials', icon: Key, path: '/settings/credentials' },
  { id: 'security', label: 'Security', icon: Shield, path: '/settings/security' },
  { 
    id: 'preferences', 
    label: 'Preferences', 
    icon: Sliders,
    children: [
      { id: 'signature', label: 'Document Signature', path: '/settings/preferences/signature' },
      { id: 'stamps', label: 'Document Stamps', path: '/settings/preferences/stamps' },
      { id: 'calendar', label: 'Calendar', path: '/settings/preferences/calendar' },
      { id: 'display', label: 'Display Settings', path: '/settings/preferences/display' },
    ]
  },
  { id: 'training', label: 'Training', icon: GraduationCap, path: '/settings/training' },
  { id: 'reports', label: 'Reports', icon: BarChart3, path: '/settings/reports' },
  { id: 'connect', label: 'Connect', icon: MessageSquare, path: '/settings/connect' },
];

const UserSettingsSidebar = () => {
  const location = useLocation();
  const [expandedItems, setExpandedItems] = useState(['preferences']);

  const toggleExpand = (itemId) => {
    setExpandedItems(prev => 
      prev.includes(itemId) ? prev.filter(id => id !== itemId) : [...prev, itemId]
    );
  };

  const isActive = (path) => location.pathname === path;
  const isParentActive = (children) => children?.some(child => location.pathname === child.path);

  return (
    <div className="w-64 bg-[#1a202c] border-r border-gray-700 flex flex-col h-full flex-shrink-0">
      {/* Header */}
      <div className="px-4 py-4 border-b border-gray-700 flex-shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-emerald-600 rounded-full flex items-center justify-center">
            <User className="w-6 h-6 text-white" />
          </div>
          <div>
            <p className="font-semibold text-white">Bryan V.</p>
            <p className="text-xs text-gray-400">bryan@vanrock.com</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-2">
        {sidebarItems.map((item) => {
          const Icon = item.icon;
          const hasChildren = item.children && item.children.length > 0;
          const isExpanded = expandedItems.includes(item.id);
          const isItemActive = item.path ? isActive(item.path) : isParentActive(item.children);

          if (hasChildren) {
            return (
              <div key={item.id} className="mb-1">
                <button 
                  onClick={() => toggleExpand(item.id)} 
                  className={cn(
                    "w-full flex items-center justify-between px-4 py-2.5 text-sm transition-colors",
                    isItemActive ? "bg-gray-700 text-white font-medium" : "text-gray-300 hover:bg-gray-700 hover:text-white"
                  )}
                >
                  <div className="flex items-center gap-3">
                    <Icon className="w-4 h-4 flex-shrink-0" />
                    <span>{item.label}</span>
                  </div>
                  {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                </button>
                {isExpanded && (
                  <div className="ml-4 pl-4 border-l border-gray-600">
                    {item.children.map((child) => (
                      <NavLink
                        key={child.id}
                        to={child.path}
                        className={cn(
                          "flex items-center justify-between px-3 py-2 text-sm transition-colors",
                          isActive(child.path)
                            ? "bg-gray-700 text-white font-medium border-l-2 border-emerald-500 -ml-[1px]"
                            : "text-gray-400 hover:text-white hover:bg-gray-700/50"
                        )}
                      >
                        <span>{child.label}</span>
                      </NavLink>
                    ))}
                  </div>
                )}
              </div>
            );
          }

          return (
            <NavLink
              key={item.id}
              to={item.path}
              className={cn(
                "flex items-center gap-3 px-4 py-2.5 text-sm transition-colors",
                isActive(item.path)
                  ? "bg-gray-700 text-white font-medium border-l-2 border-emerald-500"
                  : "text-gray-300 hover:bg-gray-700 hover:text-white"
              )}
            >
              <Icon className="w-4 h-4 flex-shrink-0" />
              <span>{item.label}</span>
            </NavLink>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="px-4 py-3 border-t border-gray-700 flex-shrink-0">
        <p className="text-xs text-gray-500">User Settings</p>
      </div>
    </div>
  );
};

export default UserSettingsSidebar;
