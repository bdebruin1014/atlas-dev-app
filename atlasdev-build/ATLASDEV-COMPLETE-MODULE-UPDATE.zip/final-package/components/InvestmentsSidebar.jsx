import React from 'react';
import { NavLink, useParams, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, Users, DollarSign, FileText, TrendingUp, 
  Building2, PieChart, Wallet, FileSignature, Settings,
  BarChart3, Calendar, Bell, MessageSquare, Shield
} from 'lucide-react';
import { cn } from '@/lib/utils';

const InvestmentsSidebar = ({ deal }) => {
  const { dealId } = useParams();
  const location = useLocation();

  const menuSections = [
    {
      title: 'Overview',
      items: [
        { label: 'Dashboard', path: `/investments/${dealId}`, icon: LayoutDashboard, exact: true },
        { label: 'Deal Summary', path: `/investments/${dealId}/summary`, icon: Building2 },
      ]
    },
    {
      title: 'Capital',
      items: [
        { label: 'Investors', path: `/investments/${dealId}/investors`, icon: Users },
        { label: 'Subscriptions', path: `/investments/${dealId}/subscriptions`, icon: FileSignature },
        { label: 'Capital Calls', path: `/investments/${dealId}/capital-calls`, icon: Wallet },
        { label: 'Ownership', path: `/investments/${dealId}/ownership`, icon: PieChart },
      ]
    },
    {
      title: 'Financials',
      items: [
        { label: 'Distributions', path: `/investments/${dealId}/distributions`, icon: DollarSign },
        { label: 'Waterfall', path: `/investments/${dealId}/waterfall`, icon: TrendingUp },
        { label: 'Performance', path: `/investments/${dealId}/performance`, icon: BarChart3 },
      ]
    },
    {
      title: 'Documents',
      items: [
        { label: 'Deal Documents', path: `/investments/${dealId}/documents`, icon: FileText },
        { label: 'K-1s', path: `/investments/${dealId}/k1s`, icon: FileText },
        { label: 'Reports', path: `/investments/${dealId}/reports`, icon: BarChart3 },
      ]
    },
    {
      title: 'Communications',
      items: [
        { label: 'Updates', path: `/investments/${dealId}/updates`, icon: MessageSquare },
        { label: 'Notifications', path: `/investments/${dealId}/notifications`, icon: Bell },
      ]
    },
    {
      title: 'Settings',
      items: [
        { label: 'Deal Settings', path: `/investments/${dealId}/settings`, icon: Settings },
        { label: 'Permissions', path: `/investments/${dealId}/permissions`, icon: Shield },
      ]
    },
  ];

  const getStageConfig = (stage) => {
    const configs = {
      raising_capital: { bg: 'bg-blue-500', label: 'Raising Capital' },
      asset_managing: { bg: 'bg-green-500', label: 'Operating' },
      liquidated: { bg: 'bg-purple-500', label: 'Liquidated' },
      archived: { bg: 'bg-gray-500', label: 'Archived' },
    };
    return configs[stage] || configs.archived;
  };

  const stageConfig = deal ? getStageConfig(deal.stage) : { bg: 'bg-gray-500', label: 'Unknown' };

  return (
    <aside className="w-56 bg-[#1a1a1a] border-r border-gray-800 flex flex-col flex-shrink-0 h-full">
      {/* Deal Header */}
      <div className="p-4 border-b border-gray-800">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 bg-[#047857] rounded-lg flex items-center justify-center">
            <Building2 className="w-5 h-5 text-white" />
          </div>
          <div className="flex-1 min-w-0">
            <h2 className="font-semibold text-white text-sm truncate">{deal?.name || 'Loading...'}</h2>
            <div className="flex items-center gap-2 mt-1">
              <span className={cn("w-2 h-2 rounded-full", stageConfig.bg)} />
              <span className="text-xs text-gray-400">{stageConfig.label}</span>
            </div>
          </div>
        </div>
        {deal && (
          <div className="grid grid-cols-2 gap-2 mt-3">
            <div className="bg-gray-800 rounded p-2">
              <p className="text-xs text-gray-400">Raised</p>
              <p className="text-sm font-semibold text-white">${(deal.totalRaised / 1000000).toFixed(1)}M</p>
            </div>
            <div className="bg-gray-800 rounded p-2">
              <p className="text-xs text-gray-400">Investors</p>
              <p className="text-sm font-semibold text-white">{deal.investorCount}</p>
            </div>
          </div>
        )}
      </div>
      
      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto p-2">
        {menuSections.map((section) => (
          <div key={section.title} className="mb-4">
            <p className="px-3 py-1 text-[10px] font-semibold text-gray-500 uppercase tracking-wider">
              {section.title}
            </p>
            {section.items.map((item) => {
              const IconComponent = item.icon;
              const isActive = item.exact 
                ? location.pathname === item.path
                : location.pathname === item.path || location.pathname.startsWith(item.path + '/');
              
              return (
                <NavLink
                  key={item.path}
                  to={item.path}
                  className={cn(
                    "flex items-center gap-2 px-3 py-2 text-sm rounded-md transition-colors",
                    isActive 
                      ? "bg-[#047857] text-white" 
                      : "text-gray-400 hover:bg-gray-800 hover:text-white"
                  )}
                >
                  <IconComponent className="w-4 h-4" />
                  {item.label}
                </NavLink>
              );
            })}
          </div>
        ))}
      </nav>
    </aside>
  );
};

export default InvestmentsSidebar;
