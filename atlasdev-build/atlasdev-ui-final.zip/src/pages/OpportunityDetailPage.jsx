import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { 
  ArrowLeft, Target, MapPin, Calendar, DollarSign, 
  Edit, MoreHorizontal, Building2, User, Phone, Mail,
  CheckCircle2, AlertCircle, Clock
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { cn, formatCurrency, formatDate } from '@/lib/utils';

// Mock opportunity data
const mockOpportunityData = {
  1: {
    id: 1,
    name: 'Highland Park Mixed-Use',
    address: '5800 N Figueroa St',
    city: 'Los Angeles',
    state: 'CA',
    zip: '90042',
    status: 'qualified',
    stage: 'Due Diligence',
    propertyType: 'Mixed-Use',
    askingPrice: 4200000,
    targetOffer: 3850000,
    estRehab: 450000,
    estARV: 5100000,
    createdDate: '2023-10-24',
    dueDate: '2024-02-15',
    source: 'Broker Referral',
    sqft: 12500,
    lotSize: 0.45,
    yearBuilt: 1965,
    units: 8,
    zoning: 'C2-1VL',
    seller: {
      name: 'John Smith',
      company: 'Smith Properties LLC',
      phone: '(555) 123-4567',
      email: 'john@smithproperties.com',
    },
    notes: 'Motivated seller, property has been on market for 6 months. Good value-add opportunity with below-market rents.',
  },
  2: {
    id: 2,
    name: 'Riverside Industrial',
    address: '2100 Commerce Way',
    city: 'Riverside',
    state: 'CA',
    zip: '92507',
    status: 'new',
    stage: 'Initial Review',
    propertyType: 'Industrial',
    askingPrice: 2800000,
    targetOffer: 2500000,
    estRehab: 200000,
    estARV: 3200000,
    createdDate: '2024-01-10',
    source: 'Direct Mail',
    sqft: 25000,
    lotSize: 1.2,
    yearBuilt: 1985,
    units: 1,
    zoning: 'M-1',
    seller: {
      name: 'Maria Garcia',
      company: 'Garcia Holdings',
      phone: '(555) 987-6543',
      email: 'maria@garciaholdings.com',
    },
    notes: 'Response from direct mail campaign. Owner interested in quick close.',
  },
};

const statusConfig = {
  new: { label: 'New', color: 'bg-blue-100 text-blue-800' },
  qualified: { label: 'Qualified', color: 'bg-emerald-100 text-emerald-800' },
  offer_submitted: { label: 'Offer Submitted', color: 'bg-yellow-100 text-yellow-800' },
  under_contract: { label: 'Under Contract', color: 'bg-purple-100 text-purple-800' },
};

const OpportunityDetailPage = () => {
  const { opportunityId, section = 'overview', subsection = 'basic-info' } = useParams();
  
  const opportunity = mockOpportunityData[opportunityId] || mockOpportunityData[1];
  const status = statusConfig[opportunity.status];

  // Render different content based on section/subsection
  const renderContent = () => {
    if (section === 'overview') {
      if (subsection === 'basic-info') {
        return <BasicInfoSection opportunity={opportunity} />;
      }
      if (subsection === 'property-profile') {
        return <PropertyProfileSection opportunity={opportunity} />;
      }
      if (subsection === 'seller-info') {
        return <SellerInfoSection opportunity={opportunity} />;
      }
      if (subsection === 'tasks') {
        return <TasksSection opportunity={opportunity} />;
      }
    }
    if (section === 'analysis') {
      if (subsection === 'deal-analysis') {
        return <DealAnalysisSection opportunity={opportunity} />;
      }
    }
    
    // Default fallback
    return <BasicInfoSection opportunity={opportunity} />;
  };

  return (
    <>
      <Helmet>
        <title>{opportunity.name} | AtlasDev</title>
      </Helmet>

      <div className="flex flex-col h-full bg-[#F7FAFC]">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 px-6 py-4 flex-shrink-0">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link 
                to="/pipeline"
                className="text-gray-500 hover:text-gray-900 flex items-center gap-1 text-sm"
              >
                <ArrowLeft className="w-4 h-4" /> Back to List
              </Link>
              <div className="h-6 w-px bg-gray-200" />
              <h1 className="text-xl font-bold text-gray-900">{opportunity.name}</h1>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm">
                <Edit className="w-4 h-4 mr-2" /> Edit
              </Button>
              <Button variant="outline" size="sm" className="text-red-600 border-red-200 hover:bg-red-50">
                Mark Lost
              </Button>
              <Button size="sm" className="bg-[#2F855A] hover:bg-[#276749]">
                Convert to Project
              </Button>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {/* Status Card */}
          <Card className="mb-6">
            <CardContent className="py-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <Target className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <h2 className="text-lg font-bold text-gray-900">{opportunity.name}</h2>
                    <p className="text-sm text-gray-500 flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      {opportunity.address}, {opportunity.city}, {opportunity.state}
                    </p>
                  </div>
                </div>
                <Badge className={cn('text-sm px-3 py-1', status?.color)}>
                  {status?.label}
                </Badge>
              </div>
            </CardContent>
          </Card>

          {/* Financial Summary */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <DollarSign className="w-5 h-5" />
                Financial Targets
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-4 gap-4">
                <div className="p-3 bg-gray-50 rounded-lg">
                  <p className="text-xs text-gray-500 uppercase mb-1">Asking Price</p>
                  <p className="text-lg font-bold">{formatCurrency(opportunity.askingPrice)}</p>
                </div>
                <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-200">
                  <p className="text-xs text-gray-500 uppercase mb-1">Target Offer</p>
                  <p className="text-lg font-bold text-emerald-600">{formatCurrency(opportunity.targetOffer)}</p>
                </div>
                <div className="p-3 bg-gray-50 rounded-lg">
                  <p className="text-xs text-gray-500 uppercase mb-1">Est. Rehab</p>
                  <p className="text-lg font-bold">{formatCurrency(opportunity.estRehab)}</p>
                </div>
                <div className="p-3 bg-gray-50 rounded-lg">
                  <p className="text-xs text-gray-500 uppercase mb-1">Est. ARV</p>
                  <p className="text-lg font-bold">{formatCurrency(opportunity.estARV)}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Dynamic Content Based on Section */}
          {renderContent()}
        </div>
      </div>
    </>
  );
};

// Section Components
const BasicInfoSection = ({ opportunity }) => (
  <Card>
    <CardHeader>
      <CardTitle className="text-base">Opportunity Details</CardTitle>
    </CardHeader>
    <CardContent>
      <div className="grid grid-cols-2 gap-6">
        <div className="space-y-4">
          <div>
            <Label className="text-xs uppercase text-gray-500">Opportunity Name</Label>
            <p className="font-medium">{opportunity.name}</p>
          </div>
          <div>
            <Label className="text-xs uppercase text-gray-500">Address</Label>
            <p className="font-medium">{opportunity.address}</p>
            <p className="text-sm text-gray-500">{opportunity.city}, {opportunity.state} {opportunity.zip}</p>
          </div>
          <div>
            <Label className="text-xs uppercase text-gray-500">Source</Label>
            <p className="font-medium">{opportunity.source}</p>
          </div>
        </div>
        <div className="space-y-4">
          <div>
            <Label className="text-xs uppercase text-gray-500">Property Type</Label>
            <p className="font-medium">{opportunity.propertyType}</p>
          </div>
          <div>
            <Label className="text-xs uppercase text-gray-500">Stage</Label>
            <p className="font-medium">{opportunity.stage}</p>
          </div>
          <div>
            <Label className="text-xs uppercase text-gray-500">Created Date</Label>
            <p className="font-medium">{formatDate(opportunity.createdDate)}</p>
          </div>
        </div>
      </div>
      {opportunity.notes && (
        <div className="mt-6 pt-6 border-t">
          <Label className="text-xs uppercase text-gray-500">Notes</Label>
          <p className="mt-1 text-gray-700">{opportunity.notes}</p>
        </div>
      )}
    </CardContent>
  </Card>
);

const PropertyProfileSection = ({ opportunity }) => (
  <Card>
    <CardHeader>
      <CardTitle className="text-base">Property Profile</CardTitle>
    </CardHeader>
    <CardContent>
      <div className="grid grid-cols-3 gap-6">
        <div>
          <Label className="text-xs uppercase text-gray-500">Square Footage</Label>
          <p className="font-medium">{opportunity.sqft?.toLocaleString()} SF</p>
        </div>
        <div>
          <Label className="text-xs uppercase text-gray-500">Lot Size</Label>
          <p className="font-medium">{opportunity.lotSize} acres</p>
        </div>
        <div>
          <Label className="text-xs uppercase text-gray-500">Year Built</Label>
          <p className="font-medium">{opportunity.yearBuilt}</p>
        </div>
        <div>
          <Label className="text-xs uppercase text-gray-500">Units</Label>
          <p className="font-medium">{opportunity.units}</p>
        </div>
        <div>
          <Label className="text-xs uppercase text-gray-500">Zoning</Label>
          <p className="font-medium">{opportunity.zoning}</p>
        </div>
        <div>
          <Label className="text-xs uppercase text-gray-500">Property Type</Label>
          <p className="font-medium">{opportunity.propertyType}</p>
        </div>
      </div>
    </CardContent>
  </Card>
);

const SellerInfoSection = ({ opportunity }) => (
  <Card>
    <CardHeader>
      <CardTitle className="text-base">Seller Information</CardTitle>
    </CardHeader>
    <CardContent>
      <div className="flex items-start gap-4">
        <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center">
          <User className="w-6 h-6 text-gray-500" />
        </div>
        <div className="space-y-3">
          <div>
            <p className="font-semibold text-gray-900">{opportunity.seller?.name}</p>
            <p className="text-sm text-gray-500">{opportunity.seller?.company}</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-sm">
              <Phone className="w-4 h-4 text-gray-400" />
              <span>{opportunity.seller?.phone}</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <Mail className="w-4 h-4 text-gray-400" />
              <span>{opportunity.seller?.email}</span>
            </div>
          </div>
        </div>
      </div>
    </CardContent>
  </Card>
);

const TasksSection = ({ opportunity }) => (
  <Card>
    <CardHeader className="flex flex-row items-center justify-between">
      <CardTitle className="text-base">Tasks</CardTitle>
      <Button size="sm">Add Task</Button>
    </CardHeader>
    <CardContent>
      <div className="space-y-3">
        {[
          { task: 'Schedule property tour', status: 'complete', due: '2024-01-15' },
          { task: 'Request financials from seller', status: 'complete', due: '2024-01-18' },
          { task: 'Run comparable analysis', status: 'pending', due: '2024-01-25' },
          { task: 'Submit initial offer', status: 'pending', due: '2024-02-01' },
        ].map((item, idx) => (
          <div key={idx} className="flex items-center justify-between p-3 border rounded-lg">
            <div className="flex items-center gap-3">
              {item.status === 'complete' ? (
                <CheckCircle2 className="w-5 h-5 text-green-500" />
              ) : (
                <Clock className="w-5 h-5 text-gray-400" />
              )}
              <span className={cn(
                "text-sm",
                item.status === 'complete' && "text-gray-400 line-through"
              )}>
                {item.task}
              </span>
            </div>
            <span className="text-xs text-gray-500">{formatDate(item.due)}</span>
          </div>
        ))}
      </div>
    </CardContent>
  </Card>
);

const DealAnalysisSection = ({ opportunity }) => {
  const purchasePrice = opportunity.targetOffer;
  const rehabCost = opportunity.estRehab;
  const arv = opportunity.estARV;
  const totalInvestment = purchasePrice + rehabCost;
  const profit = arv - totalInvestment;
  const roi = ((profit / totalInvestment) * 100).toFixed(1);
  
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">Deal Analysis</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-500">Purchase Price</p>
              <p className="text-xl font-bold">{formatCurrency(purchasePrice)}</p>
            </div>
            <div className="p-4 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-500">Rehab Cost</p>
              <p className="text-xl font-bold">{formatCurrency(rehabCost)}</p>
            </div>
            <div className="p-4 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-500">Total Investment</p>
              <p className="text-xl font-bold">{formatCurrency(totalInvestment)}</p>
            </div>
            <div className="p-4 bg-gray-50 rounded-lg">
              <p className="text-sm text-gray-500">ARV</p>
              <p className="text-xl font-bold">{formatCurrency(arv)}</p>
            </div>
          </div>
          
          <div className="border-t pt-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-emerald-50 rounded-lg border border-emerald-200">
                <p className="text-sm text-gray-500">Estimated Profit</p>
                <p className="text-2xl font-bold text-emerald-600">{formatCurrency(profit)}</p>
              </div>
              <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                <p className="text-sm text-gray-500">ROI</p>
                <p className="text-2xl font-bold text-blue-600">{roi}%</p>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default OpportunityDetailPage;
