import React, { useState } from 'react';
import { NavLink, useParams, useNavigate } from 'react-router-dom';
import { 
  ChevronDown, ChevronLeft, X, Home, FileText, Users, Settings,
  Building2, Hammer, DollarSign, TrendingUp, Calendar, ClipboardList,
  FolderOpen, Calculator, Briefcase, Map, Landmark
} from 'lucide-react';
import { cn } from '@/lib/utils';

const ProjectSidebar = () => {
  const { projectId } = useParams();
  const navigate = useNavigate();
  const [expandedSections, setExpandedSections] = useState(['overview', 'finance']);

  const projectName = "Wellington Ave";

  const toggleSection = (sectionId) => {
    setExpandedSections(prev => 
      prev.includes(sectionId) 
        ? prev.filter(id => id !== sectionId)
        : [...prev, sectionId]
    );
  };

  const sections = [
    {
      id: 'overview',
      label: 'General',
      items: [
        { id: 'basic-info', label: 'Basic Info', path: 'overview/basic-info' },
        { id: 'property', label: 'Properties', path: 'overview/property' },
        { id: 'contacts', label: 'Contacts', path: 'overview/contacts' },
        { id: 'loan', label: 'Loan', path: 'finance/loans' },
        { id: 'earnest', label: 'Earnest & Commissions', path: 'overview/earnest' },
        { id: 'taxes', label: 'Taxes & Prorations', path: 'overview/taxes' },
        { id: 'payoffs', label: 'Payoffs', path: 'overview/payoffs' },
      ]
    },
    {
      id: 'title',
      label: 'Title',
      items: [
        { id: 'title-info', label: 'Title Information', path: 'title/info' },
        { id: 'title-search', label: 'Title Search', path: 'title/search' },
        { id: 'exceptions', label: 'Exceptions', path: 'title/exceptions' },
      ]
    },
    {
      id: 'closing',
      label: 'CLOSING',
      isSectionHeader: true,
    },
    {
      id: 'charges',
      label: 'Charges',
      items: [
        { id: 'buyer-charges', label: 'Buyer Charges', path: 'closing/buyer-charges' },
        { id: 'seller-charges', label: 'Seller Charges', path: 'closing/seller-charges' },
      ]
    },
    {
      id: 'disclosures',
      label: 'Disclosures',
      items: [
        { id: 'buyer-disclosure', label: 'Buyer Disclosure', path: 'closing/buyer-disclosure' },
        { id: 'seller-disclosure', label: 'Seller Disclosure', path: 'closing/seller-disclosure' },
      ]
    },
    {
      id: 'proceeds',
      label: 'Proceeds',
      items: [
        { id: 'buyer-proceeds', label: 'Buyer Proceeds', path: 'closing/buyer-proceeds' },
        { id: 'seller-proceeds', label: 'Seller Proceeds', path: 'closing/seller-proceeds' },
      ]
    },
    {
      id: 'tasks',
      label: 'TASKS',
      isSectionHeader: true,
    },
    {
      id: 'documents',
      label: 'Documents',
      path: 'documents',
      icon: FileText,
      isLink: true,
    },
    {
      id: 'accounting',
      label: 'Accounting',
      path: 'accounting',
      icon: Calculator,
      isLink: true,
    },
    {
      id: 'integrations',
      label: 'INTEGRATIONS',
      isSectionHeader: true,
    },
    {
      id: 'connect',
      label: 'Connect',
      path: 'connect',
      icon: Briefcase,
      isLink: true,
      badge: '1',
    },
  ];

  const NavItem = ({ item, basePath }) => {
    const isActive = location.pathname.includes(item.path);
    return (
      <NavLink
        to={`/project/${projectId}/${item.path}`}
        className={cn(
          "block px-4 py-1.5 text-xs transition-colors",
          isActive
            ? "text-white bg-white/10"
            : "text-gray-400 hover:text-white hover:bg-white/5"
        )}
      >
        {item.label}
      </NavLink>
    );
  };

  return (
    <div className="w-44 bg-[#1e2a3a] flex flex-col h-full flex-shrink-0">
      {/* Header */}
      <div className="p-3 border-b border-gray-700">
        <button 
          onClick={() => navigate('/projects')}
          className="flex items-center gap-1 text-xs text-gray-400 hover:text-white mb-2"
        >
          <ChevronLeft className="w-3 h-3" />
          Back to Projects
        </button>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-white font-medium text-sm truncate">{projectName}</span>
          </div>
          <button className="text-gray-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-2">
        {sections.map((section) => {
          if (section.isSectionHeader) {
            return (
              <div key={section.id} className="px-3 pt-4 pb-1">
                <span className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider">
                  {section.label}
                </span>
              </div>
            );
          }

          if (section.isLink) {
            const isActive = location.pathname.includes(section.path);
            return (
              <NavLink
                key={section.id}
                to={`/project/${projectId}/${section.path}`}
                className={cn(
                  "flex items-center justify-between px-3 py-2 text-xs transition-colors",
                  isActive
                    ? "text-white bg-white/10"
                    : "text-gray-400 hover:text-white hover:bg-white/5"
                )}
              >
                <div className="flex items-center gap-2">
                  {section.icon && <section.icon className="w-3.5 h-3.5" />}
                  {section.label}
                </div>
                {section.badge && (
                  <span className="bg-[#047857] text-white text-[10px] px-1.5 py-0.5 rounded">
                    {section.badge}
                  </span>
                )}
              </NavLink>
            );
          }

          const isExpanded = expandedSections.includes(section.id);

          return (
            <div key={section.id}>
              <button
                onClick={() => toggleSection(section.id)}
                className="w-full flex items-center justify-between px-3 py-2 text-xs text-gray-300 hover:text-white hover:bg-white/5 transition-colors"
              >
                <span>{section.label}</span>
                <ChevronDown className={cn(
                  "w-3 h-3 transition-transform",
                  isExpanded ? "" : "-rotate-90"
                )} />
              </button>
              
              {isExpanded && section.items && (
                <div className="bg-black/20">
                  {section.items.map((item) => (
                    <NavItem key={item.id} item={item} basePath={`/project/${projectId}`} />
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </nav>

      {/* Preview Section */}
      <div className="border-t border-gray-700 p-2">
        <div className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider px-2 py-1">
          PREVIEW
        </div>
        <NavLink
          to={`/project/${projectId}/preview/closing-disclosure`}
          className="block px-3 py-1.5 text-xs text-gray-400 hover:text-white hover:bg-white/5"
        >
          Closing Disclosure
        </NavLink>
        <NavLink
          to={`/project/${projectId}/preview/settlement-statement`}
          className="block px-3 py-1.5 text-xs text-gray-400 hover:text-white hover:bg-white/5"
        >
          Settlement Statement
        </NavLink>
      </div>
    </div>
  );
};

export default ProjectSidebar;
