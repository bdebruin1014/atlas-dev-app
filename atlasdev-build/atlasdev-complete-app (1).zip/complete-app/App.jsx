import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, Outlet } from 'react-router-dom';

// Layout Components
import TopNavigation from '@/components/TopNavigation';
import ProjectSidebar from '@/components/ProjectSidebar';
import OpportunitySidebar from '@/components/OpportunitySidebar';
import EntityAccountingSidebar from '@/components/EntityAccountingSidebar';
import AdminSidebar from '@/components/AdminSidebar';

// Core Pages
import HomePage from '@/pages/HomePage';
import ProjectsListPage from '@/pages/ProjectsListPage';
import ProjectDetailPage from '@/pages/ProjectDetailPage';
import PipelineListPage from '@/pages/PipelineListPage';
import OpportunityDetailPage from '@/pages/OpportunityDetailPage';
import CalendarPage from '@/pages/CalendarPage';
import SettingsPage from '@/pages/SettingsPage';

// Operations Pages
import GlobalTasksPage from '@/pages/operations/GlobalTasksPage';
import TaskTemplatesPage from '@/pages/operations/TaskTemplatesPage';
import MilestoneTemplatesPage from '@/pages/operations/MilestoneTemplatesPage';
import OperationsReportsPage from '@/pages/operations/OperationsReportsPage';
import ProductLibraryPage from '@/pages/operations/ProductLibraryPage';

// Investor Pages
import InvestorContactsPage from '@/pages/investors/InvestorContactsPage';
import InvestmentsPage from '@/pages/investors/InvestmentsPage';
import CapitalRaisingPage from '@/pages/investors/CapitalRaisingPage';

// Accounting Pages
import AccountingEntitiesListPage from '@/pages/accounting/AccountingEntitiesListPage';
import EntityAccountingDashboard from '@/pages/accounting/EntityAccountingDashboard';
import BankAccountsPage from '@/pages/accounting/BankAccountsPage';
import BankAccountRegisterPage from '@/pages/accounting/BankAccountRegisterPage';
import ReconciliationPage from '@/pages/accounting/ReconciliationPage';
import DepositsPage from '@/pages/accounting/DepositsPage';
import WireTrackingPage from '@/pages/accounting/WireTrackingPage';
import BillsPage from '@/pages/accounting/BillsPage';
import PaymentsPage from '@/pages/accounting/PaymentsPage';
import InvoicesPage from '@/pages/accounting/InvoicesPage';
import JournalEntriesPage from '@/pages/accounting/JournalEntriesPage';
import CapitalAccountsPage from '@/pages/accounting/CapitalAccountsPage';
import DistributionsPage from '@/pages/accounting/DistributionsPage';
import K1DocumentsPage from '@/pages/accounting/K1DocumentsPage';
import FinancialReportsPage from '@/pages/accounting/FinancialReportsPage';
import TrialBalancePage from '@/pages/accounting/TrialBalancePage';
import ChartOfAccountsPage from '@/pages/accounting/ChartOfAccountsPage';

// Admin Pages - Overview
import AdminOverviewPage from '@/pages/admin/AdminOverviewPage';

// Admin Pages - Organization
import UsersPage from '@/pages/admin/UsersPage';
import PermissionGroupsPage from '@/pages/admin/PermissionGroupsPage';
import RolesStructurePage from '@/pages/admin/RolesStructurePage';

// Admin Pages - Security
import AccountSecurityPage from '@/pages/admin/AccountSecurityPage';
import AccessControlPage from '@/pages/admin/AccessControlPage';
import SSOPage from '@/pages/admin/SSOPage';
import ActivityLogPage from '@/pages/admin/ActivityLogPage';

// Admin Pages - Preferences
import BasicPreferencesPage from '@/pages/admin/BasicPreferencesPage';
import ContactsPreferencesPage from '@/pages/admin/ContactsPreferencesPage';
import AccountingPreferencesPage from '@/pages/admin/AccountingPreferencesPage';
import PartnersPreferencesPage from '@/pages/admin/PartnersPreferencesPage';
import IntegrationsPreferencesPage from '@/pages/admin/IntegrationsPreferencesPage';

// Admin Pages - Project Defaults
import ProjectDefaultsGeneralPage from '@/pages/admin/ProjectDefaultsGeneralPage';
import ProjectDefaultsChargesPage from '@/pages/admin/ProjectDefaultsChargesPage';
import ProjectDefaultsDocumentsPage from '@/pages/admin/ProjectDefaultsDocumentsPage';

// Admin Pages - Fee Schedule
import FeeScheduleDefaultPage from '@/pages/admin/FeeScheduleDefaultPage';
import FeeScheduleByTypePage from '@/pages/admin/FeeScheduleByTypePage';

// Admin Pages - Workflows
import WorkflowTypesPage from '@/pages/admin/WorkflowsPage';
import CoreWorkflowsPage from '@/pages/admin/CoreWorkflowsPage';
import SmartActionsPage from '@/pages/admin/SmartActionsPage';
import AssignmentGroupsPage from '@/pages/admin/AssignmentGroupsPage';
import ProjectTemplatesPage from '@/pages/admin/ProjectTemplatesPage';

// Admin Pages - Documents
import CustomDocumentsPage from '@/pages/admin/CustomDocumentsPage';
import DocumentPackagesPage from '@/pages/admin/DocumentPackagesPage';
import QRPackagesPage from '@/pages/admin/QRPackagesPage';
import DocumentStampsPage from '@/pages/admin/DocumentStampsPage';
import StandardInstructionsPage from '@/pages/admin/StandardInstructionsPage';

// Admin Pages - Reports
import ReportPackagesPage from '@/pages/admin/ReportPackagesPage';
import K1ReportingPage from '@/pages/admin/K1ReportingPage';

// Main Layout with Top Navigation
const MainLayout = () => (
  <div className="flex flex-col h-screen">
    <TopNavigation />
    <main className="flex-1 overflow-hidden">
      <Outlet />
    </main>
  </div>
);

// Project Layout with Dark Sidebar
const ProjectLayout = () => (
  <div className="flex h-full">
    <ProjectSidebar />
    <div className="flex-1 overflow-hidden">
      <Outlet />
    </div>
  </div>
);

// Opportunity Layout with Dark Sidebar
const OpportunityLayout = () => (
  <div className="flex h-full">
    <OpportunitySidebar />
    <div className="flex-1 overflow-hidden">
      <Outlet />
    </div>
  </div>
);

// Entity Accounting Layout with Dark Sidebar
const EntityAccountingLayout = () => (
  <div className="flex h-full">
    <EntityAccountingSidebar />
    <div className="flex-1 overflow-hidden">
      <Outlet />
    </div>
  </div>
);

// Admin Layout with Dark Sidebar
const AdminLayout = () => (
  <div className="flex h-full">
    <AdminSidebar />
    <div className="flex-1 overflow-hidden">
      <Outlet />
    </div>
  </div>
);

function App() {
  return (
    <Router>
      <Routes>
        <Route element={<MainLayout />}>
          {/* Home */}
          <Route path="/" element={<HomePage />} />
          
          {/* Calendar */}
          <Route path="/calendar" element={<CalendarPage />} />
          
          {/* Operations */}
          <Route path="/operations/tasks" element={<GlobalTasksPage />} />
          <Route path="/operations/task-templates" element={<TaskTemplatesPage />} />
          <Route path="/operations/milestone-templates" element={<MilestoneTemplatesPage />} />
          <Route path="/operations/reports" element={<OperationsReportsPage />} />
          <Route path="/operations/product-library" element={<ProductLibraryPage />} />
          
          {/* Projects List */}
          <Route path="/projects" element={<ProjectsListPage />} />
          
          {/* Project Detail with Dark Sidebar */}
          <Route path="/project/:projectId" element={<ProjectLayout />}>
            <Route index element={<Navigate to="overview/basic-info" replace />} />
            <Route path=":module" element={<ProjectDetailPage />} />
            <Route path=":module/:section" element={<ProjectDetailPage />} />
          </Route>
          
          {/* Pipeline / Opportunities List */}
          <Route path="/pipeline" element={<PipelineListPage />} />
          
          {/* Opportunity Detail with Dark Sidebar */}
          <Route path="/pipeline/:opportunityId" element={<OpportunityLayout />}>
            <Route index element={<Navigate to="overview/basic-info" replace />} />
            <Route path=":module" element={<OpportunityDetailPage />} />
            <Route path=":module/:section" element={<OpportunityDetailPage />} />
          </Route>
          
          {/* Investors */}
          <Route path="/investors" element={<Navigate to="/investors/contacts" replace />} />
          <Route path="/investors/contacts" element={<InvestorContactsPage />} />
          <Route path="/investors/investments" element={<InvestmentsPage />} />
          <Route path="/investors/capital-raising" element={<CapitalRaisingPage />} />
          
          {/* Accounting - Entities List (main entry point) */}
          <Route path="/accounting" element={<Navigate to="/accounting/entities" replace />} />
          <Route path="/accounting/entities" element={<AccountingEntitiesListPage />} />
          
          {/* Entity Accounting Detail with Dark Sidebar */}
          <Route path="/accounting/entities/:entityId" element={<EntityAccountingLayout />}>
            <Route index element={<EntityAccountingDashboard />} />
            <Route path="bank-accounts" element={<BankAccountsPage />} />
            <Route path="register" element={<BankAccountRegisterPage />} />
            <Route path="reconciliation" element={<ReconciliationPage />} />
            <Route path="deposits" element={<DepositsPage />} />
            <Route path="wire-tracking" element={<WireTrackingPage />} />
            <Route path="bills" element={<BillsPage />} />
            <Route path="payments" element={<PaymentsPage />} />
            <Route path="invoices" element={<InvoicesPage />} />
            <Route path="journal-entries" element={<JournalEntriesPage />} />
            <Route path="capital" element={<CapitalAccountsPage />} />
            <Route path="distributions" element={<DistributionsPage />} />
            <Route path="k1-documents" element={<K1DocumentsPage />} />
            <Route path="reports" element={<FinancialReportsPage />} />
            <Route path="trial-balance" element={<TrialBalancePage />} />
            <Route path="chart-of-accounts" element={<ChartOfAccountsPage />} />
          </Route>
          
          {/* Admin with Dark Sidebar */}
          <Route path="/admin" element={<AdminLayout />}>
            <Route index element={<AdminOverviewPage />} />
            
            {/* Organization */}
            <Route path="organization/users" element={<UsersPage />} />
            <Route path="organization/permissions" element={<PermissionGroupsPage />} />
            <Route path="organization/roles" element={<RolesStructurePage />} />
            
            {/* Security */}
            <Route path="security/account" element={<AccountSecurityPage />} />
            <Route path="security/access" element={<AccessControlPage />} />
            <Route path="security/sso" element={<SSOPage />} />
            <Route path="security/activity" element={<ActivityLogPage />} />
            
            {/* Preferences */}
            <Route path="preferences/basic" element={<BasicPreferencesPage />} />
            <Route path="preferences/contacts" element={<ContactsPreferencesPage />} />
            <Route path="preferences/accounting" element={<AccountingPreferencesPage />} />
            <Route path="preferences/partners" element={<PartnersPreferencesPage />} />
            <Route path="preferences/integrations" element={<IntegrationsPreferencesPage />} />
            
            {/* Project Defaults */}
            <Route path="project-defaults/general" element={<ProjectDefaultsGeneralPage />} />
            <Route path="project-defaults/charges" element={<ProjectDefaultsChargesPage />} />
            <Route path="project-defaults/documents" element={<ProjectDefaultsDocumentsPage />} />
            
            {/* Fee Schedule */}
            <Route path="fee-schedule/default" element={<FeeScheduleDefaultPage />} />
            <Route path="fee-schedule/by-type" element={<FeeScheduleByTypePage />} />
            
            {/* Workflows */}
            <Route path="workflows/types" element={<WorkflowTypesPage />} />
            <Route path="workflows/core" element={<CoreWorkflowsPage />} />
            <Route path="workflows/smart-actions" element={<SmartActionsPage />} />
            <Route path="workflows/assignments" element={<AssignmentGroupsPage />} />
            <Route path="workflows/templates" element={<ProjectTemplatesPage />} />
            
            {/* Documents */}
            <Route path="documents/custom" element={<CustomDocumentsPage />} />
            <Route path="documents/packages" element={<DocumentPackagesPage />} />
            <Route path="documents/qr" element={<QRPackagesPage />} />
            <Route path="documents/stamps" element={<DocumentStampsPage />} />
            <Route path="documents/instructions" element={<StandardInstructionsPage />} />
            
            {/* Reports */}
            <Route path="reports/packages" element={<ReportPackagesPage />} />
            <Route path="reports/k1" element={<K1ReportingPage />} />
          </Route>
          
          {/* Settings */}
          <Route path="/settings" element={<SettingsPage />} />
          <Route path="/settings/profile" element={<SettingsPage />} />
          
          {/* Catch all */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Route>
      </Routes>
    </Router>
  );
}

export default App;
