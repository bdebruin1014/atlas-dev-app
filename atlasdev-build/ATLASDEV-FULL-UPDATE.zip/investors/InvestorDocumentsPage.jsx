import React, { useState } from 'react';
import { 
  Plus, Search, Filter, Download, Upload, MoreVertical, FileText, 
  Eye, Send, CheckCircle, Clock, AlertCircle, Folder, File, 
  FileSignature, X, ChevronRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';

const InvestorDocumentsPage = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [dealFilter, setDealFilter] = useState('all');

  const documents = [
    {
      id: 'doc-001',
      name: 'Highland Park Lofts - PPM',
      type: 'ppm',
      deal: 'Highland Park Lofts',
      dealId: 'deal-001',
      uploadedAt: '2024-11-15',
      uploadedBy: 'Bryan de Bruin',
      fileSize: '2.4 MB',
      status: 'active',
      signatureRequired: false,
      signatureCount: 0,
      signedCount: 0,
    },
    {
      id: 'doc-002',
      name: 'Highland Park Lofts - Subscription Agreement',
      type: 'subscription_agreement',
      deal: 'Highland Park Lofts',
      dealId: 'deal-001',
      uploadedAt: '2024-11-15',
      uploadedBy: 'Bryan de Bruin',
      fileSize: '856 KB',
      status: 'active',
      signatureRequired: true,
      signatureCount: 12,
      signedCount: 10,
    },
    {
      id: 'doc-003',
      name: 'Highland Park Lofts - Operating Agreement',
      type: 'operating_agreement',
      deal: 'Highland Park Lofts',
      dealId: 'deal-001',
      uploadedAt: '2024-11-15',
      uploadedBy: 'Bryan de Bruin',
      fileSize: '1.2 MB',
      status: 'active',
      signatureRequired: true,
      signatureCount: 12,
      signedCount: 12,
    },
    {
      id: 'doc-004',
      name: 'Riverside Commons - K-1 (2023)',
      type: 'k1',
      deal: 'Riverside Commons',
      dealId: 'deal-002',
      uploadedAt: '2024-03-01',
      uploadedBy: 'System',
      fileSize: '324 KB',
      status: 'active',
      signatureRequired: false,
      investor: 'All Investors',
      taxYear: 2023,
    },
    {
      id: 'doc-005',
      name: 'Q4 2024 Investor Report',
      type: 'investor_report',
      deal: 'Riverside Commons',
      dealId: 'deal-002',
      uploadedAt: '2025-01-05',
      uploadedBy: 'Bryan de Bruin',
      fileSize: '1.8 MB',
      status: 'active',
      signatureRequired: false,
    },
    {
      id: 'doc-006',
      name: 'Capital Call Notice #1',
      type: 'capital_call_notice',
      deal: 'Cedar Mill Phase 2',
      dealId: 'deal-003',
      uploadedAt: '2024-12-20',
      uploadedBy: 'Bryan de Bruin',
      fileSize: '245 KB',
      status: 'active',
      signatureRequired: false,
    },
  ];

  const documentTypes = [
    { value: 'all', label: 'All Types' },
    { value: 'ppm', label: 'PPM' },
    { value: 'subscription_agreement', label: 'Subscription Agreement' },
    { value: 'operating_agreement', label: 'Operating Agreement' },
    { value: 'k1', label: 'K-1' },
    { value: 'investor_report', label: 'Investor Report' },
    { value: 'distribution_notice', label: 'Distribution Notice' },
    { value: 'capital_call_notice', label: 'Capital Call Notice' },
    { value: 'due_diligence', label: 'Due Diligence' },
    { value: 'marketing_material', label: 'Marketing' },
  ];

  const deals = [
    { value: 'all', label: 'All Deals' },
    { value: 'deal-001', label: 'Highland Park Lofts' },
    { value: 'deal-002', label: 'Riverside Commons' },
    { value: 'deal-003', label: 'Cedar Mill Phase 2' },
  ];

  const getTypeConfig = (type) => {
    const configs = {
      ppm: { bg: 'bg-blue-100', text: 'text-blue-700', label: 'PPM', icon: FileText },
      subscription_agreement: { bg: 'bg-purple-100', text: 'text-purple-700', label: 'Subscription', icon: FileSignature },
      operating_agreement: { bg: 'bg-green-100', text: 'text-green-700', label: 'Operating Agreement', icon: File },
      k1: { bg: 'bg-amber-100', text: 'text-amber-700', label: 'K-1', icon: FileText },
      investor_report: { bg: 'bg-teal-100', text: 'text-teal-700', label: 'Report', icon: FileText },
      distribution_notice: { bg: 'bg-emerald-100', text: 'text-emerald-700', label: 'Distribution', icon: FileText },
      capital_call_notice: { bg: 'bg-red-100', text: 'text-red-700', label: 'Capital Call', icon: FileText },
      due_diligence: { bg: 'bg-gray-100', text: 'text-gray-700', label: 'Due Diligence', icon: Folder },
      marketing_material: { bg: 'bg-pink-100', text: 'text-pink-700', label: 'Marketing', icon: FileText },
    };
    return configs[type] || { bg: 'bg-gray-100', text: 'text-gray-700', label: type, icon: File };
  };

  const stats = {
    totalDocuments: documents.length,
    pendingSignatures: documents.filter(d => d.signatureRequired && d.signedCount < d.signatureCount).length,
    k1Documents: documents.filter(d => d.type === 'k1').length,
  };

  const filteredDocuments = documents.filter(doc => {
    if (typeFilter !== 'all' && doc.type !== typeFilter) return false;
    if (dealFilter !== 'all' && doc.dealId !== dealFilter) return false;
    if (searchQuery && !doc.name.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    return true;
  });

  // Group documents by deal
  const groupedDocuments = filteredDocuments.reduce((acc, doc) => {
    if (!acc[doc.deal]) acc[doc.deal] = [];
    acc[doc.deal].push(doc);
    return acc;
  }, {});

  return (
    <div className="p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">Investor Documents</h1>
          <p className="text-sm text-gray-500">Manage PPMs, subscription agreements, K-1s, and investor communications</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline"><Send className="w-4 h-4 mr-2" />Send for Signature</Button>
          <Button className="bg-[#047857] hover:bg-[#065f46]"><Upload className="w-4 h-4 mr-2" />Upload Document</Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        <div className="bg-white border rounded-lg p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center"><FileText className="w-5 h-5 text-blue-600" /></div>
            <div><p className="text-2xl font-bold">{stats.totalDocuments}</p><p className="text-sm text-gray-500">Total Documents</p></div>
          </div>
        </div>
        <div className="bg-white border rounded-lg p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-amber-100 rounded-lg flex items-center justify-center"><Clock className="w-5 h-5 text-amber-600" /></div>
            <div><p className="text-2xl font-bold">{stats.pendingSignatures}</p><p className="text-sm text-gray-500">Pending Signatures</p></div>
          </div>
        </div>
        <div className="bg-white border rounded-lg p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center"><CheckCircle className="w-5 h-5 text-green-600" /></div>
            <div><p className="text-2xl font-bold">{documents.filter(d => d.signatureRequired && d.signedCount === d.signatureCount).length}</p><p className="text-sm text-gray-500">Fully Executed</p></div>
          </div>
        </div>
        <div className="bg-white border rounded-lg p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center"><FileText className="w-5 h-5 text-purple-600" /></div>
            <div><p className="text-2xl font-bold">{stats.k1Documents}</p><p className="text-sm text-gray-500">K-1 Documents</p></div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-4 mb-6">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input placeholder="Search documents..." className="pl-9" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />
        </div>
        <select value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)} className="border rounded-md px-3 py-2 text-sm">
          {documentTypes.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
        </select>
        <select value={dealFilter} onChange={(e) => setDealFilter(e.target.value)} className="border rounded-md px-3 py-2 text-sm">
          {deals.map(d => <option key={d.value} value={d.value}>{d.label}</option>)}
        </select>
        <Button variant="outline"><Download className="w-4 h-4 mr-2" />Export List</Button>
      </div>

      {/* Documents grouped by deal */}
      <div className="space-y-6">
        {Object.entries(groupedDocuments).map(([dealName, docs]) => (
          <div key={dealName} className="bg-white border rounded-lg overflow-hidden">
            <div className="px-4 py-3 bg-gray-50 border-b flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Folder className="w-4 h-4 text-gray-500" />
                <span className="font-medium">{dealName}</span>
                <span className="text-xs text-gray-500">({docs.length} documents)</span>
              </div>
            </div>
            <div className="divide-y">
              {docs.map(doc => {
                const typeConfig = getTypeConfig(doc.type);
                const TypeIcon = typeConfig.icon;
                return (
                  <div key={doc.id} className="p-4 flex items-center justify-between hover:bg-gray-50">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-gray-100 rounded-lg flex items-center justify-center">
                        <TypeIcon className="w-5 h-5 text-gray-500" />
                      </div>
                      <div>
                        <p className="font-medium">{doc.name}</p>
                        <div className="flex items-center gap-3 mt-1">
                          <span className={cn("px-2 py-0.5 rounded text-xs font-medium", typeConfig.bg, typeConfig.text)}>
                            {typeConfig.label}
                          </span>
                          <span className="text-xs text-gray-500">{doc.fileSize}</span>
                          <span className="text-xs text-gray-500">Uploaded {doc.uploadedAt}</span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      {doc.signatureRequired && (
                        <div className="flex items-center gap-2 text-sm">
                          {doc.signedCount === doc.signatureCount ? (
                            <span className="flex items-center gap-1 text-green-600">
                              <CheckCircle className="w-4 h-4" />
                              {doc.signedCount}/{doc.signatureCount} Signed
                            </span>
                          ) : (
                            <span className="flex items-center gap-1 text-amber-600">
                              <Clock className="w-4 h-4" />
                              {doc.signedCount}/{doc.signatureCount} Signed
                            </span>
                          )}
                        </div>
                      )}
                      <div className="flex items-center gap-1">
                        <Button variant="ghost" size="sm"><Eye className="w-4 h-4" /></Button>
                        <Button variant="ghost" size="sm"><Download className="w-4 h-4" /></Button>
                        <Button variant="ghost" size="sm"><MoreVertical className="w-4 h-4" /></Button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Empty State */}
      {Object.keys(groupedDocuments).length === 0 && (
        <div className="text-center py-12 bg-white border rounded-lg">
          <FileText className="w-12 h-12 mx-auto text-gray-300 mb-4" />
          <h3 className="text-lg font-medium mb-1">No documents found</h3>
          <p className="text-sm text-gray-500 mb-4">Upload your first document to get started</p>
          <Button className="bg-[#047857] hover:bg-[#065f46]"><Upload className="w-4 h-4 mr-2" />Upload Document</Button>
        </div>
      )}
    </div>
  );
};

export default InvestorDocumentsPage;
