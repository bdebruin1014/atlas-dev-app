import React from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { 
  Building2, ChevronDown, Search, Bell, User, Settings, LogOut,
  Home, Target, FolderKanban, Calendar, CheckSquare, Users, 
  Calculator, BarChart3, ListChecks, Milestone, Package, 
  TrendingUp, Briefcase, UserCircle, Shield
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { cn } from '@/lib/utils';

const TopNavigation = () => {
  const navigate = useNavigate();
  const location = useLocation();
  
  const isActive = (path) => location.pathname.startsWith(path);

  return (
    <header className="h-14 bg-[#1a202c] border-b border-gray-700 flex items-center justify-between px-4 flex-shrink-0">
      <div className="flex items-center gap-6">
        <Link to="/" className="flex items-center gap-2">
          <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center">
            <Building2 className="w-5 h-5 text-white" />
          </div>
          <span className="text-white font-bold text-lg">AtlasDev</span>
        </Link>

        <nav className="flex items-center gap-1">
          <Link to="/">
            <Button 
              variant="ghost" 
              className={cn(
                "text-gray-300 hover:text-white hover:bg-gray-700",
                location.pathname === '/' && "bg-gray-700 text-white"
              )}
            >
              <Home className="w-4 h-4 mr-2" />
              Home
            </Button>
          </Link>

          <Link to="/pipeline">
            <Button 
              variant="ghost" 
              className={cn(
                "text-gray-300 hover:text-white hover:bg-gray-700",
                isActive('/pipeline') && "bg-gray-700 text-white"
              )}
            >
              <Target className="w-4 h-4 mr-2" />
              Opportunities
            </Button>
          </Link>

          <Link to="/projects">
            <Button 
              variant="ghost" 
              className={cn(
                "text-gray-300 hover:text-white hover:bg-gray-700",
                (isActive('/project') || location.pathname === '/projects') && "bg-gray-700 text-white"
              )}
            >
              <FolderKanban className="w-4 h-4 mr-2" />
              Projects
            </Button>
          </Link>

          <Link to="/calendar">
            <Button 
              variant="ghost" 
              className={cn(
                "text-gray-300 hover:text-white hover:bg-gray-700",
                isActive('/calendar') && "bg-gray-700 text-white"
              )}
            >
              <Calendar className="w-4 h-4 mr-2" />
              Calendar
            </Button>
          </Link>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                variant="ghost" 
                className={cn(
                  "text-gray-300 hover:text-white hover:bg-gray-700",
                  isActive('/operations') && "bg-gray-700 text-white"
                )}
              >
                <CheckSquare className="w-4 h-4 mr-2" />
                Operations
                <ChevronDown className="w-4 h-4 ml-1" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-48">
              <DropdownMenuItem onClick={() => navigate('/operations/tasks')}>
                <CheckSquare className="w-4 h-4 mr-2" />Tasks
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate('/operations/task-templates')}>
                <ListChecks className="w-4 h-4 mr-2" />Task Templates
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate('/operations/milestone-templates')}>
                <Milestone className="w-4 h-4 mr-2" />Milestone Templates
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => navigate('/operations/reports')}>
                <BarChart3 className="w-4 h-4 mr-2" />Reports
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate('/operations/product-library')}>
                <Package className="w-4 h-4 mr-2" />Product Library
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                variant="ghost" 
                className={cn(
                  "text-gray-300 hover:text-white hover:bg-gray-700",
                  isActive('/investors') && "bg-gray-700 text-white"
                )}
              >
                <Users className="w-4 h-4 mr-2" />
                Investors
                <ChevronDown className="w-4 h-4 ml-1" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-48">
              <DropdownMenuItem onClick={() => navigate('/investors/contacts')}>
                <UserCircle className="w-4 h-4 mr-2" />Investor Contacts
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate('/investors/investments')}>
                <Briefcase className="w-4 h-4 mr-2" />Investments
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate('/investors/capital-raising')}>
                <TrendingUp className="w-4 h-4 mr-2" />Capital Raising
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <Link to="/accounting/entities">
            <Button 
              variant="ghost" 
              className={cn(
                "text-gray-300 hover:text-white hover:bg-gray-700",
                isActive('/accounting') && "bg-gray-700 text-white"
              )}
            >
              <Calculator className="w-4 h-4 mr-2" />
              Accounting
            </Button>
          </Link>

          <Link to="/admin">
            <Button 
              variant="ghost" 
              className={cn(
                "text-gray-300 hover:text-white hover:bg-gray-700",
                isActive('/admin') && "bg-gray-700 text-white"
              )}
            >
              <Settings className="w-4 h-4 mr-2" />
              Admin
            </Button>
          </Link>
        </nav>
      </div>

      <div className="flex items-center gap-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input 
            placeholder="Search..." 
            className="pl-9 w-64 bg-gray-700 border-gray-600 text-white placeholder:text-gray-400 focus:ring-emerald-500"
          />
        </div>

        <Button variant="ghost" size="icon" className="text-gray-300 hover:text-white hover:bg-gray-700 relative">
          <Bell className="w-5 h-5" />
          <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
        </Button>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="text-gray-300 hover:text-white hover:bg-gray-700">
              <div className="w-8 h-8 bg-emerald-600 rounded-full flex items-center justify-center mr-2">
                <User className="w-4 h-4 text-white" />
              </div>
              <span className="text-sm">Bryan</span>
              <ChevronDown className="w-4 h-4 ml-1" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-48">
            <DropdownMenuLabel>My Account</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => navigate('/settings')}>
              <Settings className="w-4 h-4 mr-2" />Settings
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => navigate('/settings/profile')}>
              <User className="w-4 h-4 mr-2" />Profile
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem className="text-red-600">
              <LogOut className="w-4 h-4 mr-2" />Log out
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
};

export default TopNavigation;
