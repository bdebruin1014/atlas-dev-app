// ROUTES.jsx - Example routing configuration for AtlasDev
// Copy relevant imports and routes to your existing router

import { Routes, Route } from 'react-router-dom';

// ============================================
// ACCOUNTING MODULE IMPORTS
// ============================================
import ChartOfAccountsPage from './pages/accounting/ChartOfAccountsPage';
import EntityHierarchyPage from './pages/accounting/EntityHierarchyPage';
import IntercompanyPage from './pages/accounting/IntercompanyPage';
import ConsolidationPage from './pages/accounting/ConsolidationPage';
import ReconciliationPage from './pages/accounting/ReconciliationPage';
import TransactionsPage from './pages/accounting/TransactionsPage';
import BankingPage from './pages/accounting/BankingPage';
import InvoicesPage from './pages/accounting/InvoicesPage';
import BillsPage from './pages/accounting/BillsPage';
import AccountingSettingsPage from './pages/accounting/AccountingSettingsPage';

// ============================================
// PROJECT MODULE IMPORTS
// ============================================
// Acquisition
import DealAnalysisPage from './pages/projects/DealAnalysisPage';
import OffersPage from './pages/projects/OffersPage';
import PropertyDetailsPage from './pages/projects/PropertyDetailsPage';

// Construction
import SchedulePage from './pages/projects/SchedulePage';
import DailyLogsPage from './pages/projects/DailyLogsPage';
import RFIsPage from './pages/projects/RFIsPage';
import SubmittalsPage from './pages/projects/SubmittalsPage';
import ChangeOrdersPage from './pages/projects/ChangeOrdersPage';
import PunchListPage from './pages/projects/PunchListPage';
import InspectionsPage from './pages/projects/InspectionsPage';
import PermitsPage from './pages/projects/PermitsPage';
import PhotosPage from './pages/projects/PhotosPage';
import TimelineGanttPage from './pages/projects/TimelineGanttPage';

// Budget & Finance
import BudgetPage from './pages/projects/BudgetPage';
import ActualsVsBudgetPage from './pages/projects/ActualsVsBudgetPage';
import CashFlowPage from './pages/projects/CashFlowPage';
import ProformaPage from './pages/projects/ProformaPage';
import ProjectLoansPage from './pages/projects/ProjectLoansPage';
import DrawRequestsPage from './pages/projects/DrawRequestsPage';
import CommitmentsPage from './pages/projects/CommitmentsPage';
import BidsPage from './pages/projects/BidsPage';

// Vendors
import VendorsPage from './pages/projects/VendorsPage';
import ContactsPage from './pages/projects/ContactsPage';

// Sales & Marketing
import SalesPage from './pages/projects/SalesPage';
import MarketingPage from './pages/projects/MarketingPage';
import UnitDetailsPage from './pages/projects/UnitDetailsPage';
import ClosingChecklistPage from './pages/projects/ClosingChecklistPage';
import WarrantyPage from './pages/projects/WarrantyPage';

// Investors
import InvestorPortalPage from './pages/projects/InvestorPortalPage';
import ProjectDistributionsPage from './pages/projects/ProjectDistributionsPage';
import EquityCallsPage from './pages/projects/EquityCallsPage';
import TaxDocumentsPage from './pages/projects/TaxDocumentsPage';

// Management
import TasksPage from './pages/projects/TasksPage';
import DocumentsPage from './pages/projects/DocumentsPage';
import NotesPage from './pages/projects/NotesPage';
import MeetingNotesPage from './pages/projects/MeetingNotesPage';
import DashboardWidgetsPage from './pages/projects/DashboardWidgetsPage';
import ProjectOverviewPage from './pages/projects/ProjectOverviewPage';

// Compliance & Reports
import CompliancePage from './pages/projects/CompliancePage';
import InsurancePage from './pages/projects/InsurancePage';
import ReportsPage from './pages/projects/ReportsPage';
import SettingsPage from './pages/projects/SettingsPage';
import ProjectComparisonPage from './pages/projects/ProjectComparisonPage';

// ============================================
// EOS MODULE IMPORTS
// ============================================
import EOSMainPage from './pages/eos/EOSMainPage';
import EOSDetailPage from './pages/eos/EOSDetailPage';

// ============================================
// ROUTES CONFIGURATION
// ============================================

const AppRoutes = () => {
  return (
    <Routes>
      {/* ========== ACCOUNTING ROUTES ========== */}
      <Route path="/accounting">
        <Route path="chart-of-accounts" element={<ChartOfAccountsPage />} />
        <Route path="entities" element={<EntityHierarchyPage />} />
        <Route path="intercompany" element={<IntercompanyPage />} />
        <Route path="consolidation" element={<ConsolidationPage />} />
        <Route path="reconciliation" element={<ReconciliationPage />} />
        <Route path="transactions" element={<TransactionsPage />} />
        <Route path="banking" element={<BankingPage />} />
        <Route path="invoices" element={<InvoicesPage />} />
        <Route path="bills" element={<BillsPage />} />
        <Route path="settings" element={<AccountingSettingsPage />} />
      </Route>

      {/* ========== PROJECT ROUTES ========== */}
      <Route path="/projects/:projectId">
        {/* Overview */}
        <Route path="overview" element={<ProjectOverviewPage />} />
        <Route path="dashboard" element={<DashboardWidgetsPage />} />
        
        {/* Acquisition */}
        <Route path="deal-analysis" element={<DealAnalysisPage />} />
        <Route path="offers" element={<OffersPage />} />
        <Route path="property-details" element={<PropertyDetailsPage />} />
        
        {/* Construction */}
        <Route path="schedule" element={<SchedulePage />} />
        <Route path="daily-logs" element={<DailyLogsPage />} />
        <Route path="rfis" element={<RFIsPage />} />
        <Route path="submittals" element={<SubmittalsPage />} />
        <Route path="change-orders" element={<ChangeOrdersPage />} />
        <Route path="punch-list" element={<PunchListPage />} />
        <Route path="inspections" element={<InspectionsPage />} />
        <Route path="permits" element={<PermitsPage />} />
        <Route path="photos" element={<PhotosPage />} />
        <Route path="timeline" element={<TimelineGanttPage />} />
        
        {/* Budget & Finance */}
        <Route path="budget" element={<BudgetPage />} />
        <Route path="actuals" element={<ActualsVsBudgetPage />} />
        <Route path="cash-flow" element={<CashFlowPage />} />
        <Route path="proforma" element={<ProformaPage />} />
        <Route path="loans" element={<ProjectLoansPage />} />
        <Route path="draws" element={<DrawRequestsPage />} />
        <Route path="commitments" element={<CommitmentsPage />} />
        <Route path="bids" element={<BidsPage />} />
        
        {/* Vendors */}
        <Route path="vendors" element={<VendorsPage />} />
        <Route path="contacts" element={<ContactsPage />} />
        
        {/* Sales */}
        <Route path="sales" element={<SalesPage />} />
        <Route path="marketing" element={<MarketingPage />} />
        <Route path="units" element={<UnitDetailsPage />} />
        <Route path="closing" element={<ClosingChecklistPage />} />
        <Route path="warranty" element={<WarrantyPage />} />
        
        {/* Investors */}
        <Route path="investor-portal" element={<InvestorPortalPage />} />
        <Route path="distributions" element={<ProjectDistributionsPage />} />
        <Route path="equity-calls" element={<EquityCallsPage />} />
        <Route path="tax-documents" element={<TaxDocumentsPage />} />
        
        {/* Management */}
        <Route path="tasks" element={<TasksPage />} />
        <Route path="documents" element={<DocumentsPage />} />
        <Route path="notes" element={<NotesPage />} />
        <Route path="meetings" element={<MeetingNotesPage />} />
        
        {/* Compliance */}
        <Route path="compliance" element={<CompliancePage />} />
        <Route path="insurance" element={<InsurancePage />} />
        <Route path="reports" element={<ReportsPage />} />
        <Route path="settings" element={<SettingsPage />} />
      </Route>
      
      {/* Project Comparison (outside project context) */}
      <Route path="/projects/compare" element={<ProjectComparisonPage />} />

      {/* ========== EOS ROUTES ========== */}
      <Route path="/eos" element={<EOSMainPage />} />
      <Route path="/eos/:programId/*" element={<EOSDetailPage />} />
    </Routes>
  );
};

export default AppRoutes;


// ============================================
// HEADER NAVIGATION EXAMPLE
// ============================================
/*
Add to your header dropdown under "Operations":

<DropdownMenu>
  <DropdownMenuTrigger>Operations</DropdownMenuTrigger>
  <DropdownMenuContent>
    <DropdownMenuItem>
      <Link to="/eos">EOS</Link>
    </DropdownMenuItem>
    ...other items
  </DropdownMenuContent>
</DropdownMenu>
*/
