import React, { useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { 
  ChevronDown, ChevronRight, Settings, LayoutDashboard, Building2, 
  Shield, Sliders, Users, Lock, Eye, KeyRound, ScrollText,
  FileText, GitBranch, ClipboardList, Zap, UsersRound, FileStack,
  Receipt, BarChart3, Search, Package, Stamp, FileSignature
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';

const sidebarItems = [
  { id: 'overview', label: 'Overview', icon: LayoutDashboard, path: '/admin' },
  { 
    id: 'organization', 
    label: 'Organization', 
    icon: Building2,
    children: [
      { id: 'users', label: 'Users', path: '/admin/organization/users', count: 5 },
      { id: 'permission-groups', label: 'Permission Groups', path: '/admin/organization/permissions', count: 4 },
      { id: 'roles-structure', label: 'Roles & Structure', path: '/admin/organization/roles' },
    ]
  },
  { 
    id: 'security', 
    label: 'Security', 
    icon: Shield,
    children: [
      { id: 'account-security', label: 'Account Security', path: '/admin/security/account' },
      { id: 'access-control', label: 'Access Control', path: '/admin/security/access' },
      { id: 'sso', label: 'Single Sign-On', path: '/admin/security/sso' },
      { id: 'activity-log', label: 'Activity Log', path: '/admin/security/activity' },
    ]
  },
  { 
    id: 'preferences', 
    label: 'Preferences', 
    icon: Sliders,
    children: [
      { id: 'basic', label: 'Basic Preferences', path: '/admin/preferences/basic' },
      { id: 'contacts', label: 'Contacts', path: '/admin/preferences/contacts' },
      { id: 'accounting-prefs', label: 'Accounting', path: '/admin/preferences/accounting' },
      { id: 'partners', label: 'Partners', path: '/admin/preferences/partners' },
      { id: 'integrations', label: 'Integrations', path: '/admin/preferences/integrations' },
    ]
  },
  { 
    id: 'project-defaults', 
    label: 'Project Defaults', 
    icon: ClipboardList,
    children: [
      { id: 'general-defaults', label: 'General', path: '/admin/project-defaults/general' },
      { id: 'charges', label: 'Charges', path: '/admin/project-defaults/charges' },
      { id: 'docs-shipping', label: 'Documents & Shipping', path: '/admin/project-defaults/documents' },
    ]
  },
  { 
    id: 'fee-schedule', 
    label: 'Fee Schedule', 
    icon: Receipt,
    children: [
      { id: 'default-fees', label: 'Default Fees', path: '/admin/fee-schedule/default' },
      { id: 'by-type', label: 'By Project Type', path: '/admin/fee-schedule/by-type' },
    ]
  },
  { 
    id: 'workflows', 
    label: 'Workflows', 
    icon: GitBranch,
    children: [
      { id: 'transaction-types', label: 'Transaction Types', path: '/admin/workflows/types', count: 4 },
      { id: 'core-workflows', label: 'Core Workflows', path: '/admin/workflows/core', count: 5 },
      { id: 'smart-actions', label: 'Smart Actions', path: '/admin/workflows/smart-actions', count: 15 },
      { id: 'assignment-groups', label: 'Assignment Groups', path: '/admin/workflows/assignments', count: 3 },
      { id: 'project-templates', label: 'Project Templates', path: '/admin/workflows/templates', count: 8 },
    ]
  },
  { 
    id: 'documents', 
    label: 'Documents', 
    icon: FileText,
    children: [
      { id: 'custom-documents', label: 'Custom Documents', path: '/admin/documents/custom', count: 24 },
      { id: 'document-packages', label: 'Document Packages', path: '/admin/documents/packages', count: 12 },
      { id: 'qr-packages', label: 'QR Packages', path: '/admin/documents/qr' },
      { id: 'document-stamps', label: 'Document Stamps', path: '/admin/documents/stamps' },
      { id: 'instructions', label: 'Standard Instructions', path: '/admin/documents/instructions' },
    ]
  },
  { 
    id: 'reports', 
    label: 'Reports', 
    icon: BarChart3,
    children: [
      { id: 'report-packages', label: 'Report Packages', path: '/admin/reports/packages', count: 6 },
      { id: 'k1-reporting', label: 'K-1 Reporting', path: '/admin/reports/k1' },
    ]
  },
];

const AdminSidebar = () => {
  const location = useLocation();
  const [expandedItems, setExpandedItems] = useState(['organization', 'security', 'preferences', 'workflows']);

  const toggleExpand = (itemId) => {
    setExpandedItems(prev => 
      prev.includes(itemId) ? prev.filter(id => id !== itemId) : [...prev, itemId]
    );
  };

  const isActive = (path) => location.pathname === path;
  const isParentActive = (children) => children?.some(child => location.pathname === child.path);

  return (
    <div className="w-64 bg-[#1a202c] border-r border-gray-700 flex flex-col h-full flex-shrink-0">
      <div className="px-4 py-4 border-b border-gray-700 flex-shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-emerald-600 rounded-lg flex items-center justify-center">
            <Settings className="w-5 h-5 text-white" />
          </div>
          <div>
            <p className="font-semibold text-white">Admin Settings</p>
            <p className="text-xs text-gray-400">System Configuration</p>
          </div>
        </div>
      </div>

      <div className="px-4 py-3 border-b border-gray-700 flex-shrink-0">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <input type="text" placeholder="Search..." className="w-full bg-gray-700 border-0 rounded-lg pl-9 pr-3 py-2 text-sm text-gray-200 placeholder-gray-500 focus:ring-1 focus:ring-emerald-500" />
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto py-2">
        {sidebarItems.map((item) => {
          const Icon = item.icon;
          const hasChildren = item.children && item.children.length > 0;
          const isExpanded = expandedItems.includes(item.id);
          const isItemActive = item.path ? isActive(item.path) : isParentActive(item.children);

          if (hasChildren) {
            return (
              <div key={item.id} className="mb-1">
                <button onClick={() => toggleExpand(item.id)} className={cn("w-full flex items-center justify-between px-4 py-2.5 text-sm transition-colors", isItemActive ? "bg-gray-700 text-white font-medium" : "text-gray-300 hover:bg-gray-700 hover:text-white")}>
                  <div className="flex items-center gap-3"><Icon className="w-4 h-4 flex-shrink-0" /><span>{item.label}</span></div>
                  {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                </button>
                {isExpanded && (
                  <div className="ml-4 pl-4 border-l border-gray-600">
                    {item.children.map((child) => (
                      <NavLink key={child.id} to={child.path} className={cn("flex items-center justify-between px-3 py-2 text-sm transition-colors", isActive(child.path) ? "bg-gray-700 text-white font-medium border-l-2 border-emerald-500 -ml-[1px]" : "text-gray-400 hover:text-white hover:bg-gray-700/50")}>
                        <span>{child.label}</span>
                        {child.count !== undefined && <Badge variant="secondary" className="bg-gray-600 text-gray-200 text-xs px-1.5">{child.count}</Badge>}
                      </NavLink>
                    ))}
                  </div>
                )}
              </div>
            );
          }

          return (
            <NavLink key={item.id} to={item.path} className={cn("flex items-center gap-3 px-4 py-2.5 text-sm transition-colors", isActive(item.path) ? "bg-gray-700 text-white font-medium border-l-2 border-emerald-500" : "text-gray-300 hover:bg-gray-700 hover:text-white")}>
              <Icon className="w-4 h-4 flex-shrink-0" /><span>{item.label}</span>
            </NavLink>
          );
        })}
      </nav>

      <div className="px-4 py-3 border-t border-gray-700 flex-shrink-0">
        <p className="text-xs text-gray-500">AtlasDev v1.0.0</p>
      </div>
    </div>
  );
};

export default AdminSidebar;
