import React from 'react';
import { 
  Users, Shield, Settings, Building2, FileText, Workflow, 
  BarChart3, Database, ChevronRight
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const AdminOverviewPage = () => {
  const navigate = useNavigate();

  const sections = [
    {
      title: 'Organization',
      icon: Users,
      items: [
        { label: 'Users', path: '/admin/organization/users', description: 'Manage user accounts and access' },
        { label: 'Permission Groups', path: '/admin/organization/permissions', description: 'Configure role-based permissions' },
        { label: 'Roles & Structure', path: '/admin/organization/roles', description: 'Define organizational hierarchy' },
      ]
    },
    {
      title: 'Security',
      icon: Shield,
      items: [
        { label: 'Account Security', path: '/admin/security/account', description: 'Password and authentication settings' },
        { label: 'Access Control', path: '/admin/security/access', description: 'IP restrictions and session management' },
        { label: 'SSO Configuration', path: '/admin/security/sso', description: 'Single sign-on settings' },
        { label: 'Activity Log', path: '/admin/security/activity', description: 'View system activity and audit trail' },
      ]
    },
    {
      title: 'Preferences',
      icon: Settings,
      items: [
        { label: 'Basic Preferences', path: '/admin/preferences/basic', description: 'General system settings' },
        { label: 'Contacts Preferences', path: '/admin/preferences/contacts', description: 'Contact management settings' },
        { label: 'Accounting Preferences', path: '/admin/preferences/accounting', description: 'Financial settings and defaults' },
        { label: 'Partners', path: '/admin/preferences/partners', description: 'Partner and vendor settings' },
        { label: 'Integrations', path: '/admin/preferences/integrations', description: 'Third-party integrations' },
      ]
    },
    {
      title: 'Project Configuration',
      icon: Building2,
      items: [
        { label: 'Project Defaults', path: '/admin/project-defaults/general', description: 'Default project settings' },
        { label: 'Fee Schedule', path: '/admin/fee-schedule/default', description: 'Configure fee structures' },
      ]
    },
    {
      title: 'Workflows',
      icon: Workflow,
      items: [
        { label: 'Workflow Types', path: '/admin/workflows/types', description: 'Define workflow categories' },
        { label: 'Core Workflows', path: '/admin/workflows/core', description: 'System workflow templates' },
        { label: 'Smart Actions', path: '/admin/workflows/smart-actions', description: 'Automated actions and triggers' },
        { label: 'Assignment Groups', path: '/admin/workflows/assignments', description: 'Task assignment rules' },
        { label: 'Project Templates', path: '/admin/workflows/templates', description: 'Reusable project templates' },
      ]
    },
    {
      title: 'Documents',
      icon: FileText,
      items: [
        { label: 'Custom Documents', path: '/admin/documents/custom', description: 'Document templates' },
        { label: 'Document Packages', path: '/admin/documents/packages', description: 'Document bundles' },
        { label: 'QR Packages', path: '/admin/documents/qr', description: 'QR code document packages' },
        { label: 'Document Stamps', path: '/admin/documents/stamps', description: 'Digital stamp configurations' },
        { label: 'Standard Instructions', path: '/admin/documents/instructions', description: 'Default document instructions' },
      ]
    },
    {
      title: 'Reports',
      icon: BarChart3,
      items: [
        { label: 'Report Packages', path: '/admin/reports/packages', description: 'Scheduled report bundles' },
        { label: 'K-1 Reporting', path: '/admin/reports/k1', description: 'Investor K-1 configuration' },
      ]
    },
  ];

  return (
    <div className="p-6 bg-gray-50 min-h-full overflow-auto">
      <div className="mb-6">
        <h1 className="text-xl font-semibold text-gray-900">Admin Settings</h1>
        <p className="text-sm text-gray-500">Configure system settings and preferences</p>
      </div>

      <div className="grid grid-cols-2 gap-6">
        {sections.map((section) => (
          <div key={section.title} className="bg-white rounded-lg border border-gray-200 overflow-hidden">
            <div className="px-4 py-3 bg-gray-50 border-b border-gray-200 flex items-center gap-2">
              <section.icon className="w-4 h-4 text-gray-500" />
              <h2 className="text-sm font-semibold text-gray-700">{section.title}</h2>
            </div>
            <div className="divide-y divide-gray-100">
              {section.items.map((item) => (
                <button
                  key={item.path}
                  onClick={() => navigate(item.path)}
                  className="w-full px-4 py-3 flex items-center justify-between hover:bg-gray-50 transition-colors text-left"
                >
                  <div>
                    <p className="text-sm font-medium text-gray-900">{item.label}</p>
                    <p className="text-xs text-gray-500">{item.description}</p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-400" />
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AdminOverviewPage;
