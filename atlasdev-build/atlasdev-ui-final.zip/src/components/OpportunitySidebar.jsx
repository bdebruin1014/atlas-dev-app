import React, { useState } from 'react';
import { NavLink, useParams, useNavigate } from 'react-router-dom';
import { 
  ChevronLeft, ChevronDown, ChevronRight, Target,
  FileText, Building2, Users, CheckSquare, Calculator,
  TrendingUp, Search, DollarSign, FolderOpen, Mail
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';

// Define opportunity modules and their subsections
const opportunityModules = [
  {
    id: 'overview',
    label: 'OVERVIEW',
    sections: [
      { id: 'basic-info', label: 'Basic Info', icon: FileText },
      { id: 'property-profile', label: 'Property Profile', icon: Building2 },
      { id: 'seller-info', label: 'Seller Info', icon: Users },
      { id: 'tasks', label: 'Tasks', icon: CheckSquare },
    ],
  },
  {
    id: 'analysis',
    label: 'PIPELINE ANALYSIS',
    sections: [
      { id: 'deal-analysis', label: 'Deal Analysis', icon: Calculator },
      { id: 'pipeline-tracker', label: 'Pipeline Tracker', icon: TrendingUp },
    ],
  },
  {
    id: 'due-diligence',
    label: 'DUE DILIGENCE',
    sections: [
      { id: 'checklist', label: 'DD Checklist', icon: CheckSquare },
      { id: 'inspections', label: 'Inspections', icon: Search },
      { id: 'financials', label: 'Financials', icon: DollarSign },
    ],
  },
  {
    id: 'documents',
    label: 'DOCUMENTS',
    sections: [
      { id: 'all-documents', label: 'Documents', icon: FolderOpen },
      { id: 'email', label: 'Email', icon: Mail },
    ],
  },
];

// Mock opportunity data
const mockOpportunityData = {
  1: { name: 'Highland Park Mixed-Use', status: 'qualified' },
  2: { name: 'Riverside Industrial', status: 'new' },
  3: { name: 'Downtown Retail Center', status: 'offer_submitted' },
  4: { name: 'Oak Valley Apartments', status: 'under_contract' },
};

const statusConfig = {
  new: { label: 'New', color: 'bg-blue-500' },
  qualified: { label: 'Qualified', color: 'bg-emerald-500' },
  offer_submitted: { label: 'Offer Submitted', color: 'bg-yellow-500' },
  under_contract: { label: 'Under Contract', color: 'bg-purple-500' },
  closed: { label: 'Closed', color: 'bg-green-500' },
  lost: { label: 'Lost', color: 'bg-red-500' },
};

const OpportunitySidebar = ({ currentSection, currentSubsection }) => {
  const { opportunityId } = useParams();
  const navigate = useNavigate();
  const [expandedModules, setExpandedModules] = useState(['overview', 'analysis']);
  
  const opportunity = mockOpportunityData[opportunityId] || mockOpportunityData[1];
  const status = statusConfig[opportunity.status];

  const toggleModule = (moduleId) => {
    setExpandedModules(prev => 
      prev.includes(moduleId) 
        ? prev.filter(id => id !== moduleId)
        : [...prev, moduleId]
    );
  };

  return (
    <div className="w-64 bg-[#1a202c] text-white flex flex-col h-full">
      {/* Back Link */}
      <div className="px-4 py-3 border-b border-gray-700">
        <button 
          onClick={() => navigate('/pipeline')}
          className="flex items-center gap-2 text-sm text-gray-400 hover:text-white transition-colors"
        >
          <ChevronLeft className="w-4 h-4" />
          BACK TO OPPORTUNITIES
        </button>
      </div>

      {/* Opportunity Header */}
      <div className="px-4 py-4 border-b border-gray-700">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
            <Target className="w-5 h-5 text-white" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs text-gray-400 uppercase">OPPORTUNITY</p>
            <p className="font-semibold truncate">{opportunity.name}</p>
          </div>
        </div>
        <div className="mt-3">
          <Badge className={cn('text-xs', status?.color, 'text-white')}>
            {status?.label}
          </Badge>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-2">
        {opportunityModules.map((module) => {
          const isExpanded = expandedModules.includes(module.id);
          
          return (
            <div key={module.id} className="mb-1">
              {/* Module Header */}
              <button
                onClick={() => toggleModule(module.id)}
                className="w-full px-4 py-2 flex items-center justify-between text-xs font-semibold text-gray-400 hover:text-gray-200 transition-colors"
              >
                <span>{module.label}</span>
                {isExpanded ? (
                  <ChevronDown className="w-4 h-4" />
                ) : (
                  <ChevronRight className="w-4 h-4" />
                )}
              </button>

              {/* Module Sections */}
              {isExpanded && (
                <div className="space-y-0.5">
                  {module.sections.map((section) => {
                    const Icon = section.icon;
                    const isActive = currentSection === module.id && currentSubsection === section.id;
                    
                    return (
                      <NavLink
                        key={section.id}
                        to={`/pipeline/opportunity/${opportunityId}/${module.id}/${section.id}`}
                        className={cn(
                          "flex items-center gap-3 px-6 py-2 text-sm transition-colors",
                          isActive 
                            ? "bg-gray-700 text-white border-l-2 border-emerald-500" 
                            : "text-gray-400 hover:bg-gray-800 hover:text-white"
                        )}
                      >
                        <Icon className="w-4 h-4" />
                        <span>{section.label}</span>
                      </NavLink>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </nav>

      {/* Quick Actions */}
      <div className="px-4 py-3 border-t border-gray-700 space-y-2">
        <button className="w-full px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-medium rounded-md transition-colors">
          Convert to Project
        </button>
        <button className="w-full px-3 py-2 bg-transparent border border-red-500 text-red-400 hover:bg-red-500/10 text-sm font-medium rounded-md transition-colors">
          Mark Lost
        </button>
      </div>

      {/* Footer */}
      <div className="px-4 py-3 border-t border-gray-700">
        <p className="text-xs text-gray-500">AtlasDev v1.0</p>
      </div>
    </div>
  );
};

export default OpportunitySidebar;
