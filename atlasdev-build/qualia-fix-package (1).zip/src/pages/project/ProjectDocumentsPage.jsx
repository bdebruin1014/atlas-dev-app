import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { 
  FileText, Upload, QrCode, Search, FolderOpen, File,
  Download, MoreVertical, ChevronDown, Folder
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';

const ProjectDocumentsPage = () => {
  const { projectId } = useParams();
  const [groupBy, setGroupBy] = useState('package');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPackage, setSelectedPackage] = useState(null);

  const documentPackages = [
    { id: 1, name: 'Alliant Title Docs' },
    { id: 2, name: 'Commercial Closing - Purchaser' },
    { id: 3, name: 'Commercial Seller Closing Docs' },
    { id: 4, name: 'Contracts and Addendums' },
    { id: 5, name: 'Copy of Q- Res Buyer Welcome Package' },
    { id: 6, name: 'Custom Templates' },
    { id: 7, name: 'DLF Assignment Package' },
  ];

  const documents = [
    { id: 1, name: 'Connect', type: 'folder', modified: 'May 23, 2019 at 9:28 am' },
    { id: 2, name: 'DLF Docs', type: 'folder', modified: 'Dec 3, 2018 at 12:00 pm' },
    { id: 3, name: 'Trash (5)', type: 'folder', modified: '', isTrash: true },
    { id: 4, name: '18-495 Jerry Bruce vs Treefrog Properties LLC - Response Le', type: 'pdf', modified: 'Mar 27, 2019 at 11:19 am', isUpload: true },
    { id: 5, name: 'Agreement to Buy and Sell Residential Real Estate', type: 'doc', modified: 'Jul 8 at 6:30 am' },
    { id: 6, name: 'Agreement-To-Buy-Sell-Real-Estate-PDF-Format', type: 'doc', modified: 'May 7, 2019 at 6:12 pm' },
    { id: 7, name: 'As Is Residential Real Estate Contract - Assignable', type: 'doc', modified: 'Jul 8 at 6:29 am' },
    { id: 8, name: 'Chain of Title', type: 'doc', modified: 'May 7, 2019 at 6:49 pm', hasAlert: true },
    { id: 9, name: 'Closing Protection Letter (964970710)', type: 'doc', modified: 'May 7, 2019 at 6:38 pm', hasAlert: true },
    { id: 10, name: 'COMPLIANCE AND TAX PRORATION AGREEMENT', type: 'doc', modified: 'Oct 2 at 9:01 am' },
    { id: 11, name: 'COMPLIANCE AND TAX PRORATION AGREEMENT (2)', type: 'doc', modified: 'Oct 2 at 9:08 am' },
    { id: 12, name: 'De Bruin Law Firm Escrow Wire Instructions - 7031', type: 'doc', modified: 'Dec 7, 2022 at 5:58 pm' },
    { id: 13, name: 'De Bruin Law Firm Escrow Wire Instructions - 7031 (2)', type: 'doc', modified: 'Sep 13, 2023 at 10:42 am' },
    { id: 14, name: 'DLF Wire Instructions', type: 'doc', modified: 'Dec 7, 2022 at 5:58 pm' },
    { id: 15, name: 'DLF Wire Instructions (2)', type: 'doc', modified: 'Mar 22, 2024 at 5:01 pm' },
    { id: 16, name: 'Draft Title Commitment', type: 'doc', modified: 'May 7, 2019 at 6:44 pm', isDraft: true },
  ];

  const filteredDocuments = documents.filter(doc => 
    doc.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-6 bg-gray-50 min-h-full">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <FileText className="w-5 h-5 text-gray-500" />
          <h1 className="text-lg font-semibold text-gray-900">Documents</h1>
        </div>
        <div className="flex items-center gap-2">
          <button className="p-2 text-gray-500 hover:text-gray-700 hover:bg-white rounded border border-transparent hover:border-gray-200">
            <Search className="w-4 h-4" />
          </button>
          <button className="p-2 text-gray-500 hover:text-gray-700 hover:bg-white rounded border border-transparent hover:border-gray-200">
            <Download className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* All Documents Header */}
      <div className="flex items-center gap-2 mb-4 text-sm text-gray-600">
        <FolderOpen className="w-4 h-4" />
        <span>All Documents</span>
      </div>

      <div className="flex gap-6">
        {/* Left Panel - Actions & Packages */}
        <div className="w-56 flex-shrink-0">
          {/* Action Buttons */}
          <div className="bg-white border border-gray-200 rounded-lg mb-4">
            <div className="grid grid-cols-3 divide-x divide-gray-200">
              <button className="flex flex-col items-center py-4 hover:bg-gray-50 rounded-l-lg">
                <FileText className="w-6 h-6 text-gray-400 mb-1" />
                <span className="text-xs text-gray-600">Generate</span>
              </button>
              <button className="flex flex-col items-center py-4 hover:bg-gray-50">
                <QrCode className="w-6 h-6 text-gray-400 mb-1" />
                <span className="text-xs text-gray-600">Scan</span>
              </button>
              <button className="flex flex-col items-center py-4 hover:bg-gray-50 rounded-r-lg">
                <Upload className="w-6 h-6 text-gray-400 mb-1" />
                <span className="text-xs text-gray-600">Upload</span>
              </button>
            </div>
          </div>

          {/* Grouping */}
          <div className="bg-white border border-gray-200 rounded-lg p-3 mb-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-gray-500">Grouping documents by</span>
              <span className="text-[10px] text-gray-400 bg-gray-100 rounded px-1">?</span>
            </div>
            <select 
              value={groupBy}
              onChange={(e) => setGroupBy(e.target.value)}
              className="w-full h-8 text-xs border border-gray-200 rounded px-2"
            >
              <option value="package">Package</option>
              <option value="type">Type</option>
              <option value="date">Date</option>
            </select>
          </div>

          {/* Search */}
          <div className="relative mb-4">
            <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400" />
            <Input 
              placeholder="Search..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8 h-8 text-xs"
            />
          </div>

          {/* Package List */}
          <div className="space-y-0.5">
            {documentPackages.map((pkg) => (
              <button
                key={pkg.id}
                onClick={() => setSelectedPackage(pkg.id === selectedPackage ? null : pkg.id)}
                className={cn(
                  "w-full flex items-center gap-2 px-2 py-1.5 text-xs rounded text-left",
                  selectedPackage === pkg.id ? 'bg-gray-100' : 'hover:bg-gray-50'
                )}
              >
                <Folder className="w-3.5 h-3.5 text-gray-400 flex-shrink-0" />
                <span className="text-gray-700 truncate">{pkg.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Right Panel - Document List */}
        <div className="flex-1 bg-white border border-gray-200 rounded-lg overflow-hidden">
          {/* Table Header */}
          <div className="grid grid-cols-12 gap-4 px-4 py-2 border-b border-gray-200 bg-gray-50">
            <div className="col-span-6 text-xs font-medium text-gray-500 flex items-center gap-1">
              NAME
              <ChevronDown className="w-3 h-3" />
            </div>
            <div className="col-span-2 text-xs font-medium text-gray-500">TYPE</div>
            <div className="col-span-3 text-xs font-medium text-gray-500">MODIFIED</div>
            <div className="col-span-1"></div>
          </div>

          {/* Document Rows */}
          <div className="divide-y divide-gray-100 max-h-[calc(100vh-300px)] overflow-auto">
            {filteredDocuments.map((doc) => (
              <div 
                key={doc.id}
                className="grid grid-cols-12 gap-4 px-4 py-2 hover:bg-gray-50 cursor-pointer items-center"
              >
                <div className="col-span-6 flex items-center gap-2 min-w-0">
                  {doc.type === 'folder' ? (
                    <Folder className={cn(
                      "w-4 h-4 flex-shrink-0",
                      doc.isTrash ? "text-gray-300" : "text-gray-400"
                    )} />
                  ) : doc.isUpload ? (
                    <Upload className="w-4 h-4 text-gray-400 flex-shrink-0" />
                  ) : (
                    <File className="w-4 h-4 text-gray-400 flex-shrink-0" />
                  )}
                  <span className={cn(
                    "text-sm truncate",
                    doc.type === 'folder' ? 'text-gray-700' : 'text-[#047857]'
                  )}>
                    {doc.name}
                  </span>
                </div>
                <div className="col-span-2 flex items-center gap-1">
                  {doc.hasAlert && (
                    <span className="w-4 h-4 bg-red-100 text-red-600 rounded text-[10px] flex items-center justify-center flex-shrink-0">!</span>
                  )}
                  {doc.isDraft && (
                    <span className="px-1.5 py-0.5 bg-gray-100 text-gray-600 rounded text-[10px]">Draft</span>
                  )}
                </div>
                <div className="col-span-3 text-xs text-gray-500 truncate">
                  {doc.modified}
                </div>
                <div className="col-span-1 flex items-center justify-end gap-1">
                  <input type="checkbox" className="w-3.5 h-3.5 rounded border-gray-300" />
                  <button className="p-1 text-gray-400 hover:text-gray-600">
                    <MoreVertical className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProjectDocumentsPage;
