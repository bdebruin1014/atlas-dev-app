import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, Outlet } from 'react-router-dom';

// Layout Components
import TopNavigation from '@/components/TopNavigation';
import ProjectSidebar from '@/components/ProjectSidebar';
import OpportunitySidebar from '@/components/OpportunitySidebar';
import EntityAccountingSidebar from '@/components/EntityAccountingSidebar';
import AdminSidebar from '@/components/AdminSidebar';
import UserSettingsSidebar from '@/components/UserSettingsSidebar';

// Core Pages
import HomePage from '@/pages/HomePage';
import ProjectsListPage from '@/pages/ProjectsListPage';
import ProjectDetailPage from '@/pages/ProjectDetailPage';
import PipelineListPage from '@/pages/PipelineListPage';
import OpportunityDetailPage from '@/pages/OpportunityDetailPage';
import CalendarPage from '@/pages/CalendarPage';

// Operations Pages
import GlobalTasksPage from '@/pages/operations/GlobalTasksPage';
import TaskTemplatesPage from '@/pages/operations/TaskTemplatesPage';
import MilestoneTemplatesPage from '@/pages/operations/MilestoneTemplatesPage';
import OperationsReportsPage from '@/pages/operations/OperationsReportsPage';
import ProductLibraryPage from '@/pages/operations/ProductLibraryPage';

// Investor Pages
import InvestorContactsPage from '@/pages/investors/InvestorContactsPage';
import InvestmentsPage from '@/pages/investors/InvestmentsPage';
import CapitalRaisingPage from '@/pages/investors/CapitalRaisingPage';

// Accounting Pages
import AccountingEntitiesListPage from '@/pages/accounting/AccountingEntitiesListPage';
import EntityAccountingDashboard from '@/pages/accounting/EntityAccountingDashboard';
import BankAccountsPage from '@/pages/accounting/BankAccountsPage';
import BankAccountRegisterPage from '@/pages/accounting/BankAccountRegisterPage';
import ReconciliationPage from '@/pages/accounting/ReconciliationPage';
import DepositsPage from '@/pages/accounting/DepositsPage';
import WireTrackingPage from '@/pages/accounting/WireTrackingPage';
import BillsPage from '@/pages/accounting/BillsPage';
import PaymentsPage from '@/pages/accounting/PaymentsPage';
import InvoicesPage from '@/pages/accounting/InvoicesPage';
import JournalEntriesPage from '@/pages/accounting/JournalEntriesPage';
import CapitalAccountsPage from '@/pages/accounting/CapitalAccountsPage';
import DistributionsPage from '@/pages/accounting/DistributionsPage';
import K1DocumentsPage from '@/pages/accounting/K1DocumentsPage';
import FinancialReportsPage from '@/pages/accounting/FinancialReportsPage';
import TrialBalancePage from '@/pages/accounting/TrialBalancePage';
import ChartOfAccountsPage from '@/pages/accounting/ChartOfAccountsPage';

// Admin Pages
import AdminOverviewPage from '@/pages/admin/AdminOverviewPage';
import UsersPage from '@/pages/admin/UsersPage';
import PermissionGroupsPage from '@/pages/admin/PermissionGroupsPage';
import RolesStructurePage from '@/pages/admin/RolesStructurePage';
import AccountSecurityPage from '@/pages/admin/AccountSecurityPage';
import AccessControlPage from '@/pages/admin/AccessControlPage';
import SSOPage from '@/pages/admin/SSOPage';
import ActivityLogPage from '@/pages/admin/ActivityLogPage';
import BasicPreferencesPage from '@/pages/admin/BasicPreferencesPage';
import ContactsPreferencesPage from '@/pages/admin/ContactsPreferencesPage';
import AccountingPreferencesPage from '@/pages/admin/AccountingPreferencesPage';
import PartnersPreferencesPage from '@/pages/admin/PartnersPreferencesPage';
import IntegrationsPreferencesPage from '@/pages/admin/IntegrationsPreferencesPage';
import ProjectDefaultsGeneralPage from '@/pages/admin/ProjectDefaultsGeneralPage';
import ProjectDefaultsChargesPage from '@/pages/admin/ProjectDefaultsChargesPage';
import ProjectDefaultsDocumentsPage from '@/pages/admin/ProjectDefaultsDocumentsPage';
import FeeScheduleDefaultPage from '@/pages/admin/FeeScheduleDefaultPage';
import FeeScheduleByTypePage from '@/pages/admin/FeeScheduleByTypePage';
import WorkflowTypesPage from '@/pages/admin/WorkflowsPage';
import CoreWorkflowsPage from '@/pages/admin/CoreWorkflowsPage';
import SmartActionsPage from '@/pages/admin/SmartActionsPage';
import AssignmentGroupsPage from '@/pages/admin/AssignmentGroupsPage';
import ProjectTemplatesPage from '@/pages/admin/ProjectTemplatesPage';
import CustomDocumentsPage from '@/pages/admin/CustomDocumentsPage';
import DocumentPackagesPage from '@/pages/admin/DocumentPackagesPage';
import QRPackagesPage from '@/pages/admin/QRPackagesPage';
import DocumentStampsPage from '@/pages/admin/DocumentStampsPage';
import StandardInstructionsPage from '@/pages/admin/StandardInstructionsPage';
import ReportPackagesPage from '@/pages/admin/ReportPackagesPage';
import K1ReportingPage from '@/pages/admin/K1ReportingPage';

// User Settings Pages
import ProfilePage from '@/pages/user-settings/ProfilePage';
import EmailSettingsPage from '@/pages/user-settings/EmailSettingsPage';
import NotificationsPage from '@/pages/user-settings/NotificationsPage';
import CredentialsPage from '@/pages/user-settings/CredentialsPage';
import UserSecurityPage from '@/pages/user-settings/SecurityPage';
import SignaturePage from '@/pages/user-settings/SignaturePage';
import StampsPage from '@/pages/user-settings/StampsPage';
import CalendarPreferencesPage from '@/pages/user-settings/CalendarPreferencesPage';
import DisplaySettingsPage from '@/pages/user-settings/DisplaySettingsPage';
import TrainingPage from '@/pages/user-settings/TrainingPage';
import ReportsSettingsPage from '@/pages/user-settings/ReportsSettingsPage';
import ConnectPage from '@/pages/user-settings/ConnectPage';

// Main Layout with Top Navigation
const MainLayout = () => (
  <div className="flex flex-col h-screen">
    <TopNavigation />
    <main className="flex-1 overflow-hidden">
      <Outlet />
    </main>
  </div>
);

// Project Layout with Dark Sidebar
const ProjectLayout = () => (
  <div className="flex h-full">
    <ProjectSidebar />
    <div className="flex-1 overflow-hidden">
      <Outlet />
    </div>
  </div>
);

// Opportunity Layout with Dark Sidebar
const OpportunityLayout = () => (
  <div className="flex h-full">
    <OpportunitySidebar />
    <div className="flex-1 overflow-hidden">
      <Outlet />
    </div>
  </div>
);

// Entity Accounting Layout with Dark Sidebar
const EntityAccountingLayout = () => (
  <div className="flex h-full">
    <EntityAccountingSidebar />
    <div className="flex-1 overflow-hidden">
      <Outlet />
    </div>
  </div>
);

// Admin Layout with Dark Sidebar
const AdminLayout = () => (
  <div className="flex h-full">
    <AdminSidebar />
    <div className="flex-1 overflow-hidden">
      <Outlet />
    </div>
  </div>
);

// User Settings Layout with Dark Sidebar
const UserSettingsLayout = () => (
  <div className="flex h-full">
    <UserSettingsSidebar />
    <div className="flex-1 overflow-hidden">
      <Outlet />
    </div>
  </div>
);

function App() {
  return (
    <Router>
      <Routes>
        <Route element={<MainLayout />}>
          {/* Home */}
          <Route path="/" element={<HomePage />} />
          
          {/* Calendar */}
          <Route path="/calendar" element={<CalendarPage />} />
          
          {/* Operations */}
          <Route path="/operations/tasks" element={<GlobalTasksPage />} />
          <Route path="/operations/task-templates" element={<TaskTemplatesPage />} />
          <Route path="/operations/milestone-templates" element={<MilestoneTemplatesPage />} />
          <Route path="/operations/reports" element={<OperationsReportsPage />} />
          <Route path="/operations/product-library" element={<ProductLibraryPage />} />
          
          {/* Projects List */}
          <Route path="/projects" element={<ProjectsListPage />} />
          
          {/* Project Detail with Dark Sidebar */}
          <Route path="/project/:projectId" element={<ProjectLayout />}>
            <Route index element={<Navigate to="overview/basic-info" replace />} />
            <Route path=":module" element={<ProjectDetailPage />} />
            <Route path=":module/:section" element={<ProjectDetailPage />} />
          </Route>
          
          {/* Pipeline / Opportunities List */}
          <Route path="/pipeline" element={<PipelineListPage />} />
          
          {/* Opportunity Detail with Dark Sidebar */}
          <Route path="/pipeline/:opportunityId" element={<OpportunityLayout />}>
            <Route index element={<Navigate to="overview/basic-info" replace />} />
            <Route path=":module" element={<OpportunityDetailPage />} />
            <Route path=":module/:section" element={<OpportunityDetailPage />} />
          </Route>
          
          {/* Investors */}
          <Route path="/investors" element={<Navigate to="/investors/contacts" replace />} />
          <Route path="/investors/contacts" element={<InvestorContactsPage />} />
          <Route path="/investors/investments" element={<InvestmentsPage />} />
          <Route path="/investors/capital-raising" element={<CapitalRaisingPage />} />
          
          {/* Accounting */}
          <Route path="/accounting" element={<Navigate to="/accounting/entities" replace />} />
          <Route path="/accounting/entities" element={<AccountingEntitiesListPage />} />
          
          {/* Entity Accounting Detail with Dark Sidebar */}
          <Route path="/accounting/entities/:entityId" element={<EntityAccountingLayout />}>
            <Route index element={<EntityAccountingDashboard />} />
            <Route path="bank-accounts" element={<BankAccountsPage />} />
            <Route path="register" element={<BankAccountRegisterPage />} />
            <Route path="reconciliation" element={<ReconciliationPage />} />
            <Route path="deposits" element={<DepositsPage />} />
            <Route path="wire-tracking" element={<WireTrackingPage />} />
            <Route path="bills" element={<BillsPage />} />
            <Route path="payments" element={<PaymentsPage />} />
            <Route path="invoices" element={<InvoicesPage />} />
            <Route path="journal-entries" element={<JournalEntriesPage />} />
            <Route path="capital" element={<CapitalAccountsPage />} />
            <Route path="distributions" element={<DistributionsPage />} />
            <Route path="k1-documents" element={<K1DocumentsPage />} />
            <Route path="reports" element={<FinancialReportsPage />} />
            <Route path="trial-balance" element={<TrialBalancePage />} />
            <Route path="chart-of-accounts" element={<ChartOfAccountsPage />} />
          </Route>
          
          {/* Admin with Dark Sidebar */}
          <Route path="/admin" element={<AdminLayout />}>
            <Route index element={<AdminOverviewPage />} />
            <Route path="organization/users" element={<UsersPage />} />
            <Route path="organization/permissions" element={<PermissionGroupsPage />} />
            <Route path="organization/roles" element={<RolesStructurePage />} />
            <Route path="security/account" element={<AccountSecurityPage />} />
            <Route path="security/access" element={<AccessControlPage />} />
            <Route path="security/sso" element={<SSOPage />} />
            <Route path="security/activity" element={<ActivityLogPage />} />
            <Route path="preferences/basic" element={<BasicPreferencesPage />} />
            <Route path="preferences/contacts" element={<ContactsPreferencesPage />} />
            <Route path="preferences/accounting" element={<AccountingPreferencesPage />} />
            <Route path="preferences/partners" element={<PartnersPreferencesPage />} />
            <Route path="preferences/integrations" element={<IntegrationsPreferencesPage />} />
            <Route path="project-defaults/general" element={<ProjectDefaultsGeneralPage />} />
            <Route path="project-defaults/charges" element={<ProjectDefaultsChargesPage />} />
            <Route path="project-defaults/documents" element={<ProjectDefaultsDocumentsPage />} />
            <Route path="fee-schedule/default" element={<FeeScheduleDefaultPage />} />
            <Route path="fee-schedule/by-type" element={<FeeScheduleByTypePage />} />
            <Route path="workflows/types" element={<WorkflowTypesPage />} />
            <Route path="workflows/core" element={<CoreWorkflowsPage />} />
            <Route path="workflows/smart-actions" element={<SmartActionsPage />} />
            <Route path="workflows/assignments" element={<AssignmentGroupsPage />} />
            <Route path="workflows/templates" element={<ProjectTemplatesPage />} />
            <Route path="documents/custom" element={<CustomDocumentsPage />} />
            <Route path="documents/packages" element={<DocumentPackagesPage />} />
            <Route path="documents/qr" element={<QRPackagesPage />} />
            <Route path="documents/stamps" element={<DocumentStampsPage />} />
            <Route path="documents/instructions" element={<StandardInstructionsPage />} />
            <Route path="reports/packages" element={<ReportPackagesPage />} />
            <Route path="reports/k1" element={<K1ReportingPage />} />
          </Route>
          
          {/* User Settings with Dark Sidebar */}
          <Route path="/settings" element={<UserSettingsLayout />}>
            <Route index element={<Navigate to="profile" replace />} />
            <Route path="profile" element={<ProfilePage />} />
            <Route path="email" element={<EmailSettingsPage />} />
            <Route path="notifications" element={<NotificationsPage />} />
            <Route path="credentials" element={<CredentialsPage />} />
            <Route path="security" element={<UserSecurityPage />} />
            <Route path="preferences/signature" element={<SignaturePage />} />
            <Route path="preferences/stamps" element={<StampsPage />} />
            <Route path="preferences/calendar" element={<CalendarPreferencesPage />} />
            <Route path="preferences/display" element={<DisplaySettingsPage />} />
            <Route path="training" element={<TrainingPage />} />
            <Route path="reports" element={<ReportsSettingsPage />} />
            <Route path="connect" element={<ConnectPage />} />
          </Route>
          
          {/* Catch all */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Route>
      </Routes>
    </Router>
  );
}

export default App;
