import React from 'react';
import { Helmet } from 'react-helmet';
import { useParams } from 'react-router-dom';
import ProjectContent from '@/components/ProjectContent';

// Project metadata for page titles
const projectMetadata = {
  1: { name: 'Watson House', entity: 'Watson House LLC' },
  2: { name: 'Oslo Townhomes', entity: 'Oslo Townhomes LLC' },
  3: { name: 'Cedar Mill Apartments', entity: 'Cedar Mill Partners' },
  4: { name: 'Pine Valley Lots', entity: 'VanRock Holdings LLC' },
};

const ProjectDetailPage = () => {
  const { projectId, tab = 'overview', subtab = 'general' } = useParams();
  
  // Get project metadata for the page title
  const id = parseInt(projectId) || 1;
  const project = projectMetadata[id] || projectMetadata[1];

  return (
    <>
      <Helmet>
        <title>{project.name} | AtlasDev</title>
        <meta name="description" content={`Project details and management for ${project.name}`} />
      </Helmet>
      
      {/* Content Only - Sidebar is now handled by App.jsx Layout */}
      <div className="h-full w-full">
        <ProjectContent project={project} tab={tab} subtab={subtab} />
      </div>
    </>
  );
};

export default ProjectDetailPage;
