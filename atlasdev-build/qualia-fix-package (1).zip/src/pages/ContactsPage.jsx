import React, { useState } from 'react';
import { 
  Search, Plus, Building2, Users, User, ChevronDown, ChevronRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';

const ContactsPage = () => {
  const [activeCategory, setActiveCategory] = useState('employees');
  const [activeSubCategory, setActiveSubCategory] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedCategories, setExpandedCategories] = useState(['employees']);

  const categories = [
    { 
      id: 'companies', 
      label: 'Companies', 
      icon: Building2,
    },
    { 
      id: 'employees', 
      label: 'Employees', 
      icon: User,
      subcategories: [
        { id: 'closing', label: 'Closing' },
        { id: 'payoffs', label: 'Payoffs' },
        { id: 'services', label: 'Services' },
        { id: 'government', label: 'Government' },
        { id: 'other-contacts', label: 'Other Contacts' },
      ]
    },
    { 
      id: 'customers', 
      label: 'Customers', 
      icon: Users,
      subcategories: [
        { id: 'individuals', label: 'Individuals' },
        { id: 'organizations', label: 'Organizations' },
      ]
    },
  ];

  const employeeContacts = [
    { id: 1, name: '', jobTitle: 'Attorney', company: '', email: '', workPhone: '', cellPhone: '' },
    { id: 2, name: '', jobTitle: 'Attorney', company: 'De Bruin Law Firm', email: '', workPhone: '', cellPhone: '' },
    { id: 3, name: '', jobTitle: 'Notary', company: 'USA Notary (RON Only)', email: 'ryon@usanotary.net', workPhone: '(804) 767-7500', cellPhone: '' },
    { id: 4, name: 'Tonya (Paralegal)', jobTitle: 'Attorney', company: 'Finklea, Hendrick & Blake, LLC', email: 'thayes@finklealaw.com', workPhone: '', cellPhone: '' },
    { id: 5, name: 'Kenya (Processor)', jobTitle: 'Loan Processor', company: 'PennyMac Loan Services, LLC', email: '', workPhone: '(800) 900-4794', cellPhone: '' },
    { id: 6, name: 'ALAN *', jobTitle: '', company: 'BROOKFIELD GARDENS', email: 'brookfield.gardens30@gmail.com', workPhone: '(678) 296-6202', cellPhone: '' },
    { id: 7, name: 'N/A 1', jobTitle: '', company: 'USAA', email: 'doublejveytia@gmail.com', workPhone: '(800) 531-8722', cellPhone: '' },
    { id: 8, name: 'Todd ???', jobTitle: '', company: 'Foxfield Commons Town Houses', email: 'foxfieldcommonstownhouses@gmail.com', workPhone: '', cellPhone: '' },
    { id: 9, name: '??? ???', jobTitle: '', company: 'Foxfield Commons Town Houses', email: 'foxfieldcommonstownhouses@gmail.com', workPhone: '', cellPhone: '' },
    { id: 10, name: 'Colby Absmeier', jobTitle: '', company: 'State Farm', email: 'colbyabs103@outlook.com', workPhone: '(606) 359-3185', cellPhone: '' },
    { id: 11, name: 'Stephanie Accor', jobTitle: 'Loan Processor', company: 'Family Trust FCU', email: 'saccor@familytrust.org', workPhone: '(803) 326-2171', cellPhone: '' },
    { id: 12, name: 'Jason Acosta', jobTitle: '', company: 'First Choice Insurance Agency Inc', email: 'jason@fcisc.com', workPhone: '(864) 334-1200', cellPhone: '' },
    { id: 13, name: 'Stuart Adams', jobTitle: 'Real Estate Agent', company: 'Capital Center, LLC', email: 'sadams@capcenter.com', workPhone: '', cellPhone: '' },
    { id: 14, name: 'Jonathan Adams', jobTitle: 'Loan Officer', company: 'LendUS, LLC', email: '', workPhone: '(864) 640-8088', cellPhone: '' },
    { id: 15, name: 'Alex Adams', jobTitle: '', company: 'State Farm', email: 'alex@agentscottburkhard.com', workPhone: '(704) 987-5115', cellPhone: '' },
  ];

  const companyContacts = [
    { id: 1, name: 'First National Bank', type: 'Lender', address: '123 Main St, Greenville, SC', phone: '(864) 555-1234' },
    { id: 2, name: 'ABC Title Company', type: 'Title Company', address: '456 Oak Ave, Greenville, SC', phone: '(864) 555-5678' },
    { id: 3, name: 'Smith Construction LLC', type: 'Contractor', address: '789 Builder Rd, Greenville, SC', phone: '(864) 555-9012' },
    { id: 4, name: 'Johnson Engineering', type: 'Engineers', address: '321 Tech Blvd, Greenville, SC', phone: '(864) 555-3456' },
    { id: 5, name: 'Greenville Surveyors Inc', type: 'Surveyors', address: '654 Map Lane, Greenville, SC', phone: '(864) 555-7890' },
  ];

  const toggleCategory = (categoryId) => {
    if (expandedCategories.includes(categoryId)) {
      setExpandedCategories(expandedCategories.filter(c => c !== categoryId));
    } else {
      setExpandedCategories([...expandedCategories, categoryId]);
    }
    setActiveCategory(categoryId);
    setActiveSubCategory(null);
  };

  const getCategoryTitle = () => {
    if (activeCategory === 'companies') return 'All Companies';
    if (activeCategory === 'employees') return 'All Contacts';
    if (activeCategory === 'customers') return 'All Customers';
    return 'Contacts';
  };

  const getButtonLabel = () => {
    if (activeCategory === 'companies') return 'New Company';
    if (activeCategory === 'employees') return 'New Employee';
    if (activeCategory === 'customers') return 'New Customer';
    return 'New Contact';
  };

  return (
    <div className="flex h-[calc(100vh-40px)] bg-gray-50">
      {/* Left Sidebar */}
      <div className="w-44 bg-white border-r border-gray-200 flex-shrink-0">
        <nav className="py-1">
          {categories.map((category) => (
            <div key={category.id}>
              <button
                onClick={() => toggleCategory(category.id)}
                className={cn(
                  "w-full flex items-center gap-2 px-3 py-2 text-sm",
                  activeCategory === category.id && !activeSubCategory
                    ? "bg-[#047857] text-white"
                    : "text-gray-700 hover:bg-gray-100"
                )}
              >
                <category.icon className="w-4 h-4" />
                {category.label}
                {category.subcategories && (
                  <ChevronDown className={cn(
                    "w-3 h-3 ml-auto transition-transform",
                    expandedCategories.includes(category.id) ? "" : "-rotate-90"
                  )} />
                )}
              </button>
              
              {category.subcategories && expandedCategories.includes(category.id) && (
                <div className="ml-6 border-l border-gray-200">
                  {category.subcategories.map((sub) => (
                    <button
                      key={sub.id}
                      onClick={() => {
                        setActiveCategory(category.id);
                        setActiveSubCategory(sub.id);
                      }}
                      className={cn(
                        "w-full text-left px-3 py-1.5 text-xs",
                        activeSubCategory === sub.id
                          ? "text-[#047857] font-medium"
                          : "text-gray-600 hover:text-gray-900"
                      )}
                    >
                      {sub.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          ))}
        </nav>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <User className="w-5 h-5 text-gray-500" />
            <h1 className="text-lg font-semibold text-gray-900">{getCategoryTitle()}</h1>
          </div>
          <Button className="bg-[#047857] hover:bg-[#065f46] text-white text-xs h-8">
            {getButtonLabel()}
          </Button>
        </div>

        {/* Table */}
        <div className="flex-1 overflow-auto">
          <table className="w-full">
            <thead className="bg-gray-50 sticky top-0">
              <tr className="border-b border-gray-200">
                {activeCategory === 'companies' ? (
                  <>
                    <th className="text-left px-4 py-2 text-xs font-medium text-gray-500">Name</th>
                    <th className="text-left px-4 py-2 text-xs font-medium text-gray-500">Type</th>
                    <th className="text-left px-4 py-2 text-xs font-medium text-gray-500">Address</th>
                    <th className="text-left px-4 py-2 text-xs font-medium text-gray-500">Phone</th>
                  </>
                ) : (
                  <>
                    <th className="text-left px-4 py-2 text-xs font-medium text-gray-500">Name</th>
                    <th className="text-left px-4 py-2 text-xs font-medium text-gray-500">Job Title</th>
                    <th className="text-left px-4 py-2 text-xs font-medium text-gray-500">Company</th>
                    <th className="text-left px-4 py-2 text-xs font-medium text-gray-500">Email</th>
                    <th className="text-left px-4 py-2 text-xs font-medium text-gray-500">Work Phone</th>
                    <th className="text-left px-4 py-2 text-xs font-medium text-gray-500">Cell Phone</th>
                  </>
                )}
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-100">
              {activeCategory === 'companies' ? (
                companyContacts.map((contact) => (
                  <tr key={contact.id} className="hover:bg-gray-50 cursor-pointer">
                    <td className="px-4 py-2.5 text-sm text-gray-900">{contact.name}</td>
                    <td className="px-4 py-2.5 text-sm text-gray-600">{contact.type}</td>
                    <td className="px-4 py-2.5 text-sm text-gray-600">{contact.address || <span className="text-gray-400">Not set</span>}</td>
                    <td className="px-4 py-2.5 text-sm text-gray-600">{contact.phone || <span className="text-gray-400">Not set</span>}</td>
                  </tr>
                ))
              ) : (
                employeeContacts.map((contact) => (
                  <tr key={contact.id} className="hover:bg-gray-50 cursor-pointer">
                    <td className="px-4 py-2.5 text-sm text-gray-900">{contact.name || <span className="text-gray-400">Not set</span>}</td>
                    <td className="px-4 py-2.5 text-sm text-gray-600">{contact.jobTitle || <span className="text-gray-400">Not set</span>}</td>
                    <td className="px-4 py-2.5 text-sm text-gray-600">{contact.company || <span className="text-gray-400">Not set</span>}</td>
                    <td className="px-4 py-2.5 text-sm text-gray-600">{contact.email || <span className="text-gray-400">Not set</span>}</td>
                    <td className="px-4 py-2.5 text-sm text-gray-600">{contact.workPhone || <span className="text-gray-400">Not set</span>}</td>
                    <td className="px-4 py-2.5 text-sm text-gray-600">{contact.cellPhone || <span className="text-gray-400">Not set</span>}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>

          {/* Pagination */}
          <div className="bg-white border-t border-gray-200 px-4 py-2 flex items-center justify-center gap-1">
            <button className="px-2 py-1 text-xs text-gray-500 hover:text-gray-700">&lt;</button>
            <button className="px-2.5 py-1 text-xs bg-[#047857] text-white rounded">1</button>
            <button className="px-2.5 py-1 text-xs text-gray-600 hover:bg-gray-100 rounded">2</button>
            <button className="px-2.5 py-1 text-xs text-gray-600 hover:bg-gray-100 rounded">3</button>
            <button className="px-2.5 py-1 text-xs text-gray-600 hover:bg-gray-100 rounded">4</button>
            <button className="px-2.5 py-1 text-xs text-gray-600 hover:bg-gray-100 rounded">5</button>
            <button className="px-2.5 py-1 text-xs text-gray-600 hover:bg-gray-100 rounded">6</button>
            <button className="px-2.5 py-1 text-xs text-gray-600 hover:bg-gray-100 rounded">7</button>
            <span className="px-2 text-xs text-gray-400">...</span>
            <button className="px-2.5 py-1 text-xs text-gray-600 hover:bg-gray-100 rounded">116</button>
            <button className="px-2 py-1 text-xs text-gray-500 hover:text-gray-700">&gt;</button>
          </div>
        </div>
      </div>

      {/* Right Sidebar - Filters */}
      <div className="w-52 bg-white border-l border-gray-200 flex-shrink-0 p-3">
        <h3 className="text-sm font-medium text-gray-900 mb-3">Filter People</h3>
        
        <div className="space-y-3">
          <div>
            <label className="block text-[10px] font-medium text-gray-500 uppercase mb-1">Search Term</label>
            <div className="relative">
              <Input
                placeholder="Search..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="h-8 text-xs pr-8"
              />
              <Search className="absolute right-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400" />
            </div>
          </div>

          <div className="border-t border-gray-200 pt-3">
            <h4 className="text-[10px] font-medium text-gray-500 uppercase mb-2 flex items-center gap-1">
              <ChevronDown className="w-3 h-3" /> PROFILE
            </h4>
            
            <div className="space-y-2">
              <div>
                <label className="block text-[10px] text-gray-500 uppercase mb-1">Company</label>
                <Input placeholder="Any" className="h-7 text-xs" />
              </div>
              <div>
                <label className="block text-[10px] text-gray-500 uppercase mb-1">Job Title</label>
                <Input placeholder="Any" className="h-7 text-xs" />
              </div>
              <div>
                <label className="block text-[10px] text-gray-500 uppercase mb-1">Phone</label>
                <Input placeholder="Any" className="h-7 text-xs" />
              </div>
              <div>
                <label className="block text-[10px] text-gray-500 uppercase mb-1">Email</label>
                <Input placeholder="Any" className="h-7 text-xs" />
              </div>
            </div>
          </div>

          <div className="border-t border-gray-200 pt-3">
            <h4 className="text-[10px] font-medium text-gray-500 uppercase mb-2 flex items-center gap-1">
              <ChevronRight className="w-3 h-3" /> REPORTING
            </h4>
            <div>
              <label className="block text-[10px] text-gray-500 uppercase mb-1">Associated Marketer</label>
              <Input placeholder="Any" className="h-7 text-xs" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactsPage;
