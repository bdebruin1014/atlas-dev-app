import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ChevronLeft, ChevronRight, Plus, Calendar as CalendarIcon } from 'lucide-react';

const mockEvents = [
  { id: 1, title: 'Watson House Site Visit', date: '2024-11-05', time: '10:00 AM', type: 'meeting', project: 'Watson House' },
  { id: 2, title: 'Oslo Permit Review', date: '2024-11-05', time: '2:00 PM', type: 'deadline', project: 'Oslo Townhomes' },
  { id: 3, title: 'Investor Call', date: '2024-11-07', time: '11:00 AM', type: 'call', project: null },
  { id: 4, title: 'Draw Request Due', date: '2024-11-10', time: 'All Day', type: 'deadline', project: 'Watson House' },
];

const CalendarPage = () => {
  const [currentDate, setCurrentDate] = useState(new Date());
  
  const daysInMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).getDate();
  const firstDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).getDay();
  
  const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  
  const prevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  };
  
  const nextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  };

  const typeColors = {
    meeting: 'bg-blue-500',
    deadline: 'bg-red-500',
    call: 'bg-green-500',
  };

  return (
    <div className="p-6 space-y-6 overflow-y-auto h-full bg-[#F7FAFC]">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Calendar</h1>
        <Button><Plus className="w-4 h-4 mr-2" />Add Event</Button>
      </div>

      <div className="grid grid-cols-3 gap-6">
        {/* Calendar Grid */}
        <Card className="col-span-2">
          <CardHeader className="flex flex-row items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={prevMonth}><ChevronLeft className="w-4 h-4" /></Button>
              <h2 className="text-lg font-semibold">{monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}</h2>
              <Button variant="ghost" size="icon" onClick={nextMonth}><ChevronRight className="w-4 h-4" /></Button>
            </div>
            <Button variant="outline" onClick={() => setCurrentDate(new Date())}>Today</Button>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-7 gap-1">
              {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                <div key={day} className="text-center text-sm font-medium text-gray-500 py-2">{day}</div>
              ))}
              {Array.from({ length: firstDayOfMonth }).map((_, i) => (
                <div key={`empty-${i}`} className="h-24 bg-gray-50 rounded"></div>
              ))}
              {Array.from({ length: daysInMonth }).map((_, i) => {
                const day = i + 1;
                const isToday = day === new Date().getDate() && 
                  currentDate.getMonth() === new Date().getMonth() && 
                  currentDate.getFullYear() === new Date().getFullYear();
                return (
                  <div 
                    key={day} 
                    className={`h-24 border rounded p-1 cursor-pointer hover:bg-gray-50 ${isToday ? 'border-emerald-500 bg-emerald-50' : 'border-gray-200'}`}
                  >
                    <span className={`text-sm font-medium ${isToday ? 'text-emerald-600' : ''}`}>{day}</span>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Upcoming Events */}
        <Card>
          <CardHeader>
            <CardTitle>Upcoming Events</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {mockEvents.map((event) => (
                <div key={event.id} className="p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-2 mb-1">
                    <div className={`w-2 h-2 rounded-full ${typeColors[event.type]}`}></div>
                    <span className="font-medium text-sm">{event.title}</span>
                  </div>
                  <p className="text-xs text-gray-500">{event.date} • {event.time}</p>
                  {event.project && <Badge variant="outline" className="mt-1 text-xs">{event.project}</Badge>}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default CalendarPage;
