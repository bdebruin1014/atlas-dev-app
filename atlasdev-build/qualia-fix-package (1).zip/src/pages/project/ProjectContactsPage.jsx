import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { Search, Plus, User, Building2, Users } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

const ProjectContactsPage = () => {
  const { projectId } = useParams();
  const [activeCategory, setActiveCategory] = useState('buyers');
  const [activeTab, setActiveTab] = useState('info');
  const [searchTerm, setSearchTerm] = useState('');

  const categories = [
    { id: 'buyers', label: 'Buyers', count: 2 },
    { id: 'sellers', label: 'Sellers', count: 1 },
    { id: 'lenders', label: 'Lenders', count: 1 },
    { id: 'contractors', label: 'Contractors', count: 3 },
    { id: 'architects', label: 'Architects', count: 1 },
    { id: 'engineers', label: 'Engineers', count: 1 },
    { id: 'title', label: 'Title Companies', count: 1 },
    { id: 'attorneys', label: 'Attorneys', count: 2 },
    { id: 'surveyors', label: 'Surveyors', count: 1 },
    { id: 'appraisers', label: 'Appraisers', count: 0 },
    { id: 'investors', label: 'Investors', count: 2 },
    { id: 'other', label: 'Other', count: 0 },
  ];

  const tabs = [
    { id: 'info', label: 'Info' },
    { id: 'spouse', label: 'Spouse' },
    { id: 'addresses', label: 'Addresses' },
    { id: 'attorney', label: 'Attorney' },
    { id: 'documents', label: 'Documents' },
  ];

  const [contactData, setContactData] = useState({
    contactType: 'Individual',
    firstName: '',
    middleName: '',
    lastName: '',
    suffix: '',
    gender: '',
    maritalStatus: '',
    ssn: '',
    dob: '',
    email: '',
    cellPhone: '',
    homePhone: '',
    workPhone: '',
    fax: '',
    preferEmail: true,
    preferSMS: false,
    preferMail: false,
    addresses: [{ street: '', apt: '', city: '', state: '', zip: '', country: 'USA' }],
  });

  const handleChange = (field, value) => {
    setContactData(prev => ({ ...prev, [field]: value }));
  };

  const addAddress = () => {
    setContactData(prev => ({
      ...prev,
      addresses: [...prev.addresses, { street: '', apt: '', city: '', state: '', zip: '', country: 'USA' }]
    }));
  };

  return (
    <div className="flex h-full bg-gray-50">
      {/* Left Categories Panel */}
      <div className="w-44 bg-white border-r border-gray-200 flex-shrink-0 overflow-auto">
        <div className="p-2 border-b border-gray-200">
          <h3 className="text-xs font-semibold text-gray-500 uppercase">Contacts</h3>
        </div>
        <div className="py-1">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={cn(
                "w-full flex items-center justify-between px-3 py-1.5 text-xs",
                activeCategory === cat.id
                  ? "bg-[#047857] text-white"
                  : "text-gray-700 hover:bg-gray-100"
              )}
            >
              <span>{cat.label}</span>
              {cat.count > 0 && (
                <span className={cn(
                  "text-[10px] px-1.5 rounded",
                  activeCategory === cat.id ? "bg-white/20" : "bg-gray-100"
                )}>
                  {cat.count}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-gray-500" />
            <h2 className="text-sm font-semibold text-gray-900 capitalize">{activeCategory}</h2>
          </div>
          <Button className="bg-[#047857] hover:bg-[#065f46] text-white text-xs h-7">
            <Plus className="w-3 h-3 mr-1" /> Add Contact
          </Button>
        </div>

        {/* Tabs */}
        <div className="bg-white border-b border-gray-200 px-4 flex-shrink-0">
          <div className="flex gap-1">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={cn(
                  "px-3 py-2 text-xs font-medium border-b-2 transition-colors",
                  activeTab === tab.id
                    ? "text-[#047857] border-[#047857]"
                    : "text-gray-500 border-transparent hover:text-gray-700"
                )}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Form Content */}
        <div className="flex-1 overflow-auto p-4">
          {activeTab === 'info' && (
            <div className="max-w-2xl space-y-4">
              {/* Contact Type */}
              <div className="bg-white rounded-lg border border-gray-200 p-4">
                <label className="block text-[11px] text-gray-500 uppercase mb-2">Contact Type</label>
                <select
                  value={contactData.contactType}
                  onChange={(e) => handleChange('contactType', e.target.value)}
                  className="w-48 h-9 text-sm border border-gray-200 rounded px-2"
                >
                  <option>Individual</option>
                  <option>Entity</option>
                  <option>Company</option>
                </select>
              </div>

              {/* Name */}
              <div className="bg-white rounded-lg border border-gray-200 p-4">
                <h3 className="text-xs font-semibold text-gray-700 uppercase mb-3">Name</h3>
                <div className="grid grid-cols-4 gap-3">
                  <div>
                    <label className="block text-[11px] text-gray-500 uppercase mb-1">First</label>
                    <Input
                      value={contactData.firstName}
                      onChange={(e) => handleChange('firstName', e.target.value)}
                      className="h-9 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-gray-500 uppercase mb-1">Middle</label>
                    <Input
                      value={contactData.middleName}
                      onChange={(e) => handleChange('middleName', e.target.value)}
                      className="h-9 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-gray-500 uppercase mb-1">Last</label>
                    <Input
                      value={contactData.lastName}
                      onChange={(e) => handleChange('lastName', e.target.value)}
                      className="h-9 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-gray-500 uppercase mb-1">Suffix</label>
                    <Input
                      value={contactData.suffix}
                      onChange={(e) => handleChange('suffix', e.target.value)}
                      className="h-9 text-sm"
                    />
                  </div>
                </div>
              </div>

              {/* Personal Info */}
              <div className="bg-white rounded-lg border border-gray-200 p-4">
                <h3 className="text-xs font-semibold text-gray-700 uppercase mb-3">Personal Information</h3>
                <div className="grid grid-cols-4 gap-3">
                  <div>
                    <label className="block text-[11px] text-gray-500 uppercase mb-1">Gender</label>
                    <select
                      value={contactData.gender}
                      onChange={(e) => handleChange('gender', e.target.value)}
                      className="w-full h-9 text-sm border border-gray-200 rounded px-2"
                    >
                      <option value="">Select...</option>
                      <option>Male</option>
                      <option>Female</option>
                      <option>Other</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[11px] text-gray-500 uppercase mb-1">Marital Status</label>
                    <select
                      value={contactData.maritalStatus}
                      onChange={(e) => handleChange('maritalStatus', e.target.value)}
                      className="w-full h-9 text-sm border border-gray-200 rounded px-2"
                    >
                      <option value="">Select...</option>
                      <option>Single</option>
                      <option>Married</option>
                      <option>Divorced</option>
                      <option>Widowed</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[11px] text-gray-500 uppercase mb-1">SSN</label>
                    <Input
                      value={contactData.ssn}
                      onChange={(e) => handleChange('ssn', e.target.value)}
                      placeholder="XXX-XX-XXXX"
                      className="h-9 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-gray-500 uppercase mb-1">Date of Birth</label>
                    <Input
                      type="date"
                      value={contactData.dob}
                      onChange={(e) => handleChange('dob', e.target.value)}
                      className="h-9 text-sm"
                    />
                  </div>
                </div>
              </div>

              {/* Contact Info */}
              <div className="bg-white rounded-lg border border-gray-200 p-4">
                <h3 className="text-xs font-semibold text-gray-700 uppercase mb-3">Contact Information</h3>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] text-gray-500 uppercase mb-1">Email</label>
                    <Input
                      type="email"
                      value={contactData.email}
                      onChange={(e) => handleChange('email', e.target.value)}
                      className="h-9 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-gray-500 uppercase mb-1">Cell Phone</label>
                    <Input
                      value={contactData.cellPhone}
                      onChange={(e) => handleChange('cellPhone', e.target.value)}
                      placeholder="(xxx) xxx-xxxx"
                      className="h-9 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-gray-500 uppercase mb-1">Home Phone</label>
                    <Input
                      value={contactData.homePhone}
                      onChange={(e) => handleChange('homePhone', e.target.value)}
                      placeholder="(xxx) xxx-xxxx"
                      className="h-9 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-gray-500 uppercase mb-1">Work Phone</label>
                    <Input
                      value={contactData.workPhone}
                      onChange={(e) => handleChange('workPhone', e.target.value)}
                      placeholder="(xxx) xxx-xxxx"
                      className="h-9 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-gray-500 uppercase mb-1">Fax</label>
                    <Input
                      value={contactData.fax}
                      onChange={(e) => handleChange('fax', e.target.value)}
                      placeholder="(xxx) xxx-xxxx"
                      className="h-9 text-sm"
                    />
                  </div>
                </div>
              </div>

              {/* Communication Preferences */}
              <div className="bg-white rounded-lg border border-gray-200 p-4">
                <h3 className="text-xs font-semibold text-gray-700 uppercase mb-3">Communication Preferences</h3>
                <div className="flex gap-6">
                  <label className="flex items-center gap-2 text-xs text-gray-600">
                    <input
                      type="checkbox"
                      checked={contactData.preferEmail}
                      onChange={(e) => handleChange('preferEmail', e.target.checked)}
                      className="rounded"
                    />
                    Email
                  </label>
                  <label className="flex items-center gap-2 text-xs text-gray-600">
                    <input
                      type="checkbox"
                      checked={contactData.preferSMS}
                      onChange={(e) => handleChange('preferSMS', e.target.checked)}
                      className="rounded"
                    />
                    SMS/Text
                  </label>
                  <label className="flex items-center gap-2 text-xs text-gray-600">
                    <input
                      type="checkbox"
                      checked={contactData.preferMail}
                      onChange={(e) => handleChange('preferMail', e.target.checked)}
                      className="rounded"
                    />
                    Mail
                  </label>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'addresses' && (
            <div className="max-w-2xl space-y-4">
              {contactData.addresses.map((address, index) => (
                <div key={index} className="bg-white rounded-lg border border-gray-200 p-4">
                  <h3 className="text-xs font-semibold text-gray-700 uppercase mb-3">
                    Address {index + 1}
                  </h3>
                  <div className="grid grid-cols-6 gap-3">
                    <div className="col-span-4">
                      <label className="block text-[11px] text-gray-500 uppercase mb-1">Street</label>
                      <Input className="h-9 text-sm" />
                    </div>
                    <div className="col-span-2">
                      <label className="block text-[11px] text-gray-500 uppercase mb-1">Apt/Suite</label>
                      <Input className="h-9 text-sm" />
                    </div>
                    <div className="col-span-2">
                      <label className="block text-[11px] text-gray-500 uppercase mb-1">City</label>
                      <Input className="h-9 text-sm" />
                    </div>
                    <div className="col-span-2">
                      <label className="block text-[11px] text-gray-500 uppercase mb-1">State</label>
                      <select className="w-full h-9 text-sm border border-gray-200 rounded px-2">
                        <option>Select...</option>
                        <option>SC</option>
                        <option>NC</option>
                        <option>GA</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[11px] text-gray-500 uppercase mb-1">ZIP</label>
                      <Input className="h-9 text-sm" />
                    </div>
                    <div>
                      <label className="block text-[11px] text-gray-500 uppercase mb-1">Country</label>
                      <Input className="h-9 text-sm" defaultValue="USA" />
                    </div>
                  </div>
                </div>
              ))}
              <Button variant="outline" className="text-xs h-8" onClick={addAddress}>
                <Plus className="w-3 h-3 mr-1" /> Add Another Address
              </Button>
            </div>
          )}

          {(activeTab === 'spouse' || activeTab === 'attorney' || activeTab === 'documents') && (
            <div className="flex items-center justify-center h-64 text-gray-500 text-sm">
              {activeTab === 'spouse' && 'Spouse information will appear here'}
              {activeTab === 'attorney' && 'Attorney information will appear here'}
              {activeTab === 'documents' && 'Related documents will appear here'}
            </div>
          )}
        </div>
      </div>

      {/* Right Search Panel */}
      <div className="w-52 bg-white border-l border-gray-200 flex-shrink-0 p-3">
        <h3 className="text-xs font-semibold text-gray-700 mb-3">Search Existing</h3>
        <div className="relative mb-4">
          <Input
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search contacts..."
            className="h-8 text-xs pr-8"
          />
          <Search className="absolute right-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400" />
        </div>

        <h4 className="text-[10px] font-semibold text-gray-500 uppercase mb-2">Assign Role</h4>
        <div className="space-y-1">
          {categories.slice(0, 6).map((cat) => (
            <label key={cat.id} className="flex items-center gap-2 text-xs text-gray-600">
              <input type="checkbox" className="rounded w-3 h-3" />
              {cat.label}
            </label>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ProjectContactsPage;
