// ============================================
// APP.JSX ROUTING UPDATES - UPDATE 2
// Add these imports and routes to your App.jsx
// ============================================

// ADD THESE IMPORTS:
// -----------------------------------------

// Reports Module
import ReportsLayout from '@/components/ReportsLayout';
import PresetReportsPage from '@/pages/reports/PresetReportsPage';
import CustomReportsPage from '@/pages/reports/CustomReportsPage';
import SubscribedReportsPage from '@/pages/reports/SubscribedReportsPage';
import ReportPackagesPage from '@/pages/reports/ReportPackagesPage';
import TrendsPage from '@/pages/reports/TrendsPage';

// Global Pages
import GlobalContactsPage from '@/pages/GlobalContactsPage';
import CalendarPage from '@/pages/CalendarPage';

// Project Pages
import ProjectDocumentsPage from '@/pages/project/ProjectDocumentsPage';


// ADD THESE ROUTES:
// -----------------------------------------

// Global Contacts Route (already added, just verify)
<Route path="/contacts" element={<GlobalContactsPage />} />

// Calendar Route (replace existing)
<Route path="/calendar" element={<CalendarPage />} />

// Reports Module Routes
<Route path="/reports" element={<ReportsLayout />}>
  <Route index element={<Navigate to="/reports/preset" replace />} />
  <Route path="preset" element={<PresetReportsPage />} />
  <Route path="preset/:category" element={<PresetReportsPage />} />
  <Route path="custom" element={<CustomReportsPage />} />
  <Route path="subscribed" element={<SubscribedReportsPage />} />
  <Route path="packages" element={<ReportPackagesPage />} />
  <Route path="trends" element={<TrendsPage />} />
</Route>

// Inside Project routes, add Documents:
<Route path="documents" element={<ProjectDocumentsPage />} />


// ============================================
// FILE PLACEMENT INSTRUCTIONS
// ============================================

// Components:
// TopNavigation.jsx -> src/components/TopNavigation.jsx (replace)
// ReportsLayout.jsx -> src/components/ReportsLayout.jsx (new)

// Global Pages:
// CalendarPage.jsx -> src/pages/CalendarPage.jsx (replace)
// GlobalContactsPage.jsx -> src/pages/GlobalContactsPage.jsx (replace)

// Reports Pages (create new folder: src/pages/reports/):
// PresetReportsPage.jsx -> src/pages/reports/PresetReportsPage.jsx
// CustomReportsPage.jsx -> src/pages/reports/CustomReportsPage.jsx
// SubscribedReportsPage.jsx -> src/pages/reports/SubscribedReportsPage.jsx
// ReportPackagesPage.jsx -> src/pages/reports/ReportPackagesPage.jsx
// TrendsPage.jsx -> src/pages/reports/TrendsPage.jsx

// Project Pages:
// ProjectDocumentsPage.jsx -> src/pages/project/ProjectDocumentsPage.jsx (new)


// ============================================
// SIDEBAR UPDATE (ProjectSidebar.jsx)
// ============================================

// Add Documents to the sidebar under TASKS section:
const tasksItems = [
  { id: 'documents', label: 'Documents', path: 'documents', icon: FileText },
  // ... other items
];


// ============================================
// BASH COMMANDS TO RUN
// ============================================
/*
cd /workspaces/atlas-dev-app/atlasdev-build

# Create reports folder
mkdir -p src/pages/reports

# Copy files
cp -f TopNavigation.jsx src/components/
cp -f ReportsLayout.jsx src/components/
cp -f CalendarPage.jsx src/pages/
cp -f GlobalContactsPage.jsx src/pages/
cp -f PresetReportsPage.jsx src/pages/reports/
cp -f CustomReportsPage.jsx src/pages/reports/
cp -f SubscribedReportsPage.jsx src/pages/reports/
cp -f ReportPackagesPage.jsx src/pages/reports/
cp -f TrendsPage.jsx src/pages/reports/
cp -f ProjectDocumentsPage.jsx src/pages/project/

# Clean up
rm -f *.jsx ROUTING_INSTRUCTIONS.jsx

# Verify
ls -la src/pages/reports/

# Restart
rm -rf node_modules/.vite
npm run dev
*/
