import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { Search, Plus, Trash2, ExternalLink } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

const ProjectPropertyPage = () => {
  const { projectId } = useParams();
  const [activeTab, setActiveTab] = useState('property');
  
  const [formData, setFormData] = useState({
    // Property Tab
    street: '',
    apt: '',
    city: '',
    county: '',
    state: '',
    zip: '',
    propertyType: '',
    jurisdiction: '',
    zoning: '',
    yearBuilt: '',
    briefLegal: '',
    lotSize: '',
    lotUnit: 'acres',
    frontage: '',
    depth: '',
    buildingSize: '',
    stories: '',
    bedrooms: '',
    bathrooms: '',
    garageSpaces: '',
    parcelIds: [''],
    assessedValue: '',
    annualTax: '',
    taxYear: '',
    // Legal Description Tab
    fullLegalDescription: '',
    // Subdivision Tab
    subdivisionName: '',
    phase: '',
    lotNumber: '',
    block: '',
    section: '',
    platBook: '',
    platPage: '',
    // Survey Tab
    surveyCompany: '',
    surveyorName: '',
    surveyDate: '',
    surveyType: '',
    surveyNotes: '',
  });

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleParcelChange = (index, value) => {
    const newParcels = [...formData.parcelIds];
    newParcels[index] = value;
    setFormData(prev => ({ ...prev, parcelIds: newParcels }));
  };

  const addParcel = () => {
    setFormData(prev => ({ ...prev, parcelIds: [...prev.parcelIds, ''] }));
  };

  const removeParcel = (index) => {
    if (formData.parcelIds.length > 1) {
      const newParcels = formData.parcelIds.filter((_, i) => i !== index);
      setFormData(prev => ({ ...prev, parcelIds: newParcels }));
    }
  };

  const tabs = [
    { id: 'property', label: 'Property' },
    { id: 'legal', label: 'Legal Description' },
    { id: 'subdivision', label: 'Subdivision' },
    { id: 'survey', label: 'Survey' },
  ];

  const propertyTypes = [
    'Residence 1-4 Family',
    'Condominium',
    'Townhouse',
    'Multi-Family 5+',
    'Commercial',
    'Industrial',
    'Land/Lot',
    'Mixed Use',
    'Agricultural',
    'Mobile Home',
  ];

  const zoningTypes = [
    'R-1 Single Family',
    'R-2 Two Family',
    'R-3 Multi-Family',
    'R-4 High Density',
    'C-1 Light Commercial',
    'C-2 General Commercial',
    'C-3 Heavy Commercial',
    'I-1 Light Industrial',
    'I-2 Heavy Industrial',
    'PUD Planned Development',
    'A Agricultural',
    'MU Mixed Use',
  ];

  const surveyTypes = [
    'Boundary Survey',
    'ALTA/NSPS Survey',
    'Topographic Survey',
    'Construction Survey',
  ];

  return (
    <div className="p-6 bg-gray-50 min-h-full overflow-auto">
      <div className="max-w-4xl">
        {/* Tabs */}
        <div className="flex gap-1 mb-4">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={cn(
                "px-4 py-2 text-xs font-medium rounded-t transition-colors",
                activeTab === tab.id
                  ? "bg-gray-800 text-white"
                  : "bg-white text-gray-600 hover:bg-gray-100 border border-gray-200"
              )}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Property Tab */}
        {activeTab === 'property' && (
          <div className="space-y-4">
            {/* Address */}
            <div className="bg-white rounded-lg border border-gray-200 p-4">
              <h3 className="text-xs font-semibold text-gray-700 uppercase mb-4">Address</h3>
              <div className="grid grid-cols-6 gap-3">
                <div className="col-span-3">
                  <label className="block text-[11px] text-gray-500 uppercase mb-1">Street</label>
                  <Input 
                    value={formData.street}
                    onChange={(e) => handleChange('street', e.target.value)}
                    className="h-9 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-gray-500 uppercase mb-1">Apt/Unit</label>
                  <Input 
                    value={formData.apt}
                    onChange={(e) => handleChange('apt', e.target.value)}
                    className="h-9 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-gray-500 uppercase mb-1">City</label>
                  <Input 
                    value={formData.city}
                    onChange={(e) => handleChange('city', e.target.value)}
                    className="h-9 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-gray-500 uppercase mb-1">County</label>
                  <Input 
                    value={formData.county}
                    onChange={(e) => handleChange('county', e.target.value)}
                    className="h-9 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-gray-500 uppercase mb-1">State</label>
                  <select 
                    value={formData.state}
                    onChange={(e) => handleChange('state', e.target.value)}
                    className="w-full h-9 text-sm border border-gray-200 rounded px-2"
                  >
                    <option value="">Select...</option>
                    <option value="SC">South Carolina</option>
                    <option value="NC">North Carolina</option>
                    <option value="GA">Georgia</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] text-gray-500 uppercase mb-1">ZIP</label>
                  <Input 
                    value={formData.zip}
                    onChange={(e) => handleChange('zip', e.target.value)}
                    className="h-9 text-sm"
                  />
                </div>
              </div>
            </div>

            {/* Property Details */}
            <div className="bg-white rounded-lg border border-gray-200 p-4">
              <h3 className="text-xs font-semibold text-gray-700 uppercase mb-4">Property Details</h3>
              <div className="grid grid-cols-4 gap-3">
                <div>
                  <label className="block text-[11px] text-gray-500 uppercase mb-1">Property Type</label>
                  <select 
                    value={formData.propertyType}
                    onChange={(e) => handleChange('propertyType', e.target.value)}
                    className="w-full h-9 text-sm border border-gray-200 rounded px-2"
                  >
                    <option value="">Select type...</option>
                    {propertyTypes.map(type => (
                      <option key={type} value={type}>{type}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] text-gray-500 uppercase mb-1">Municipal Jurisdiction</label>
                  <Input 
                    value={formData.jurisdiction}
                    onChange={(e) => handleChange('jurisdiction', e.target.value)}
                    className="h-9 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-gray-500 uppercase mb-1">Zoning</label>
                  <select 
                    value={formData.zoning}
                    onChange={(e) => handleChange('zoning', e.target.value)}
                    className="w-full h-9 text-sm border border-gray-200 rounded px-2"
                  >
                    <option value="">Select zoning...</option>
                    {zoningTypes.map(type => (
                      <option key={type} value={type}>{type}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] text-gray-500 uppercase mb-1">Year Built</label>
                  <Input 
                    type="number"
                    value={formData.yearBuilt}
                    onChange={(e) => handleChange('yearBuilt', e.target.value)}
                    className="h-9 text-sm"
                  />
                </div>
              </div>
              <div className="mt-3">
                <label className="block text-[11px] text-gray-500 uppercase mb-1">Brief Legal Description</label>
                <div className="flex gap-2">
                  <Input 
                    value={formData.briefLegal}
                    onChange={(e) => handleChange('briefLegal', e.target.value)}
                    className="h-9 text-sm flex-1"
                    placeholder="Enter brief legal description..."
                  />
                  <Button variant="link" className="text-xs text-[#047857] h-9 px-2">
                    Add Full Description
                  </Button>
                </div>
              </div>
            </div>

            {/* Dimensions */}
            <div className="bg-white rounded-lg border border-gray-200 p-4">
              <h3 className="text-xs font-semibold text-gray-700 uppercase mb-4">Dimensions</h3>
              <div className="grid grid-cols-5 gap-3">
                <div>
                  <label className="block text-[11px] text-gray-500 uppercase mb-1">Lot Size</label>
                  <div className="flex gap-1">
                    <Input 
                      type="number"
                      value={formData.lotSize}
                      onChange={(e) => handleChange('lotSize', e.target.value)}
                      className="h-9 text-sm flex-1"
                    />
                    <select 
                      value={formData.lotUnit}
                      onChange={(e) => handleChange('lotUnit', e.target.value)}
                      className="h-9 text-xs border border-gray-200 rounded px-1 w-16"
                    >
                      <option value="acres">acres</option>
                      <option value="sqft">sqft</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-[11px] text-gray-500 uppercase mb-1">Frontage (ft)</label>
                  <Input 
                    type="number"
                    value={formData.frontage}
                    onChange={(e) => handleChange('frontage', e.target.value)}
                    className="h-9 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-gray-500 uppercase mb-1">Depth (ft)</label>
                  <Input 
                    type="number"
                    value={formData.depth}
                    onChange={(e) => handleChange('depth', e.target.value)}
                    className="h-9 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-gray-500 uppercase mb-1">Building Size (sqft)</label>
                  <Input 
                    type="number"
                    value={formData.buildingSize}
                    onChange={(e) => handleChange('buildingSize', e.target.value)}
                    className="h-9 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-gray-500 uppercase mb-1">Stories</label>
                  <Input 
                    type="number"
                    value={formData.stories}
                    onChange={(e) => handleChange('stories', e.target.value)}
                    className="h-9 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-gray-500 uppercase mb-1">Bedrooms</label>
                  <Input 
                    type="number"
                    value={formData.bedrooms}
                    onChange={(e) => handleChange('bedrooms', e.target.value)}
                    className="h-9 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-gray-500 uppercase mb-1">Bathrooms</label>
                  <Input 
                    type="number"
                    value={formData.bathrooms}
                    onChange={(e) => handleChange('bathrooms', e.target.value)}
                    className="h-9 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-gray-500 uppercase mb-1">Garage Spaces</label>
                  <Input 
                    type="number"
                    value={formData.garageSpaces}
                    onChange={(e) => handleChange('garageSpaces', e.target.value)}
                    className="h-9 text-sm"
                  />
                </div>
              </div>
            </div>

            {/* Parcel IDs */}
            <div className="bg-white rounded-lg border border-gray-200 p-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xs font-semibold text-gray-700 uppercase">Parcel IDs</h3>
                <Button variant="outline" size="sm" className="text-xs h-7" onClick={addParcel}>
                  <Plus className="w-3 h-3 mr-1" /> Add Parcel
                </Button>
              </div>
              <div className="space-y-2">
                {formData.parcelIds.map((parcel, index) => (
                  <div key={index} className="flex gap-2">
                    <Input 
                      value={parcel}
                      onChange={(e) => handleParcelChange(index, e.target.value)}
                      className="h-9 text-sm flex-1"
                      placeholder="Enter parcel ID..."
                    />
                    <Button variant="outline" size="sm" className="h-9 px-2">
                      <ExternalLink className="w-3.5 h-3.5" />
                    </Button>
                    {formData.parcelIds.length > 1 && (
                      <Button variant="outline" size="sm" className="h-9 px-2 text-red-500" onClick={() => removeParcel(index)}>
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Tax Information */}
            <div className="bg-white rounded-lg border border-gray-200 p-4">
              <h3 className="text-xs font-semibold text-gray-700 uppercase mb-4">Tax Information</h3>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] text-gray-500 uppercase mb-1">Assessed Value</label>
                  <Input 
                    value={formData.assessedValue}
                    onChange={(e) => handleChange('assessedValue', e.target.value)}
                    placeholder="$0.00"
                    className="h-9 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-gray-500 uppercase mb-1">Annual Tax</label>
                  <Input 
                    value={formData.annualTax}
                    onChange={(e) => handleChange('annualTax', e.target.value)}
                    placeholder="$0.00"
                    className="h-9 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-gray-500 uppercase mb-1">Tax Year</label>
                  <Input 
                    type="number"
                    value={formData.taxYear}
                    onChange={(e) => handleChange('taxYear', e.target.value)}
                    placeholder="2024"
                    className="h-9 text-sm"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Legal Description Tab */}
        {activeTab === 'legal' && (
          <div className="bg-white rounded-lg border border-gray-200 p-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xs font-semibold text-gray-700 uppercase">Full Legal Description</h3>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="text-xs h-7">Import</Button>
                <Button variant="outline" size="sm" className="text-xs h-7">Lookup</Button>
              </div>
            </div>
            <textarea 
              value={formData.fullLegalDescription}
              onChange={(e) => handleChange('fullLegalDescription', e.target.value)}
              className="w-full h-64 text-sm border border-gray-200 rounded p-3 resize-none"
              placeholder="Enter full legal description..."
            />
          </div>
        )}

        {/* Subdivision Tab */}
        {activeTab === 'subdivision' && (
          <div className="bg-white rounded-lg border border-gray-200 p-4">
            <h3 className="text-xs font-semibold text-gray-700 uppercase mb-4">Subdivision Information</h3>
            <div className="grid grid-cols-3 gap-4">
              <div className="col-span-2">
                <label className="block text-[11px] text-gray-500 uppercase mb-1">Subdivision Name</label>
                <Input 
                  value={formData.subdivisionName}
                  onChange={(e) => handleChange('subdivisionName', e.target.value)}
                  className="h-9 text-sm"
                />
              </div>
              <div>
                <label className="block text-[11px] text-gray-500 uppercase mb-1">Phase</label>
                <Input 
                  value={formData.phase}
                  onChange={(e) => handleChange('phase', e.target.value)}
                  className="h-9 text-sm"
                />
              </div>
              <div>
                <label className="block text-[11px] text-gray-500 uppercase mb-1">Lot Number</label>
                <Input 
                  value={formData.lotNumber}
                  onChange={(e) => handleChange('lotNumber', e.target.value)}
                  className="h-9 text-sm"
                />
              </div>
              <div>
                <label className="block text-[11px] text-gray-500 uppercase mb-1">Block</label>
                <Input 
                  value={formData.block}
                  onChange={(e) => handleChange('block', e.target.value)}
                  className="h-9 text-sm"
                />
              </div>
              <div>
                <label className="block text-[11px] text-gray-500 uppercase mb-1">Section</label>
                <Input 
                  value={formData.section}
                  onChange={(e) => handleChange('section', e.target.value)}
                  className="h-9 text-sm"
                />
              </div>
              <div>
                <label className="block text-[11px] text-gray-500 uppercase mb-1">Plat Book</label>
                <Input 
                  value={formData.platBook}
                  onChange={(e) => handleChange('platBook', e.target.value)}
                  className="h-9 text-sm"
                />
              </div>
              <div>
                <label className="block text-[11px] text-gray-500 uppercase mb-1">Plat Page</label>
                <Input 
                  value={formData.platPage}
                  onChange={(e) => handleChange('platPage', e.target.value)}
                  className="h-9 text-sm"
                />
              </div>
            </div>
          </div>
        )}

        {/* Survey Tab */}
        {activeTab === 'survey' && (
          <div className="bg-white rounded-lg border border-gray-200 p-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xs font-semibold text-gray-700 uppercase">Survey Information</h3>
              <Button variant="outline" size="sm" className="text-xs h-7">Upload Survey</Button>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-[11px] text-gray-500 uppercase mb-1">Survey Company</label>
                <div className="relative">
                  <Input 
                    value={formData.surveyCompany}
                    onChange={(e) => handleChange('surveyCompany', e.target.value)}
                    className="h-9 text-sm pr-8"
                  />
                  <Search className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                </div>
              </div>
              <div>
                <label className="block text-[11px] text-gray-500 uppercase mb-1">Surveyor Name</label>
                <Input 
                  value={formData.surveyorName}
                  onChange={(e) => handleChange('surveyorName', e.target.value)}
                  className="h-9 text-sm"
                />
              </div>
              <div>
                <label className="block text-[11px] text-gray-500 uppercase mb-1">Survey Date</label>
                <Input 
                  type="date"
                  value={formData.surveyDate}
                  onChange={(e) => handleChange('surveyDate', e.target.value)}
                  className="h-9 text-sm"
                />
              </div>
              <div>
                <label className="block text-[11px] text-gray-500 uppercase mb-1">Survey Type</label>
                <select 
                  value={formData.surveyType}
                  onChange={(e) => handleChange('surveyType', e.target.value)}
                  className="w-full h-9 text-sm border border-gray-200 rounded px-2"
                >
                  <option value="">Select type...</option>
                  {surveyTypes.map(type => (
                    <option key={type} value={type}>{type}</option>
                  ))}
                </select>
              </div>
              <div className="col-span-2">
                <label className="block text-[11px] text-gray-500 uppercase mb-1">Notes</label>
                <textarea 
                  value={formData.surveyNotes}
                  onChange={(e) => handleChange('surveyNotes', e.target.value)}
                  className="w-full h-24 text-sm border border-gray-200 rounded p-2 resize-none"
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProjectPropertyPage;
