// src/components/inspections/index.js
// Export all inspection components

export { default as CreateInspectionModal } from './CreateInspectionModal';
